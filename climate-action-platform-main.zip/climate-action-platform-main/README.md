# 🌱 ClimateAction — Personalized Climate Action & Impact Website

A full-stack, production-grade web application built to understand personal environmental lifestyle habits, deliver personalized climate-action recommendations, report genuine climate actions with authentic photo proof, conduct automated heuristic & admin verification, award impact-based points, maintain daily streaks, map 52-week activity heatmaps, dynamically calculate a 0–100 Climate Action Score, participate in community teams, follow peers, and compete on worldwide leaderboards.

Aligned with **United Nations Sustainable Development Goal 13 (Climate Action)**.

---

## 🌟 Key Features

1. **Real Full-Stack Architecture**:
   - Frontend: Modern HTML5, CSS3, ES6+ JavaScript, Lucide Icons, Chart.js.
   - Backend: Node.js & Express.js REST APIs with structured JSON responses.
   - Database: MongoDB & Mongoose with schema validation, compound indexes, and TTL indexes.
   - Storage: Photo proof upload with strict MIME/extension validation and video rejection.
2. **Authentic Authentication with 2-Step OTP**:
   - Secure registration with real 6-digit email OTPs.
   - Passwords hashed using bcrypt.
   - JWT sessions with HTTP-only cookies and Bearer tokens.
   - Forgot password and reset password using secure email OTPs.
   - Anti-brute-force rate limiting and OTP attempt limits.
3. **Personal Climate Lifestyle Assessment**:
   - Comprehensive questionnaire covering Transportation, Energy, Water, Diet, Waste, Shopping, Nature, and Climate Concern.
   - Dynamic baseline calculation and rule-based recommendation generation.
4. **Explainable Recommendation Engine**:
   - Formulates personalized recommendations with transparent source-habit rationales.
   - Pre-populates daily actions and report forms.
5. **Authentic Action Reporting & Proof Verification**:
   - Reporting with mandatory photo proof (JPG, JPEG, PNG, WEBP).
   - Strict rejection of video files (MP4, MOV, AVI, etc.).
   - Two-stage verification:
     - Stage 1: Automated heuristic checks (photo integrity, descriptive substance, keyword context, timestamp plausibility).
     - Stage 2: Admin review queue for uncertain or flagged actions.
6. **Scientifically-Grounded Environmental Impact & Points**:
   - Transparent calculations of estimated CO2 avoided (kg), water saved (L), energy conserved (kWh), and waste diverted (kg).
   - Dynamic points calculation based on real environmental benefits.
   - Traceable, idempotent transaction logging (`ImpactTransaction`) preventing duplicate awards.
7. **Daily Streaks & 52-Week Activity Heatmap**:
   - Real streak tracking for consecutive days with verified actions.
   - GitHub-style 52-week activity heatmap based solely on real database activity.
8. **0–100 Dynamic Climate Action Score**:
   - Transparent formula combining action volume (30%), consistency (25%), habit diversity (20%), cumulative impact (15%), and engagement (10%).
9. **Global & Community Leaderboards**:
   - Real ranking based on verified impact points.
   - Deterministic tie-breaking preserving earlier achievers.
   - Community leaderboards aggregating team scores.
10. **Communities & Social Features**:
    - Users can create 1 active community as admin.
    - Community post feeds with photo sharing, replies, and seedling reactions.
    - User follow/unfollow system with follower counters and in-app alerts.
11. **Notifications & Scheduled Email Reminders**:
    - In-app notification center for approvals, points, followers, and comments.
    - Background cron scheduler (`node-cron`) for daily action reminders and missed-streak recovery alerts.
12. **Admin Dashboard**:
    - Verification queue with photo proof inspection.
    - Automated check audits and confidence score display.
    - Approval and rejection controls with mandatory feedback.
    - Platform user and community moderation.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | HTML5, CSS3, Modern JavaScript (ES6+), Chart.js, Lucide Icons |
| **Backend** | Node.js (v18+), Express.js |
| **Database** | MongoDB / MongoDB Atlas, Mongoose ODM |
| **Authentication** | JWT, bcryptjs, cookie-parser, express-rate-limit |
| **File Storage** | Multer (photo-only storage with file type filtering) |
| **Email Delivery** | Nodemailer (Real SMTP with Ethereal fallback) |
| **Task Scheduling**| node-cron |

---

## 📋 Prerequisites

- **Node.js**: v18.0.0 or higher (`node -v`)
- **NPM**: v9.0.0 or higher (`npm -v`)
- **Google Chrome** (or any modern Chromium browser)
- **MongoDB** (Optional: If local MongoDB or Atlas URI is not provided, the platform automatically launches an embedded in-memory MongoDB instance with zero configuration required!)

---

## 🚀 Installation & Quick Start

### 1. Install Dependencies
In the project root folder:
\`\`\`bash
npm install
\`\`\`

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
\`\`\`bash
cp .env.example .env
\`\`\`

Review `.env` settings:
- `PORT`: Server port (default: `3000`).
- `MONGODB_URI`: Your MongoDB connection URI. If left blank, the application automatically launches an embedded MongoDB engine.
- `JWT_SECRET`: Secret key for signing authentication tokens.
- `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USER`, `EMAIL_PASSWORD`: Real SMTP credentials (e.g. Gmail App Password). If omitted, Nodemailer operates using an Ethereal development mailbox with preview links.
- `ADMIN_SECRET_KEY`: Passkey to register an administrator account during registration (default: `climate_admin_secret_setup_key_2026`).

### 3. Start the Development Server
\`\`\`bash
npm run dev
\`\`\`
or:
\`\`\`bash
npm start
\`\`\`

### 4. Open in Google Chrome
Navigate to:
\`\`\`
http://localhost:3000
\`\`\`

---

## 🧪 Testing

To run the full-stack automated integration test suite:
\`\`\`bash
node test/api-test.js
\`\`\`

To test HTTP endpoints, real file uploads, video rejection, and frontend delivery:
\`\`\`bash
node test/http-test.js
\`\`\`

---

## 🔑 Administrative Account Setup

To register an administrator account:
1. Navigate to **Get Started** (`#signup`).
2. Enter your email address to receive a 6-digit verification code.
3. In Step 2, enter the OTP, full name, password, and the **Admin Passkey**:
   \`climate_admin_secret_setup_key_2026\`
4. Submit to create your verified Administrator account.
5. The **Admin** link will appear in your top navigation bar, granting access to the action verification queue, photo inspection, and platform statistics.

---

## 🛡️ Security & Integrity

- **No Fake Data**: Every statistic, leaderboard rank, streak, score, and heatmap square is generated from actual database records.
- **Strict Photo-Only Verification**: Video formats (MP4, MOV, AVI, MKV) are strictly blocked on both the client and server.
- **Idempotency**: Action approvals cannot duplicate points or impact metrics.
- **Secure Password Hashing**: Utilizes bcrypt with 10 salt rounds.
- **Protection**: Rate-limiting on authentication and OTP generation endpoints prevents brute-force abuse.
