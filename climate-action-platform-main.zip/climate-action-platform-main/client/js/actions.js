/**
 * ClimateAction — Actions Controller (Frontend)
 * Handles reporting genuine climate actions with photo proof, live image previews,
 * automatic verification status modals, and filtered action history.
 */

window.actions = {
  selectedFile: null,

  init() {
    this.bindEvents();
  },

  bindEvents() {
    const reportForm = document.getElementById('report-action-form');
    const photoInput = document.getElementById('report-photo-input');
    const dropArea = document.getElementById('report-drop-area');

    if (photoInput) {
      photoInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          this.handleFileSelected(e.target.files[0]);
        }
      });
    }

    if (dropArea) {
      ['dragenter', 'dragover'].forEach((eventName) => {
        dropArea.addEventListener(eventName, (e) => {
          e.preventDefault();
          dropArea.style.borderColor = 'var(--emerald)';
          dropArea.style.background = 'var(--soft-green)';
        });
      });

      ['dragleave', 'drop'].forEach((eventName) => {
        dropArea.addEventListener(eventName, (e) => {
          e.preventDefault();
          dropArea.style.borderColor = 'var(--light-border)';
          dropArea.style.background = 'transparent';
        });
      });

      dropArea.addEventListener('drop', (e) => {
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          this.handleFileSelected(e.dataTransfer.files[0]);
        }
      });
    }

    if (reportForm) {
      reportForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.submitReport();
      });
    }

    // Filter controls for Action History
    const statusFilter = document.getElementById('history-status-filter');
    const categoryFilter = document.getElementById('history-category-filter');

    if (statusFilter) {
      statusFilter.addEventListener('change', () => this.loadHistory());
    }
    if (categoryFilter) {
      categoryFilter.addEventListener('change', () => this.loadHistory());
    }
  },

  handleFileSelected(file) {
    // Strictly validate photo formats and reject video formats
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const ext = file.name.split('.').pop().toLowerCase();
    const disallowedVideos = ['mp4', 'mov', 'avi', 'mkv', 'webm', 'flv'];

    if (disallowedVideos.includes(ext) || file.type.startsWith('video/')) {
      window.app.showToast('Video files are not allowed. Please upload a clear photo proof (JPG, PNG, WEBP).', 'error');
      this.clearSelectedFile();
      return;
    }

    if (!allowed.includes(file.type)) {
      window.app.showToast('Invalid photo format. Please upload JPG, JPEG, PNG, or WEBP.', 'error');
      this.clearSelectedFile();
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      window.app.showToast('Photo proof size must not exceed 5MB.', 'error');
      this.clearSelectedFile();
      return;
    }

    this.selectedFile = file;

    // Show preview
    const previewContainer = document.getElementById('report-photo-preview-container');
    const previewImg = document.getElementById('report-photo-preview-img');
    const placeholder = document.getElementById('report-drop-placeholder');

    const reader = new FileReader();
    reader.onload = (e) => {
      previewImg.src = e.target.result;
      previewContainer.style.display = 'block';
      placeholder.style.display = 'none';
    };
    reader.readAsDataURL(file);
  },

  clearSelectedFile() {
    this.selectedFile = null;
    const photoInput = document.getElementById('report-photo-input');
    if (photoInput) photoInput.value = '';
    const previewContainer = document.getElementById('report-photo-preview-container');
    const placeholder = document.getElementById('report-drop-placeholder');
    if (previewContainer) previewContainer.style.display = 'none';
    if (placeholder) placeholder.style.display = 'block';
  },

  prefillReport(title, category, description) {
    window.app.navigate('report');
    setTimeout(() => {
      document.getElementById('report-title').value = decodeURIComponent(title);
      document.getElementById('report-category').value = category;
      document.getElementById('report-description').value = decodeURIComponent(description);
    }, 100);
  },

  async submitReport() {
    if (!this.selectedFile) {
      window.app.showToast('Please upload authentic photo proof of your climate action.', 'error');
      return;
    }

    const title = document.getElementById('report-title').value.trim();
    const category = document.getElementById('report-category').value;
    const description = document.getElementById('report-description').value.trim();
    const quantity = document.getElementById('report-quantity').value || 1;
    const date = document.getElementById('report-date').value;

    if (!title || !category || !description) {
      window.app.showToast('Please fill in title, category, and action description.', 'error');
      return;
    }

    const submitBtn = document.getElementById('report-submit-btn');

    try {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i data-lucide="loader" class="spin"></i> Verifying Proof...';

      const formData = new FormData();
      formData.append('title', title);
      formData.append('category', category);
      formData.append('description', description);
      formData.append('quantity', quantity);
      if (date) formData.append('date', date);
      formData.append('photoProof', this.selectedFile);

      const res = await window.api.reportAction(formData);

      this.clearSelectedFile();
      document.getElementById('report-action-form').reset();

      if (res.verificationStatus === 'approved') {
        window.app.showToast(`Action Approved! +${res.pointsEarned} points awarded.`, 'success');
        this.showApprovalModal(res);
      } else {
        window.app.showToast('Action received and queued for review.', 'info');
        window.app.navigate('history');
      }
    } catch (err) {
      window.app.showToast(err.message, 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i data-lucide="send"></i> Submit Climate Action';
      if (window.lucide) window.lucide.createIcons();
    }
  },

  showApprovalModal(res) {
    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-header">
          <h3 class="modal-title">🎉 Action Verified!</h3>
          <button class="modal-close-btn" onclick="this.closest('.modal-backdrop').remove()">&times;</button>
        </div>
        <div class="modal-body" style="text-align: center;">
          <div style="width: 70px; height: 70px; border-radius: 50%; background: var(--soft-green); color: var(--emerald); display: inline-flex; align-items: center; justify-content: center; font-size: 2rem; margin-bottom: 1rem;">
            ✓
          </div>
          <h3 style="font-size: 1.4rem; color: var(--dark); margin-bottom: 0.5rem;">${res.action.title}</h3>
          <p style="color: var(--secondary-text); margin-bottom: 1.5rem;">${res.impact?.explanation || 'Estimated positive climate benefit recorded.'}</p>
          
          <div class="grid-2" style="margin-bottom: 1.5rem;">
            <div style="background: var(--soft-green); padding: 1rem; border-radius: var(--radius-md);">
              <div style="font-size: 1.8rem; font-weight: 800; color: #047857;">+${res.pointsEarned}</div>
              <div style="font-size: 0.8rem; font-weight: 600; color: #065F46;">IMPACT POINTS</div>
            </div>
            <div style="background: #EFF6FF; padding: 1rem; border-radius: var(--radius-md);">
              <div style="font-size: 1.8rem; font-weight: 800; color: #1D4ED8;">~${res.impact?.co2AvoidedKg || 0} kg</div>
              <div style="font-size: 0.8rem; font-weight: 600; color: #1E40AF;">CO2 AVOIDED</div>
            </div>
          </div>

          <div style="display: flex; gap: 0.75rem; justify-content: center;">
            <button class="btn btn-secondary" onclick="this.closest('.modal-backdrop').remove(); window.app.navigate('dashboard');">Go to Dashboard</button>
            <button class="btn btn-primary" onclick="this.closest('.modal-backdrop').remove(); window.app.navigate('history');">View Action History</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  },

  async loadHistory() {
    const listEl = document.getElementById('history-actions-list');
    if (!listEl) return;

    const status = document.getElementById('history-status-filter')?.value || 'all';
    const category = document.getElementById('history-category-filter')?.value || 'all';

    try {
      listEl.innerHTML = '<div style="text-align: center; padding: 2rem;"><p>Loading actions...</p></div>';

      const res = await window.api.getActionHistory({ status, category });
      const actions = res.actions || [];

      if (actions.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon"><i data-lucide="inbox"></i></div>
            <h4 class="empty-state-title">No Actions Found</h4>
            <p class="empty-state-text">No actions match your current filter selection. Report a new climate action with photo proof anytime.</p>
            <button class="btn btn-primary" onclick="window.app.navigate('report')">Report An Action</button>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
      }

      listEl.innerHTML = `
        <div class="grid-3">
          ${actions
            .map(
              (act) => `
            <div class="action-card card-hover">
              <div class="action-card-img-wrapper">
                <img src="${act.photoProof}" alt="${act.title}" class="action-card-img" onclick="window.actions.viewPhotoModal('${act.photoProof}', '${encodeURIComponent(act.title)}')" style="cursor: pointer;" />
                <span class="badge badge-${act.verificationStatus}" style="position: absolute; top: 12px; right: 12px;">
                  ${act.verificationStatus.replace('_', ' ')}
                </span>
              </div>
              <div class="action-card-body">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.4rem;">
                  <span class="badge badge-category">${act.category}</span>
                  <span style="font-size: 0.8rem; color: var(--muted-text);">${new Date(act.date).toLocaleDateString()}</span>
                </div>
                <h4 class="action-card-title">${act.title}</h4>
                <p class="action-card-desc">${act.description}</p>
                ${
                  act.verificationStatus === 'approved'
                    ? `
                  <div style="background: var(--soft-green); border-radius: var(--radius-sm); padding: 8px 10px; font-size: 0.8rem; color: #047857; margin-bottom: 0.75rem;">
                    <strong>+${act.pointsEarned} Points</strong> &bull; ~${act.impact?.co2AvoidedKg || 0} kg CO2 avoided
                    <div style="font-size: 0.75rem; color: #065F46; margin-top: 2px;">${act.impact?.explanation || ''}</div>
                  </div>
                `
                    : act.verificationStatus === 'rejected'
                    ? `
                  <div style="background: var(--danger-light); border-radius: var(--radius-sm); padding: 8px 10px; font-size: 0.8rem; color: #991B1B; margin-bottom: 0.75rem;">
                    <strong>Verification Feedback:</strong> ${act.rejectionReason || 'Proof does not meet verification guidelines.'}
                  </div>
                `
                    : `
                  <div style="background: #F1F5F9; border-radius: var(--radius-sm); padding: 8px 10px; font-size: 0.8rem; color: var(--secondary-text); margin-bottom: 0.75rem;">
                    ⏳ Photo proof under verification. Points will be awarded upon approval.
                  </div>
                `
                }
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      `;

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('loadHistory error:', err);
      listEl.innerHTML = '<p style="color: var(--danger);">Failed to load action history.</p>';
    }
  },

  viewPhotoModal(src, title) {
    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.innerHTML = `
      <div class="modal-dialog" style="max-width: 720px; background: transparent; border: none; box-shadow: none;">
        <div style="text-align: right; margin-bottom: 8px;">
          <button class="btn btn-secondary btn-sm" onclick="this.closest('.modal-backdrop').remove()">Close &times;</button>
        </div>
        <img src="${src}" alt="${decodeURIComponent(title)}" style="width: 100%; max-height: 80vh; object-fit: contain; border-radius: var(--radius-lg); background: #000;" />
        <div style="color: var(--white); text-align: center; margin-top: 8px; font-weight: 600;">${decodeURIComponent(title)}</div>
      </div>
    `;
    document.body.appendChild(modal);
  },
};
