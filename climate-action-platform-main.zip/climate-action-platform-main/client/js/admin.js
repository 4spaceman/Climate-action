/**
 * ClimateAction — Admin Dashboard Controller (Frontend)
 * Handles action verification queue, photo inspection, approval/rejection, user moderation, and platform statistics.
 */

window.admin = {
  async render() {
    if (!window.app.currentUser || window.app.currentUser.role !== 'admin') {
      window.app.showToast('Access denied: Admin privileges required.', 'error');
      window.app.navigate('dashboard');
      return;
    }

    await Promise.all([this.loadStats(), this.loadPendingQueue(), this.loadUsers()]);
  },

  async loadStats() {
    try {
      const res = await window.api.getAdminStats();
      const s = res.stats;

      document.getElementById('admin-total-users').textContent = s.totalUsers;
      document.getElementById('admin-verified-actions').textContent = s.verifiedActionsCount;
      document.getElementById('admin-pending-queue').textContent = s.pendingReviewCount;
      document.getElementById('admin-total-points').textContent = s.totalPointsAwarded;
      document.getElementById('admin-total-co2').textContent = `${s.totalCO2AvoidedKg} kg`;
      document.getElementById('admin-total-water').textContent = `${s.totalWaterSavedLitres} L`;
    } catch (err) {
      console.error('loadStats error:', err);
    }
  },

  async loadPendingQueue() {
    const listEl = document.getElementById('admin-pending-list');
    if (!listEl) return;

    try {
      listEl.innerHTML = '<div style="text-align: center; padding: 2rem;"><p>Loading verification queue...</p></div>';

      const res = await window.api.getPendingActions();
      const actions = res.actions || [];

      if (actions.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon"><i data-lucide="check-check"></i></div>
            <h4 class="empty-state-title">Verification Queue Clean!</h4>
            <p class="empty-state-text">All reported climate actions have been verified and processed.</p>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
      }

      listEl.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
          ${actions
            .map((act) => {
              const audit = act.verificationAudit?.autoVerificationResult;
              const checks = audit?.checks || [];

              return `
              <div class="card" style="display: grid; grid-template-columns: 240px 1fr; gap: 1.5rem; align-items: start;">
                <div>
                  <img src="${act.photoProof}" alt="${act.title}" style="width: 100%; height: 180px; object-fit: cover; border-radius: var(--radius-md); cursor: pointer;" onclick="window.actions.viewPhotoModal('${act.photoProof}', '${encodeURIComponent(act.title)}')" />
                  <div style="font-size: 0.75rem; color: var(--muted-text); margin-top: 4px; text-align: center;">Click photo to zoom</div>
                </div>

                <div>
                  <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                    <div>
                      <span class="badge badge-${act.verificationStatus}">${act.verificationStatus.replace('_', ' ')}</span>
                      <span class="badge badge-category" style="margin-left: 6px;">${act.category}</span>
                    </div>
                    <div style="font-size: 0.85rem; color: var(--muted-text);">${new Date(act.date).toLocaleDateString()}</div>
                  </div>

                  <h3 style="font-size: 1.2rem; font-weight: 700; color: var(--dark); margin-bottom: 0.4rem;">${act.title}</h3>
                  <p style="font-size: 0.9rem; color: var(--secondary-text); margin-bottom: 0.75rem;">${act.description}</p>
                  
                  <div style="font-size: 0.85rem; color: var(--primary-text); margin-bottom: 0.75rem;">
                    Reported by: <strong>${act.user ? act.user.name : 'Unknown'}</strong> (${act.user?.email || 'N/A'})
                  </div>

                  <!-- Automated Verification Audit Box -->
                  <div style="background: #F8FAFC; border: 1px solid var(--light-border); border-radius: var(--radius-md); padding: 10px 14px; margin-bottom: 1rem; font-size: 0.85rem;">
                    <div style="display: flex; justify-content: space-between; font-weight: 700; margin-bottom: 6px;">
                      <span>Automated Analysis Score:</span>
                      <span style="color: ${audit?.confidence >= 75 ? '#047857' : '#B45309'};">${audit?.confidence || 0}% Confidence</span>
                    </div>
                    <div style="color: var(--secondary-text); font-size: 0.8rem; margin-bottom: 6px;">
                      <em>${audit?.reason || 'Audit checks performed.'}</em>
                    </div>
                    ${checks
                      .map(
                        (c) => `
                      <div style="font-size: 0.78rem; display: flex; gap: 6px; align-items: center;">
                        <span>${c.passed ? '✅' : '⚠️'}</span>
                        <span><strong>${c.name}:</strong> ${c.details}</span>
                      </div>
                    `
                      )
                      .join('')}
                  </div>

                  <div style="display: flex; gap: 0.75rem;">
                    <button class="btn btn-primary btn-sm" onclick="window.admin.handleApprove('${act._id}')">
                      <i data-lucide="check"></i> Approve & Award Impact
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="window.admin.handleReject('${act._id}')">
                      <i data-lucide="x"></i> Reject Proof
                    </button>
                  </div>
                </div>
              </div>
            `;
            })
            .join('')}
        </div>
      `;

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('loadPendingQueue error:', err);
      listEl.innerHTML = '<p style="color: var(--danger);">Failed to load review queue.</p>';
    }
  },

  async handleApprove(actionId) {
    const notes = prompt('Approval notes (optional):', 'Valid photo proof verified');
    if (notes === null) return; // User cancelled prompt

    try {
      const res = await window.api.approveAction(actionId, notes);
      window.app.showToast(res.message, 'success');
      this.loadPendingQueue();
      this.loadStats();
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async handleReject(actionId) {
    const reason = prompt('Please enter rejection reason explaining why the proof is insufficient:', 'Photo proof is unclear or does not verify the claimed action');
    if (!reason || !reason.trim()) {
      window.app.showToast('Rejection reason is required.', 'error');
      return;
    }

    try {
      const res = await window.api.rejectAction(actionId, reason.trim());
      window.app.showToast(res.message, 'info');
      this.loadPendingQueue();
      this.loadStats();
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async loadUsers() {
    const tbody = document.getElementById('admin-users-tbody');
    if (!tbody) return;

    try {
      const res = await window.api.getAdminUsers();
      const users = res.users || [];

      tbody.innerHTML = users
        .map(
          (u) => `
        <tr>
          <td>
            <strong>${u.name}</strong>
            <div style="font-size: 0.75rem; color: var(--muted-text);">${u._id}</div>
          </td>
          <td>${u.email}</td>
          <td><span class="badge ${u.role === 'admin' ? 'badge-under_review' : 'badge-category'}">${u.role}</span></td>
          <td>${u.totalPoints} pts</td>
          <td>${u.totalVerifiedActions}</td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="window.admin.toggleRole('${u._id}')">
              ${u.role === 'admin' ? 'Revoke Admin' : 'Make Admin'}
            </button>
          </td>
        </tr>
      `
        )
        .join('');
    } catch (err) {
      console.error('loadUsers error:', err);
    }
  },

  async toggleRole(userId) {
    try {
      const res = await window.api.toggleUserRole(userId);
      window.app.showToast(res.message, 'success');
      this.loadUsers();
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },
};
