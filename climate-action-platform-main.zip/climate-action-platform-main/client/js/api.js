/**
 * ClimateAction — REST API Client Wrapper
 * Handles all network requests, authentication headers, multipart payloads, and errors.
 */

const API_BASE = '/api';

class ApiClient {
  constructor() {
    this.token = localStorage.getItem('ca_token') || null;
  }

  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('ca_token', token);
    } else {
      localStorage.removeItem('ca_token');
    }
  }

  async request(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const headers = options.headers || {};

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const config = {
      ...options,
      headers,
      credentials: 'include', // Includes HTTP-only cookies
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Request failed with status ' + response.status);
      }

      return data;
    } catch (error) {
      console.error(`API Error on [${options.method || 'GET'}] ${endpoint}:`, error.message);
      throw error;
    }
  }

  get(endpoint, params = {}) {
    const query = new URLSearchParams(params).toString();
    const fullEndpoint = query ? `${endpoint}?${query}` : endpoint;
    return this.request(fullEndpoint, { method: 'GET' });
  }

  post(endpoint, body) {
    return this.request(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  }

  put(endpoint, body) {
    return this.request(endpoint, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  }

  patch(endpoint, body = {}) {
    return this.request(endpoint, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  }

  delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }

  postFormData(endpoint, formData) {
    return this.request(endpoint, {
      method: 'POST',
      body: formData,
    });
  }

  putFormData(endpoint, formData) {
    return this.request(endpoint, {
      method: 'PUT',
      body: formData,
    });
  }

  // ==========================================
  // Auth Endpoints
  // ==========================================
  sendSignupOtp(email) {
    return this.post('/auth/signup-otp', { email });
  }

  verifyAndRegister({ email, otp, name, password, adminSecretKey }) {
    return this.post('/auth/register', { email, otp, name, password, adminSecretKey });
  }

  login(email, password) {
    return this.post('/auth/login', { email, password });
  }

  forgotPassword(email) {
    return this.post('/auth/forgot-password', { email });
  }

  resetPassword({ email, otp, newPassword }) {
    return this.post('/auth/reset-password', { email, otp, newPassword });
  }

  getMe() {
    return this.get('/auth/me');
  }

  logout() {
    this.setToken(null);
    return this.post('/auth/logout');
  }

  // ==========================================
  // User & Profile Endpoints
  // ==========================================
  updateProfile(profileData) {
    return this.put('/users/profile', profileData);
  }

  uploadAvatar(formData) {
    return this.postFormData('/users/avatar', formData);
  }

  getPublicProfile(userId) {
    return this.get(`/users/${userId}`);
  }

  getUserHeatmap(userId) {
    return this.get(userId ? `/users/heatmap/${userId}` : '/users/heatmap');
  }

  // ==========================================
  // Climate Lifestyle Assessment
  // ==========================================
  submitAssessment(assessmentData) {
    return this.post('/assessment', assessmentData);
  }

  getAssessment() {
    return this.get('/assessment');
  }

  // ==========================================
  // Recommendations & Daily Actions
  // ==========================================
  getRecommendations() {
    return this.get('/recommendations');
  }

  getDailyActions() {
    return this.get('/recommendations/daily');
  }

  // ==========================================
  // Climate Actions & Reporting
  // ==========================================
  reportAction(formData) {
    return this.postFormData('/actions/report', formData);
  }

  getActionHistory(params) {
    return this.get('/actions/history', params);
  }

  getActionById(id) {
    return this.get(`/actions/${id}`);
  }

  // ==========================================
  // Environmental Impact & Analytics
  // ==========================================
  getImpactSummary(userId) {
    return this.get('/impact/summary', userId ? { userId } : {});
  }

  getImpactTransactions(params) {
    return this.get('/impact/transactions', params);
  }

  // ==========================================
  // Leaderboards
  // ==========================================
  getGlobalLeaderboard(params) {
    return this.get('/leaderboard/global', params);
  }

  getCommunityLeaderboard(params) {
    return this.get('/leaderboard/communities', params);
  }

  // ==========================================
  // Communities & Social Groups
  // ==========================================
  createCommunity(formData) {
    return this.postFormData('/communities', formData);
  }

  getCommunities(params) {
    return this.get('/communities', params);
  }

  getCommunityById(id) {
    return this.get(`/communities/${id}`);
  }

  joinCommunity(id) {
    return this.post(`/communities/${id}/join`);
  }

  leaveCommunity(id) {
    return this.post(`/communities/${id}/leave`);
  }

  updateCommunity(id, data) {
    return this.put(`/communities/${id}`, data);
  }

  deleteCommunity(id) {
    return this.delete(`/communities/${id}`);
  }

  createPost(formData) {
    return this.postFormData('/communities/posts', formData);
  }

  getCommunityPosts(communityId, params) {
    return this.get(`/communities/${communityId}/posts`, params);
  }

  deletePost(postId) {
    return this.delete(`/communities/posts/${postId}`);
  }

  addComment(postId, content) {
    return this.post(`/communities/posts/${postId}/comments`, { content });
  }

  getComments(postId) {
    return this.get(`/communities/posts/${postId}/comments`);
  }

  toggleReaction(postId, type) {
    return this.post(`/communities/posts/${postId}/react`, { type });
  }

  // ==========================================
  // Follow System
  // ==========================================
  followUser(userId) {
    return this.post(`/social/${userId}`);
  }

  unfollowUser(userId) {
    return this.delete(`/social/${userId}`);
  }

  removeFollower(followerUserId) {
    return this.delete(`/social/follower/${followerUserId}`);
  }

  getFollowers(userId) {
    return this.get(`/social/followers/${userId || ''}`);
  }

  getFollowing(userId) {
    return this.get(`/social/following/${userId || ''}`);
  }

  // ==========================================
  // Notifications
  // ==========================================
  getNotifications(params) {
    return this.get('/notifications', params);
  }

  markNotificationAsRead(id) {
    return this.patch(`/notifications/${id}/read`);
  }

  markAllNotificationsAsRead() {
    return this.patch('/notifications/read-all');
  }

  deleteNotification(id) {
    return this.delete(`/notifications/${id}`);
  }

  // ==========================================
  // Admin Operations
  // ==========================================
  getAdminStats() {
    return this.get('/admin/stats');
  }

  getPendingActions(params) {
    return this.get('/admin/actions/pending', params);
  }

  approveAction(actionId, notes) {
    return this.post(`/admin/actions/${actionId}/approve`, { notes });
  }

  rejectAction(actionId, reason) {
    return this.post(`/admin/actions/${actionId}/reject`, { reason });
  }

  getAdminUsers(params) {
    return this.get('/admin/users', params);
  }

  toggleUserRole(userId) {
    return this.patch(`/admin/users/${userId}/role`);
  }
}

// Export singleton instance
const api = new ApiClient();
window.api = api;
