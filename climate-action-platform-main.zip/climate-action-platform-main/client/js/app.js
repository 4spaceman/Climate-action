/**
 * ClimateAction — Main Application Orchestrator & Client Router
 */

window.app = {
  currentUser: null,
  currentView: 'landing',

  async init() {
    this.bindGlobalEvents();
    window.auth.init();
    window.actions.init();

    // Check existing session
    await this.checkSession();

    // Setup hash-based navigation router
    window.addEventListener('hashchange', () => this.handleRouting());
    this.handleRouting();

    // Start notification badge updates
    if (this.currentUser) {
      this.updateNotifications();
      setInterval(() => this.updateNotifications(), 30000);
    }
  },

  async checkSession() {
    try {
      const res = await window.api.getMe();
      if (res.success && res.user) {
        this.currentUser = res.user;
        this.updateNavAuth();
      }
    } catch (err) {
      this.currentUser = null;
      this.updateNavAuth();
    }
  },

  updateNavAuth() {
    const authLinks = document.getElementById('nav-auth-links');
    const guestLinks = document.getElementById('nav-guest-links');
    const adminLink = document.getElementById('nav-admin-link');
    const navName = document.getElementById('nav-user-name');
    const navAvatar = document.getElementById('nav-user-avatar');

    if (this.currentUser) {
      if (authLinks) authLinks.style.display = 'flex';
      if (guestLinks) guestLinks.style.display = 'none';
      if (navName) navName.textContent = this.currentUser.name.split(' ')[0];
      if (adminLink) adminLink.style.display = this.currentUser.role === 'admin' ? 'flex' : 'none';

      if (navAvatar) {
        if (this.currentUser.avatar) {
          navAvatar.innerHTML = `<img src="${this.currentUser.avatar}" alt="Avatar" class="nav-avatar" />`;
        } else {
          navAvatar.innerHTML = `<div class="nav-avatar-placeholder">${this.currentUser.name.charAt(0).toUpperCase()}</div>`;
        }
      }
    } else {
      if (authLinks) authLinks.style.display = 'none';
      if (guestLinks) guestLinks.style.display = 'flex';
      if (adminLink) adminLink.style.display = 'none';
    }

    if (window.lucide) window.lucide.createIcons();
  },

  navigate(viewName) {
    window.location.hash = `#${viewName}`;
  },

  handleRouting() {
    let hash = window.location.hash.replace('#', '') || 'landing';

    // Route guards
    const protectedViews = [
      'onboarding',
      'assessment',
      'dashboard',
      'actions',
      'report',
      'history',
      'impact',
      'profile',
      'notifications',
      'admin',
    ];

    if (!this.currentUser && protectedViews.includes(hash)) {
      hash = 'login';
    }

    // Hide all view containers
    document.querySelectorAll('.view-container').forEach((el) => {
      el.style.display = 'none';
    });

    // Show active view
    const target = document.getElementById(`view-${hash}`);
    if (target) {
      target.style.display = 'block';
      this.currentView = hash;
      window.scrollTo(0, 0);

      // Trigger view-specific data loaders
      switch (hash) {
        case 'dashboard':
          window.dashboard.render();
          break;
        case 'history':
          window.actions.loadHistory();
          break;
        case 'impact':
          window.impact.render();
          break;
        case 'leaderboard':
          window.leaderboard.render();
          break;
        case 'communities':
          window.communities.render();
          break;
        case 'profile':
          window.profile.render();
          break;
        case 'notifications':
          this.loadNotificationsView();
          break;
        case 'admin':
          window.admin.render();
          break;
      }
    } else {
      // Fallback to landing
      const landing = document.getElementById('view-landing');
      if (landing) landing.style.display = 'block';
    }

    // Update active state in nav
    document.querySelectorAll('.nav-item').forEach((item) => {
      item.classList.remove('active');
      if (item.getAttribute('data-view') === hash) {
        item.classList.add('active');
      }
    });

    if (window.lucide) window.lucide.createIcons();
  },

  bindGlobalEvents() {
    // Mobile navigation toggle
    const mobileBtn = document.getElementById('mobile-menu-toggle');
    const navLinks = document.getElementById('main-nav-links');
    if (mobileBtn && navLinks) {
      mobileBtn.onclick = () => {
        navLinks.classList.toggle('open');
      };
    }

    // Onboarding Form
    const onboardingForm = document.getElementById('onboarding-form');
    if (onboardingForm) {
      onboardingForm.onsubmit = async (e) => {
        e.preventDefault();
        const city = document.getElementById('onboard-city').value.trim();
        const occupation = document.getElementById('onboard-occupation').value;
        const institution = document.getElementById('onboard-institution').value.trim();
        const bio = document.getElementById('onboard-bio').value.trim();

        try {
          const res = await window.api.updateProfile({
            city,
            occupation,
            college: occupation === 'student' ? institution : '',
            company: occupation === 'employee' ? institution : '',
            bio,
          });
          this.currentUser = res.user;
          this.showToast('Profile configured! Let us complete your climate lifestyle assessment.', 'success');
          this.navigate('assessment');
        } catch (err) {
          this.showToast(err.message, 'error');
        }
      };
    }

    // Climate Assessment Form
    const assessmentForm = document.getElementById('climate-assessment-form');
    if (assessmentForm) {
      assessmentForm.onsubmit = async (e) => {
        e.preventDefault();
        const btn = assessmentForm.querySelector('button[type="submit"]');

        try {
          btn.disabled = true;
          btn.innerHTML = 'Computing personalized baseline...';

          const data = {
            transportation: {
              primaryCommute: document.getElementById('assess-commute').value,
              weeklyKm: Number(document.getElementById('assess-commute-km').value) || 30,
            },
            energy: {
              acUsageHoursPerDay: Number(document.getElementById('assess-ac').value) || 2,
              solarPowered: document.getElementById('assess-solar').value === 'true',
              appliancesOffWhenIdle: document.getElementById('assess-standby').value === 'true',
            },
            water: {
              showerDurationMins: Number(document.getElementById('assess-shower').value) || 8,
              runningTapHabit: document.getElementById('assess-tap').value === 'true',
              rainwaterHarvesting: document.getElementById('assess-rainwater').value === 'true',
            },
            food: {
              dietType: document.getElementById('assess-diet').value,
              mealsWithMeatPerWeek: Number(document.getElementById('assess-meat-meals').value) || 5,
              foodWasteFrequency: document.getElementById('assess-food-waste').value,
            },
            waste: {
              recyclePlastics: document.getElementById('assess-recycle').value === 'true',
              singleUseBottlesWeekly: Number(document.getElementById('assess-bottles').value) || 2,
              repairBeforeReplace: document.getElementById('assess-repair').value === 'true',
            },
            nature: {
              plantsTreesAnnually: document.getElementById('assess-trees').value === 'true',
              gardeningOrHouseplants: document.getElementById('assess-plants').value === 'true',
              participatesInCleanups: document.getElementById('assess-cleanups').value === 'true',
            },
            climateAwareness: {
              concernLevel: Number(document.getElementById('assess-concern').value) || 4,
            },
          };

          const res = await window.api.submitAssessment(data);
          this.showToast('Lifestyle assessment complete! Baseline score: ' + res.baselineScore, 'success');
          this.navigate('dashboard');
        } catch (err) {
          this.showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Generate Personalized Recommendations';
        }
      };
    }
  },

  async updateNotifications() {
    try {
      const res = await window.api.getNotifications({ limit: 1 });
      const badge = document.getElementById('nav-notif-badge');
      if (badge) {
        if (res.unreadCount > 0) {
          badge.textContent = res.unreadCount;
          badge.style.display = 'inline-block';
        } else {
          badge.style.display = 'none';
        }
      }
    } catch (err) {}
  },

  async loadNotificationsView() {
    const listEl = document.getElementById('notifications-list');
    if (!listEl) return;

    try {
      listEl.innerHTML = '<div style="text-align: center; padding: 2rem;"><p>Loading notifications...</p></div>';

      const res = await window.api.getNotifications({ limit: 30 });
      const notifications = res.notifications || [];

      if (notifications.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon"><i data-lucide="bell-off"></i></div>
            <h4 class="empty-state-title">You're all caught up!</h4>
            <p class="empty-state-text">No new notifications. We will notify you when your actions are verified or peers interact with your climate journey.</p>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
      }

      listEl.innerHTML = `
        <div style="display: flex; justify-content: flex-end; margin-bottom: 1rem;">
          <button class="btn btn-secondary btn-sm" onclick="window.app.markAllNotificationsRead()">Mark All as Read</button>
        </div>
        <div>
          ${notifications
            .map(
              (n) => `
            <div class="card" style="margin-bottom: 0.75rem; border-left: 4px solid ${n.isRead ? 'var(--light-border)' : 'var(--emerald)'}; background: ${n.isRead ? 'var(--white)' : 'var(--soft-green)'};">
              <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                  <h4 style="font-size: 1rem; font-weight: 700; color: var(--dark); margin-bottom: 0.25rem;">${n.title}</h4>
                  <p style="font-size: 0.9rem; color: var(--secondary-text);">${n.message}</p>
                  <span style="font-size: 0.75rem; color: var(--muted-text); margin-top: 4px; display: inline-block;">${new Date(n.createdAt).toLocaleString()}</span>
                </div>
                ${!n.isRead ? `<button class="btn btn-sm btn-soft" onclick="window.app.markNotificationRead('${n._id}')">Mark Read</button>` : ''}
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      `;

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      listEl.innerHTML = '<p style="color: var(--danger);">Failed to load notifications.</p>';
    }
  },

  async markNotificationRead(id) {
    try {
      await window.api.markNotificationAsRead(id);
      this.loadNotificationsView();
      this.updateNotifications();
    } catch (err) {}
  },

  async markAllNotificationsRead() {
    try {
      await window.api.markAllNotificationsAsRead();
      this.loadNotificationsView();
      this.updateNotifications();
      this.showToast('All notifications marked as read', 'info');
    } catch (err) {}
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span>${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
      <div style="flex: 1;">${message}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  },
};

// Initialize App when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app.init();
});
