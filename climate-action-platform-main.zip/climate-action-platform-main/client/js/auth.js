/**
 * ClimateAction — Authentication Controller (Frontend)
 * Handles Sign Up, OTP Verification, Login, Forgot Password, and Logout.
 */

window.auth = {
  // Temporary storage during signup/reset flows
  pendingEmail: '',

  // Initialize Auth event listeners
  init() {
    this.bindEvents();
  },

  bindEvents() {
    // 1. Signup Step 1: Request OTP
    const signupOtpForm = document.getElementById('signup-otp-form');
    if (signupOtpForm) {
      signupOtpForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const emailInput = document.getElementById('signup-email');
        const email = emailInput.value.trim();
        const btn = signupOtpForm.querySelector('button[type="submit"]');

        try {
          btn.disabled = true;
          btn.innerHTML = 'Sending Code...';
          const res = await window.api.sendSignupOtp(email);
          this.pendingEmail = email;
          window.app.showToast(res.message, 'success');

          // If Ethereal test account returned preview URL, notify in development
          if (res.previewUrl) {
            console.log('✉️ Dev Mailbox Preview:', res.previewUrl);
            window.app.showToast(`Dev OTP preview available in console`, 'info');
          }

          // Move to Step 2: OTP verification form
          document.getElementById('signup-step-1').style.display = 'none';
          document.getElementById('signup-step-2').style.display = 'block';
          document.getElementById('verify-email-display').textContent = email;
          document.getElementById('verify-otp').focus();
        } catch (err) {
          window.app.showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Continue & Send OTP';
        }
      });
    }

    // 2. Signup Step 2: Verify OTP & Create Account
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
      registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const otp = document.getElementById('verify-otp').value.trim();
        const name = document.getElementById('register-name').value.trim();
        const password = document.getElementById('register-password').value;
        const adminKey = document.getElementById('register-adminkey')?.value.trim();
        const btn = registerForm.querySelector('button[type="submit"]');

        try {
          btn.disabled = true;
          btn.innerHTML = 'Creating Account...';
          const res = await window.api.verifyAndRegister({
            email: this.pendingEmail,
            otp,
            name,
            password,
            adminSecretKey: adminKey,
          });

          window.api.setToken(res.token);
          window.app.currentUser = res.user;
          window.app.showToast(res.message, 'success');

          // Transition to Onboarding / Climate Assessment
          window.app.updateNavAuth();
          window.app.navigate('onboarding');
        } catch (err) {
          window.app.showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Verify & Complete Registration';
        }
      });
    }

    // 3. Resend OTP button
    const resendBtn = document.getElementById('resend-otp-btn');
    if (resendBtn) {
      resendBtn.addEventListener('click', async () => {
        if (!this.pendingEmail) return;
        try {
          resendBtn.disabled = true;
          resendBtn.textContent = 'Resending...';
          const res = await window.api.sendSignupOtp(this.pendingEmail);
          window.app.showToast('A new 6-digit code has been sent!', 'success');
          if (res.previewUrl) console.log('✉️ Dev Mailbox Preview:', res.previewUrl);
        } catch (err) {
          window.app.showToast(err.message, 'error');
        } finally {
          resendBtn.disabled = false;
          resendBtn.textContent = 'Resend Code';
        }
      });
    }

    // 4. Login Form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;
        const btn = loginForm.querySelector('button[type="submit"]');

        try {
          btn.disabled = true;
          btn.innerHTML = 'Logging in...';
          const res = await window.api.login(email, password);

          window.api.setToken(res.token);
          window.app.currentUser = res.user;
          window.app.showToast('Welcome back, ' + res.user.name + '!', 'success');

          window.app.updateNavAuth();

          if (!res.user.isOnboarded) {
            window.app.navigate('onboarding');
          } else if (!res.user.hasCompletedAssessment) {
            window.app.navigate('assessment');
          } else {
            window.app.navigate('dashboard');
          }
        } catch (err) {
          window.app.showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Sign In';
        }
      });
    }

    // 5. Forgot Password Step 1
    const forgotForm = document.getElementById('forgot-password-form');
    if (forgotForm) {
      forgotForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('forgot-email').value.trim();
        const btn = forgotForm.querySelector('button[type="submit"]');

        try {
          btn.disabled = true;
          btn.innerHTML = 'Sending Code...';
          const res = await window.api.forgotPassword(email);
          this.pendingEmail = email;
          window.app.showToast(res.message, 'success');

          if (res.previewUrl) console.log('✉️ Dev Reset Preview:', res.previewUrl);

          document.getElementById('forgot-step-1').style.display = 'none';
          document.getElementById('forgot-step-2').style.display = 'block';
          document.getElementById('reset-email-display').textContent = email;
          document.getElementById('reset-otp').focus();
        } catch (err) {
          window.app.showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Send Reset Code';
        }
      });
    }

    // 6. Forgot Password Step 2: Reset Password with OTP
    const resetForm = document.getElementById('reset-password-form');
    if (resetForm) {
      resetForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const otp = document.getElementById('reset-otp').value.trim();
        const newPassword = document.getElementById('reset-new-password').value;
        const btn = resetForm.querySelector('button[type="submit"]');

        try {
          btn.disabled = true;
          btn.innerHTML = 'Resetting Password...';
          const res = await window.api.resetPassword({
            email: this.pendingEmail,
            otp,
            newPassword,
          });

          window.app.showToast(res.message, 'success');
          // Switch to login view
          window.app.navigate('login');
        } catch (err) {
          window.app.showToast(err.message, 'error');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Set New Password';
        }
      });
    }
  },

  async handleLogout() {
    try {
      await window.api.logout();
    } catch (err) {
      console.warn('Logout notification error:', err);
    }
    window.app.currentUser = null;
    window.app.updateNavAuth();
    window.app.showToast('You have been logged out.', 'info');
    window.app.navigate('landing');
  },
};
