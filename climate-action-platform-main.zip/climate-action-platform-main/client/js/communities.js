/**
 * ClimateAction — Communities Controller (Frontend)
 * Handles discovering, creating, joining communities, post feeds, comments, and reactions.
 */

window.communities = {
  currentCommunityId: null,

  async render() {
    this.bindEvents();
    await this.loadCommunitiesList();
  },

  bindEvents() {
    const searchInput = document.getElementById('communities-search');
    if (searchInput) {
      let debounceTimer;
      searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => this.loadCommunitiesList(), 300);
      });
    }

    const createForm = document.getElementById('create-community-form');
    if (createForm) {
      createForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleCreateCommunity();
      });
    }
  },

  async loadCommunitiesList() {
    const listEl = document.getElementById('communities-grid');
    if (!listEl) return;

    const search = document.getElementById('communities-search')?.value.trim() || '';

    try {
      listEl.innerHTML = '<div style="text-align: center; padding: 2rem;"><p>Loading communities...</p></div>';

      const res = await window.api.getCommunities({ search });
      const communities = res.communities || [];

      if (communities.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state" style="grid-column: 1 / -1;">
            <div class="empty-state-icon"><i data-lucide="users"></i></div>
            <h4 class="empty-state-title">No Communities Found</h4>
            <p class="empty-state-text">Be the first environmental leader to launch a local or topical sustainability group!</p>
            <button class="btn btn-primary" onclick="window.communities.openCreateModal()">Create A Community</button>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
      }

      listEl.innerHTML = communities
        .map(
          (c) => `
        <div class="card card-hover" style="display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
              <span class="badge badge-category">${c.category}</span>
              <span style="font-size: 0.85rem; font-weight: 700; color: #047857;">+${c.totalPoints} pts</span>
            </div>
            <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--dark); margin-bottom: 0.5rem; cursor: pointer;" onclick="window.communities.openCommunity('${c._id}')">
              ${c.name}
            </h3>
            <p style="font-size: 0.9rem; color: var(--secondary-text); margin-bottom: 1.25rem; line-height: 1.5;">${c.description}</p>
          </div>

          <div>
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--light-border); padding-top: 0.75rem; margin-bottom: 0.75rem; font-size: 0.85rem; color: var(--secondary-text);">
              <span>👥 <strong>${c.memberCount}</strong> Member${c.memberCount === 1 ? '' : 's'}</span>
              <span>~${(c.totalCO2Avoided || 0).toFixed(0)} kg CO2</span>
            </div>
            <div style="display: flex; gap: 0.5rem;">
              <button class="btn btn-primary btn-sm btn-block" onclick="window.communities.openCommunity('${c._id}')">View Community</button>
              ${
                c.isMember
                  ? `<span class="badge badge-approved" style="align-self: center;">Joined</span>`
                  : `<button class="btn btn-soft btn-sm" onclick="window.communities.quickJoin('${c._id}')">Join</button>`
              }
            </div>
          </div>
        </div>
      `
        )
        .join('');

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('loadCommunitiesList error:', err);
      listEl.innerHTML = '<p style="color: var(--danger);">Failed to load communities.</p>';
    }
  },

  openCreateModal() {
    const modal = document.getElementById('create-community-modal');
    if (modal) modal.style.display = 'flex';
  },

  closeCreateModal() {
    const modal = document.getElementById('create-community-modal');
    if (modal) modal.style.display = 'none';
  },

  async handleCreateCommunity() {
    const name = document.getElementById('comm-name').value.trim();
    const category = document.getElementById('comm-category').value;
    const description = document.getElementById('comm-desc').value.trim();

    try {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('category', category);
      formData.append('description', description);

      const res = await window.api.createCommunity(formData);
      window.app.showToast(res.message, 'success');
      this.closeCreateModal();
      document.getElementById('create-community-form').reset();
      this.openCommunity(res.community._id);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async quickJoin(communityId) {
    try {
      const res = await window.api.joinCommunity(communityId);
      window.app.showToast(res.message, 'success');
      this.loadCommunitiesList();
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async openCommunity(communityId) {
    this.currentCommunityId = communityId;
    window.app.navigate('community-detail');

    try {
      const [commRes, postsRes] = await Promise.all([
        window.api.getCommunityById(communityId),
        window.api.getCommunityPosts(communityId),
      ]);

      const comm = commRes.community;
      const isMember = commRes.isMember;
      const isAdmin = commRes.isAdmin;
      const posts = postsRes.posts || [];

      // Render Header
      document.getElementById('cd-name').textContent = comm.name;
      document.getElementById('cd-category').textContent = comm.category;
      document.getElementById('cd-desc').textContent = comm.description;
      document.getElementById('cd-members-count').textContent = comm.memberCount;
      document.getElementById('cd-points').textContent = comm.totalPoints;
      document.getElementById('cd-co2').textContent = `${(comm.totalCO2Avoided || 0).toFixed(1)} kg`;

      // Membership Action Button
      const actionBtnContainer = document.getElementById('cd-action-btn-container');
      if (isAdmin) {
        actionBtnContainer.innerHTML = `
          <button class="btn btn-danger btn-sm" onclick="window.communities.deleteCommunity('${comm._id}')">Delete Community</button>
        `;
      } else if (isMember) {
        actionBtnContainer.innerHTML = `
          <button class="btn btn-secondary btn-sm" onclick="window.communities.leaveCommunity('${comm._id}')">Leave Community</button>
        `;
      } else {
        actionBtnContainer.innerHTML = `
          <button class="btn btn-primary btn-sm" onclick="window.communities.joinCurrentCommunity('${comm._id}')">Join Community</button>
        `;
      }

      // Render Post Creation box
      const postBox = document.getElementById('cd-create-post-box');
      if (postBox) {
        postBox.style.display = isMember ? 'block' : 'none';
      }

      // Render Posts
      this.renderPosts(posts, isAdmin);

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('openCommunity error:', err);
      window.app.showToast('Failed to load community details.', 'error');
    }
  },

  async joinCurrentCommunity(id) {
    try {
      const res = await window.api.joinCommunity(id);
      window.app.showToast(res.message, 'success');
      this.openCommunity(id);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async leaveCommunity(id) {
    if (!confirm('Are you sure you want to leave this community?')) return;
    try {
      const res = await window.api.leaveCommunity(id);
      window.app.showToast(res.message, 'info');
      this.openCommunity(id);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async deleteCommunity(id) {
    if (!confirm('Are you sure you want to delete this community? All posts will be removed.')) return;
    try {
      const res = await window.api.deleteCommunity(id);
      window.app.showToast(res.message, 'success');
      window.app.navigate('communities');
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async submitPost() {
    const content = document.getElementById('post-content').value.trim();
    const photoInput = document.getElementById('post-photo-input');

    if (!content) {
      window.app.showToast('Post content cannot be empty.', 'error');
      return;
    }

    try {
      const formData = new FormData();
      formData.append('communityId', this.currentCommunityId);
      formData.append('content', content);
      if (photoInput && photoInput.files[0]) {
        formData.append('photo', photoInput.files[0]);
      }

      const res = await window.api.createPost(formData);
      window.app.showToast('Post shared!', 'success');
      document.getElementById('post-content').value = '';
      if (photoInput) photoInput.value = '';
      this.openCommunity(this.currentCommunityId);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  renderPosts(posts, isCommunityAdmin) {
    const feed = document.getElementById('cd-posts-feed');
    if (!feed) return;

    if (!posts || posts.length === 0) {
      feed.innerHTML = `
        <div class="empty-state" style="padding: 2rem 1rem;">
          <div class="empty-state-icon"><i data-lucide="message-square"></i></div>
          <h4 class="empty-state-title">No Discussions Yet</h4>
          <p class="empty-state-text">Start the conversation by sharing a climate tip, habit update, or photo!</p>
        </div>
      `;
      return;
    }

    feed.innerHTML = posts
      .map(
        (p) => `
      <div class="card" style="margin-bottom: 1.25rem;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
          <div style="display: flex; align-items: center; gap: 0.75rem; cursor: pointer;" onclick="window.profile.openProfile('${p.author._id}')">
            <div class="nav-avatar-placeholder" style="width: 38px; height: 38px;">
              ${p.author.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div style="font-weight: 700; color: var(--dark);">${p.author.name}</div>
              <div style="font-size: 0.75rem; color: var(--muted-text);">${new Date(p.createdAt).toLocaleDateString()}</div>
            </div>
          </div>

          ${
            p.isAuthor || isCommunityAdmin
              ? `<button class="btn btn-secondary btn-sm" onclick="window.communities.deletePost('${p._id}')" title="Delete post">&times;</button>`
              : ''
          }
        </div>

        <p style="font-size: 0.95rem; line-height: 1.5; color: var(--primary-text); margin-bottom: 0.75rem;">${p.content}</p>

        ${
          p.photo
            ? `<img src="${p.photo}" alt="Post proof" style="width: 100%; max-height: 380px; object-fit: cover; border-radius: var(--radius-md); margin-bottom: 0.75rem;" />`
            : ''
        }

        <div style="display: flex; align-items: center; gap: 1rem; border-top: 1px solid var(--light-border); padding-top: 0.75rem; margin-top: 0.5rem;">
          <button class="btn btn-sm ${p.userReaction ? 'btn-primary' : 'btn-secondary'}" onclick="window.communities.reactToPost('${p._id}', 'seedling')">
            🌱 ${p.likesCount || 0}
          </button>
          <button class="btn btn-secondary btn-sm" onclick="window.communities.toggleComments('${p._id}')">
            💬 ${p.commentsCount || 0} Comments
          </button>
        </div>

        <div id="comments-box-${p._id}" style="display: none; margin-top: 1rem; border-top: 1px dashed var(--light-border); padding-top: 1rem;">
          <div id="comments-list-${p._id}"></div>
          <div style="display: flex; gap: 0.5rem; margin-top: 0.75rem;">
            <input type="text" class="form-control" id="comment-input-${p._id}" placeholder="Write a supportive reply..." style="padding: 0.5rem 0.75rem; font-size: 0.85rem;" />
            <button class="btn btn-primary btn-sm" onclick="window.communities.submitComment('${p._id}')">Reply</button>
          </div>
        </div>
      </div>
    `
      )
      .join('');
  },

  async deletePost(postId) {
    if (!confirm('Delete this post?')) return;
    try {
      await window.api.deletePost(postId);
      window.app.showToast('Post removed.', 'info');
      this.openCommunity(this.currentCommunityId);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async reactToPost(postId, type) {
    try {
      await window.api.toggleReaction(postId, type);
      this.openCommunity(this.currentCommunityId);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async toggleComments(postId) {
    const box = document.getElementById(`comments-box-${postId}`);
    if (!box) return;

    if (box.style.display === 'none') {
      box.style.display = 'block';
      await this.loadComments(postId);
    } else {
      box.style.display = 'none';
    }
  },

  async loadComments(postId) {
    const listEl = document.getElementById(`comments-list-${postId}`);
    if (!listEl) return;

    try {
      const res = await window.api.getComments(postId);
      const comments = res.comments || [];

      if (comments.length === 0) {
        listEl.innerHTML = '<p style="font-size: 0.85rem; color: var(--muted-text);">No comments yet.</p>';
        return;
      }

      listEl.innerHTML = comments
        .map(
          (c) => `
        <div style="background: var(--light); padding: 8px 12px; border-radius: var(--radius-sm); margin-bottom: 6px; font-size: 0.85rem;">
          <strong>${c.author.name}:</strong> <span>${c.content}</span>
        </div>
      `
        )
        .join('');
    } catch (err) {
      listEl.innerHTML = '<p style="font-size: 0.8rem; color: var(--danger);">Failed to load comments.</p>';
    }
  },

  async submitComment(postId) {
    const input = document.getElementById(`comment-input-${postId}`);
    if (!input || !input.value.trim()) return;

    try {
      await window.api.addComment(postId, input.value.trim());
      input.value = '';
      await this.loadComments(postId);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },
};
