/**
 * ClimateAction — Dashboard Controller (Frontend)
 * Renders real metrics, GitHub-style activity heatmap, score gauge, daily recommendations, and recent actions.
 */

window.dashboard = {
  async render() {
    const container = document.getElementById('view-dashboard');
    if (!container) return;

    try {
      // Fetch fresh user data and impact summary in parallel
      const [meRes, impactRes, recoRes, actionsRes] = await Promise.all([
        window.api.getMe(),
        window.api.getImpactSummary(),
        window.api.getDailyActions(),
        window.api.getActionHistory({ limit: 4 }),
      ]);

      const user = meRes.user;
      window.app.currentUser = user;
      const totals = impactRes.totals;
      const heatmap = impactRes.heatmapData || {};
      const recommendations = recoRes.dailyActions || [];
      const recentActions = actionsRes.actions || [];

      // Update Greeting
      document.getElementById('dash-greeting').textContent = `Welcome back, ${user.name.split(' ')[0]}! 🌱`;

      // Update Top Metric Stat Cards
      document.getElementById('dash-streak').textContent = `${totals.currentStreak || 0} Days`;
      document.getElementById('dash-longest-streak').textContent = `Best: ${totals.longestStreak || 0} d`;
      document.getElementById('dash-points').textContent = `${totals.totalPoints || 0} pts`;
      document.getElementById('dash-actions-count').textContent = totals.totalVerifiedActions || 0;
      document.getElementById('dash-co2').textContent = `${(totals.totalCO2AvoidedKg || 0).toFixed(1)} kg`;
      document.getElementById('dash-water').textContent = `${(totals.totalWaterSavedLitres || 0).toFixed(0)} L`;

      // Render Climate Action Score Gauge
      const score = totals.climateActionScore || 0;
      const scoreCircle = document.getElementById('dash-score-circle');
      if (scoreCircle) {
        scoreCircle.style.setProperty('--score-pct', score);
        document.getElementById('dash-score-val').textContent = score;
      }

      // Render GitHub-Style Activity Heatmap
      this.renderHeatmap(heatmap);

      // Render Daily Recommendations
      this.renderRecommendations(recommendations);

      // Render Recent Actions List
      this.renderRecentActions(recentActions);

      // Refresh Lucide icons
      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('Error rendering dashboard:', err);
      window.app.showToast('Failed to load dashboard metrics.', 'error');
    }
  },

  renderHeatmap(heatmapData) {
    const grid = document.getElementById('dashboard-heatmap-grid');
    if (!grid) return;
    grid.innerHTML = '';

    // Generate past 364 days (52 weeks x 7 days)
    const today = new Date();
    const daysToShow = 52 * 7;
    const startDate = new Date();
    startDate.setDate(today.getDate() - daysToShow + 1);

    for (let i = 0; i < daysToShow; i++) {
      const d = new Date(startDate);
      d.setDate(startDate.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];

      const dayEl = document.createElement('div');
      dayEl.className = 'heatmap-day';

      const entry = heatmapData[dateStr];
      const level = entry ? entry.level : 0;
      dayEl.setAttribute('data-level', level);

      const titleText = entry
        ? `${dateStr}: ${entry.count} action(s), +${entry.points} pts, ~${entry.co2} kg CO2`
        : `${dateStr}: No verified actions`;
      dayEl.title = titleText;

      grid.appendChild(dayEl);
    }
  },

  renderRecommendations(recommendations) {
    const container = document.getElementById('dash-recommendations-list');
    if (!container) return;

    if (!recommendations || recommendations.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="padding: 2rem 1rem;">
          <div class="empty-state-icon"><i data-lucide="check-circle"></i></div>
          <h4 class="empty-state-title">All Caught Up!</h4>
          <p class="empty-state-text">You have completed your primary daily recommendations. Feel free to report any genuine sustainability action anytime!</p>
          <button class="btn btn-primary" onclick="window.app.navigate('report')">Report An Action</button>
        </div>
      `;
      return;
    }

    container.innerHTML = recommendations
      .map(
        (rec) => `
        <div class="card card-hover" style="display: flex; flex-direction: column; justify-content: space-between; border-left: 4px solid var(--emerald);">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
              <span class="badge badge-category">${rec.category}</span>
              <span style="font-weight: 700; color: var(--emerald-dark); font-size: 0.85rem;">+${rec.potentialPoints} pts</span>
            </div>
            <h4 style="font-size: 1.05rem; font-weight: 700; color: var(--dark); margin-bottom: 0.4rem;">${rec.title}</h4>
            <p style="font-size: 0.88rem; color: var(--secondary-text); margin-bottom: 0.75rem; line-height: 1.4;">${rec.description}</p>
            <div style="font-size: 0.78rem; color: #047857; background: var(--soft-green); padding: 4px 8px; border-radius: 4px; margin-bottom: 1rem;">
              💡 <em>${rec.sourceHabit}</em>
            </div>
          </div>
          <button class="btn btn-soft btn-sm btn-block" onclick="window.actions.prefillReport('${encodeURIComponent(rec.title)}', '${rec.category}', '${encodeURIComponent(rec.description)}')">
            <i data-lucide="camera" style="width: 16px; height: 16px;"></i> Complete & Report Proof
          </button>
        </div>
      `
      )
      .join('');
  },

  renderRecentActions(actions) {
    const container = document.getElementById('dash-recent-actions-list');
    if (!container) return;

    if (!actions || actions.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon"><i data-lucide="leaf"></i></div>
          <h4 class="empty-state-title">No Actions Reported Yet</h4>
          <p class="empty-state-text">You haven't reported any climate actions yet. Complete your first action with photo proof to start earning points and building your streak!</p>
          <button class="btn btn-primary" onclick="window.app.navigate('report')">Report Your First Action</button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="grid-2">
        ${actions
          .map(
            (act) => `
          <div class="card" style="display: flex; gap: 1rem; align-items: center;">
            <img src="${act.photoProof}" alt="${act.title}" style="width: 80px; height: 80px; border-radius: var(--radius-md); object-fit: cover; flex-shrink: 0; background: #E2E8F0;" />
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
                <span class="badge badge-${act.verificationStatus}">${act.verificationStatus.replace('_', ' ')}</span>
                <span style="font-size: 0.8rem; color: var(--muted-text);">${new Date(act.date).toLocaleDateString()}</span>
              </div>
              <h4 style="font-size: 0.98rem; font-weight: 700; color: var(--dark); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${act.title}</h4>
              <p style="font-size: 0.82rem; color: var(--secondary-text); margin-top: 2px;">
                ${act.verificationStatus === 'approved' ? `+${act.pointsEarned} pts &bull; ~${act.impact?.co2AvoidedKg || 0} kg CO2` : act.rejectionReason || 'Under automated & admin review'}
              </p>
            </div>
          </div>
        `
          )
          .join('')}
      </div>
      <div style="text-align: center; margin-top: 1.5rem;">
        <button class="btn btn-secondary btn-sm" onclick="window.app.navigate('history')">View Full Action History &rarr;</button>
      </div>
    `;
  },
};
