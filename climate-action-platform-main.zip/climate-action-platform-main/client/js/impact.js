/**
 * ClimateAction — Impact Analytics Controller (Frontend)
 * Renders Chart.js donut breakdown, transparent environmental estimates, score components, and transaction logs.
 */

window.impact = {
  chartInstance: null,

  async render() {
    try {
      const [summaryRes, transRes] = await Promise.all([
        window.api.getImpactSummary(),
        window.api.getImpactTransactions({ limit: 15 }),
      ]);

      const totals = summaryRes.totals || {};
      const breakdown = summaryRes.categoryBreakdown || [];
      const transactions = transRes.transactions || [];

      // Update Top Metrics
      document.getElementById('impact-total-co2').textContent = `${(totals.totalCO2AvoidedKg || 0).toFixed(2)} kg`;
      document.getElementById('impact-total-water').textContent = `${(totals.totalWaterSavedLitres || 0).toFixed(0)} L`;
      document.getElementById('impact-total-energy').textContent = `${(totals.totalEnergyReducedKwh || 0).toFixed(1)} kWh`;
      document.getElementById('impact-total-waste').textContent = `${(totals.totalWasteAvoidedKg || 0).toFixed(2)} kg`;
      document.getElementById('impact-total-points').textContent = totals.totalPoints || 0;
      document.getElementById('impact-total-actions').textContent = totals.totalVerifiedActions || 0;

      // Render Score Breakdown
      const scoreBreakdown = totals.scoreBreakdown || {};
      document.getElementById('score-factor-actions').textContent = `${scoreBreakdown.actionsScore || 0} / 30`;
      document.getElementById('score-factor-streak').textContent = `${scoreBreakdown.streakScore || 0} / 25`;
      document.getElementById('score-factor-diversity').textContent = `${scoreBreakdown.diversityScore || 0} / 20`;
      document.getElementById('score-factor-impact').textContent = `${scoreBreakdown.impactScore || 0} / 15`;
      document.getElementById('score-factor-engagement').textContent = `${scoreBreakdown.engagementScore || 0} / 10`;

      // Render Chart.js Donut Chart
      this.renderChart(breakdown);

      // Render Sector Impact Table
      this.renderSectorTable(breakdown);

      // Render Traceable Transactions Log
      this.renderTransactions(transactions);

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('Impact render error:', err);
      window.app.showToast('Failed to load impact analytics.', 'error');
    }
  },

  renderChart(breakdown) {
    const canvas = document.getElementById('impact-donut-chart');
    if (!canvas || !window.Chart) return;

    // Filter categories with actions or points
    const activeCategories = breakdown.filter((b) => b.count > 0 || b.points > 0);

    const labels = activeCategories.length > 0 ? activeCategories.map((b) => b.label) : ['No Verified Actions Yet'];
    const data = activeCategories.length > 0 ? activeCategories.map((b) => b.points) : [1];
    const colors = [
      '#10B981', // Emerald
      '#3B82F6', // Blue
      '#F59E0B', // Amber
      '#8B5CF6', // Purple
      '#EC4899', // Pink
      '#14532D', // Deep Green
      '#06B6D4', // Cyan
      '#64748B', // Slate
    ];

    if (this.chartInstance) {
      this.chartInstance.destroy();
    }

    const ctx = canvas.getContext('2d');
    this.chartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [
          {
            data: data,
            backgroundColor: activeCategories.length > 0 ? colors.slice(0, labels.length) : ['#E2E8F0'],
            borderWidth: 2,
            borderColor: '#FFFFFF',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              padding: 16,
              font: { family: 'inherit', size: 12 },
            },
          },
          tooltip: {
            callbacks: {
              label: function (context) {
                if (activeCategories.length === 0) return 'Complete actions to populate chart';
                return ` ${context.label}: ${context.raw} points`;
              },
            },
          },
        },
        cutout: '70%',
      },
    });
  },

  renderSectorTable(breakdown) {
    const tbody = document.getElementById('impact-sectors-tbody');
    if (!tbody) return;

    tbody.innerHTML = breakdown
      .map(
        (b) => `
        <tr>
          <td><strong>${b.label}</strong></td>
          <td>${b.count}</td>
          <td><span style="font-weight: 700; color: #047857;">+${b.points}</span></td>
          <td>${b.co2Avoided} kg</td>
          <td>${b.waterSaved > 0 ? `${b.waterSaved} L` : b.wasteAvoided > 0 ? `${b.wasteAvoided} kg waste` : b.energyReduced > 0 ? `${b.energyReduced} kWh` : '-'}</td>
        </tr>
      `
      )
      .join('');
  },

  renderTransactions(transactions) {
    const list = document.getElementById('impact-transactions-list');
    if (!list) return;

    if (!transactions || transactions.length === 0) {
      list.innerHTML = `
        <div class="empty-state" style="padding: 2rem 1rem;">
          <p class="empty-state-text">No points awarded yet. Report and verify genuine climate actions to log traceable impact transactions.</p>
        </div>
      `;
      return;
    }

    list.innerHTML = `
      <div style="overflow-x: auto;">
        <table class="leaderboard-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Action</th>
              <th>Category</th>
              <th>Points Awarded</th>
              <th>Estimated Benefit</th>
            </tr>
          </thead>
          <tbody>
            ${transactions
              .map(
                (tx) => `
              <tr>
                <td style="color: var(--secondary-text); font-size: 0.85rem;">${new Date(tx.createdAt).toLocaleDateString()}</td>
                <td><strong>${tx.action ? tx.action.title : 'Verified Action'}</strong></td>
                <td><span class="badge badge-category">${tx.category}</span></td>
                <td><span style="font-weight: 800; color: #047857;">+${tx.points} pts</span></td>
                <td style="font-size: 0.85rem; color: var(--secondary-text);">${tx.calculationNotes || '~' + (tx.co2AvoidedKg || 0) + ' kg CO2'}</td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>
      </div>
    `;
  },
};
