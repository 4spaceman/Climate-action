/**
 * ClimateAction — Leaderboard Controller (Frontend)
 * Renders verified global rankings with tie-breaking and community rankings.
 */

window.leaderboard = {
  activeTab: 'global', // 'global' or 'communities'

  async render() {
    this.bindEvents();
    if (this.activeTab === 'global') {
      await this.loadGlobal();
    } else {
      await this.loadCommunities();
    }
  },

  bindEvents() {
    const globalBtn = document.getElementById('lb-tab-global');
    const commBtn = document.getElementById('lb-tab-communities');

    if (globalBtn) {
      globalBtn.onclick = () => {
        this.activeTab = 'global';
        globalBtn.className = 'btn btn-primary btn-sm';
        if (commBtn) commBtn.className = 'btn btn-secondary btn-sm';
        this.loadGlobal();
      };
    }

    if (commBtn) {
      commBtn.onclick = () => {
        this.activeTab = 'communities';
        commBtn.className = 'btn btn-primary btn-sm';
        if (globalBtn) globalBtn.className = 'btn btn-secondary btn-sm';
        this.loadCommunities();
      };
    }
  },

  async loadGlobal() {
    const container = document.getElementById('leaderboard-content');
    if (!container) return;

    try {
      container.innerHTML = '<div style="text-align: center; padding: 2rem;"><p>Loading global rankings...</p></div>';

      const res = await window.api.getGlobalLeaderboard();
      const users = res.leaderboard || [];
      const currentRank = res.currentUserRank;

      if (users.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon"><i data-lucide="award"></i></div>
            <h4 class="empty-state-title">No Leaderboard Data Yet</h4>
            <p class="empty-state-text">Complete verified climate actions to be the first champion on the worldwide leaderboard!</p>
            <button class="btn btn-primary" onclick="window.app.navigate('report')">Report Your Action</button>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
      }

      let userHighlightHtml = '';
      if (currentRank) {
        userHighlightHtml = `
          <div class="card" style="background: var(--soft-green); border: 1px solid var(--soft-green-border); margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between;">
            <div>
              <span style="font-size: 0.85rem; font-weight: 700; color: #047857; text-transform: uppercase;">Your Global Position</span>
              <div style="font-size: 1.4rem; font-weight: 800; color: var(--deep-green);">Worldwide Rank #${currentRank.rank} &bull; ${currentRank.totalPoints} Impact Points</div>
            </div>
            <button class="btn btn-deep btn-sm" onclick="window.app.navigate('report')">Earn More Points</button>
          </div>
        `;
      }

      container.innerHTML = `
        ${userHighlightHtml}
        <div style="overflow-x: auto;">
          <table class="leaderboard-table">
            <thead>
              <tr>
                <th style="width: 70px;">Rank</th>
                <th>Participant</th>
                <th>Location</th>
                <th>Streak</th>
                <th>Actions</th>
                <th>Score</th>
                <th>Impact Points</th>
              </tr>
            </thead>
            <tbody>
              ${users
                .map((u) => {
                  const isCurrent = window.app.currentUser && window.app.currentUser._id === u._id;
                  let rankClass = 'rank-default';
                  if (u.rank === 1) rankClass = 'rank-1';
                  else if (u.rank === 2) rankClass = 'rank-2';
                  else if (u.rank === 3) rankClass = 'rank-3';

                  return `
                  <tr class="${isCurrent ? 'current-user-row' : ''}">
                    <td>
                      <span class="rank-badge ${rankClass}">#${u.rank}</span>
                    </td>
                    <td>
                      <div style="display: flex; align-items: center; gap: 0.75rem; cursor: pointer;" onclick="window.profile.openProfile('${u._id}')">
                        <div class="nav-avatar-placeholder" style="width: 34px; height: 34px; font-size: 0.85rem;">
                          ${u.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div style="font-weight: 700; color: var(--dark);">${u.name} ${isCurrent ? '<span style="font-size: 0.75rem; color: #047857;">(You)</span>' : ''}</div>
                          <div style="font-size: 0.75rem; color: var(--muted-text);">${u.occupation || 'Climate Steward'}</div>
                        </div>
                      </div>
                    </td>
                    <td style="color: var(--secondary-text);">${u.city || 'Global'}</td>
                    <td><span style="font-weight: 700; color: #D97706;">🔥 ${u.currentStreak || 0}d</span></td>
                    <td>${u.totalVerifiedActions || 0}</td>
                    <td><span style="font-weight: 700; color: var(--emerald-dark);">${u.climateActionScore || 0}/100</span></td>
                    <td><span style="font-size: 1.1rem; font-weight: 800; color: #047857;">${u.totalPoints} pts</span></td>
                  </tr>
                `;
                })
                .join('')}
            </tbody>
          </table>
        </div>
      `;

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('loadGlobal error:', err);
      container.innerHTML = '<p style="color: var(--danger);">Failed to load global leaderboard.</p>';
    }
  },

  async loadCommunities() {
    const container = document.getElementById('leaderboard-content');
    if (!container) return;

    try {
      container.innerHTML = '<div style="text-align: center; padding: 2rem;"><p>Loading community rankings...</p></div>';

      const res = await window.api.getCommunityLeaderboard();
      const communities = res.communities || [];

      if (communities.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <div class="empty-state-icon"><i data-lucide="users"></i></div>
            <h4 class="empty-state-title">No Communities Registered</h4>
            <p class="empty-state-text">Be the first to launch a community and climb the sustainability ladder!</p>
            <button class="btn btn-primary" onclick="window.app.navigate('communities')">Explore Communities</button>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
      }

      container.innerHTML = `
        <div style="overflow-x: auto;">
          <table class="leaderboard-table">
            <thead>
              <tr>
                <th style="width: 70px;">Rank</th>
                <th>Community</th>
                <th>Category</th>
                <th>Members</th>
                <th>Verified Actions</th>
                <th>CO2 Avoided</th>
                <th>Combined Points</th>
              </tr>
            </thead>
            <tbody>
              ${communities
                .map((comm) => {
                  let rankClass = 'rank-default';
                  if (comm.rank === 1) rankClass = 'rank-1';
                  else if (comm.rank === 2) rankClass = 'rank-2';
                  else if (comm.rank === 3) rankClass = 'rank-3';

                  return `
                  <tr>
                    <td><span class="rank-badge ${rankClass}">#${comm.rank}</span></td>
                    <td>
                      <div style="font-weight: 700; color: var(--dark); cursor: pointer;" onclick="window.communities.openCommunity('${comm._id}')">
                        ${comm.name}
                      </div>
                      <div style="font-size: 0.75rem; color: var(--secondary-text);">${comm.description.slice(0, 45)}...</div>
                    </td>
                    <td><span class="badge badge-category">${comm.category}</span></td>
                    <td><span style="font-weight: 600;">👥 ${comm.memberCount}</span></td>
                    <td>${comm.totalActionsVerified || 0}</td>
                    <td>~${(comm.totalCO2Avoided || 0).toFixed(1)} kg</td>
                    <td><span style="font-size: 1.1rem; font-weight: 800; color: #047857;">${comm.totalPoints} pts</span></td>
                  </tr>
                `;
                })
                .join('')}
            </tbody>
          </table>
        </div>
      `;

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('loadCommunities error:', err);
      container.innerHTML = '<p style="color: var(--danger);">Failed to load community rankings.</p>';
    }
  },
};
