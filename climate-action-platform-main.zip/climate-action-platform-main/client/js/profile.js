/**
 * ClimateAction — Profile Controller (Frontend)
 * Handles user profiles (self & public), followers/following modals, profile editing, and avatar updates.
 */

window.profile = {
  viewingUserId: null,

  async render(targetUserId = null) {
    this.viewingUserId = targetUserId || window.app.currentUser?._id;
    if (!this.viewingUserId) return;

    try {
      const res = await window.api.getPublicProfile(this.viewingUserId);
      const profile = res.profile;

      // Update Identity
      document.getElementById('profile-name').textContent = profile.name;
      document.getElementById('profile-bio').textContent = profile.bio || 'Passionate climate steward taking real steps for planetary sustainability.';
      document.getElementById('profile-city').textContent = profile.city ? `📍 ${profile.city}` : '📍 Global';

      const occupationText = [profile.occupation, profile.college || profile.company].filter(Boolean).join(' • ');
      document.getElementById('profile-occupation').textContent = occupationText || 'Eco Champion';

      // Avatar
      const avatarImg = document.getElementById('profile-avatar-img');
      const avatarPlaceholder = document.getElementById('profile-avatar-placeholder');
      if (profile.avatar) {
        avatarImg.src = profile.avatar;
        avatarImg.style.display = 'block';
        avatarPlaceholder.style.display = 'none';
      } else {
        avatarImg.style.display = 'none';
        avatarPlaceholder.style.display = 'flex';
        avatarPlaceholder.textContent = profile.name.charAt(0).toUpperCase();
      }

      // Stats
      document.getElementById('profile-points').textContent = `${profile.totalPoints || 0} pts`;
      document.getElementById('profile-score').textContent = `${profile.climateActionScore || 0}/100`;
      document.getElementById('profile-streak').textContent = `${profile.currentStreak || 0} days`;
      document.getElementById('profile-longest-streak').textContent = `${profile.longestStreak || 0} days`;
      document.getElementById('profile-actions-count').textContent = profile.totalVerifiedActions || 0;
      document.getElementById('profile-co2').textContent = `${(profile.totalCO2Avoided || 0).toFixed(1)} kg`;
      document.getElementById('profile-rank').textContent = `#${profile.worldwideRank || '-'}`;

      // Social Counters
      document.getElementById('profile-followers-count').textContent = profile.followersCount || 0;
      document.getElementById('profile-following-count').textContent = profile.followingCount || 0;

      // Action Buttons (Edit Profile vs Follow/Unfollow)
      const actionArea = document.getElementById('profile-action-buttons');
      if (profile.isSelf) {
        actionArea.innerHTML = `
          <button class="btn btn-secondary btn-sm" onclick="window.profile.openEditModal()"><i data-lucide="edit-3"></i> Edit Profile</button>
          <label class="btn btn-soft btn-sm" style="margin: 0; cursor: pointer;">
            <i data-lucide="camera"></i> Change Photo
            <input type="file" id="profile-avatar-input" accept="image/*" style="display: none;" onchange="window.profile.handleAvatarUpload(event)" />
          </label>
        `;
      } else {
        actionArea.innerHTML = `
          <button class="btn ${profile.isFollowing ? 'btn-secondary' : 'btn-primary'} btn-sm" onclick="window.profile.toggleFollow('${profile.id}', ${profile.isFollowing})">
            ${profile.isFollowing ? '✓ Following' : '+ Follow'}
          </button>
        `;
      }

      // Render Heatmap
      this.renderHeatmap(profile.heatmapData || {});

      // Render Verified Actions
      await this.loadUserActions(profile.id);

      if (window.lucide) window.lucide.createIcons();
    } catch (err) {
      console.error('profile render error:', err);
      window.app.showToast('Failed to load profile.', 'error');
    }
  },

  openProfile(userId) {
    window.app.navigate('profile');
    this.render(userId);
  },

  renderHeatmap(heatmapData) {
    const grid = document.getElementById('profile-heatmap-grid');
    if (!grid) return;
    grid.innerHTML = '';

    const today = new Date();
    const daysToShow = 52 * 7;
    const startDate = new Date();
    startDate.setDate(today.getDate() - daysToShow + 1);

    for (let i = 0; i < daysToShow; i++) {
      const d = new Date(startDate);
      d.setDate(startDate.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];

      const dayEl = document.createElement('div');
      dayEl.className = 'heatmap-day';

      const entry = heatmapData[dateStr];
      const level = entry ? entry.level : 0;
      dayEl.setAttribute('data-level', level);

      const titleText = entry
        ? `${dateStr}: ${entry.count} action(s), +${entry.points} pts, ~${entry.co2} kg CO2`
        : `${dateStr}: No actions`;
      dayEl.title = titleText;

      grid.appendChild(dayEl);
    }
  },

  async loadUserActions(userId) {
    const listEl = document.getElementById('profile-actions-list');
    if (!listEl) return;

    try {
      const res = await window.api.getActionHistory({ userId, status: 'approved', limit: 6 });
      const actions = res.actions || [];

      if (actions.length === 0) {
        listEl.innerHTML = `
          <div class="empty-state" style="padding: 2rem 1rem;">
            <p class="empty-state-text">No verified actions completed yet.</p>
          </div>
        `;
        return;
      }

      listEl.innerHTML = `
        <div class="grid-3">
          ${actions
            .map(
              (act) => `
            <div class="action-card">
              <div class="action-card-img-wrapper" style="height: 160px;">
                <img src="${act.photoProof}" alt="${act.title}" class="action-card-img" />
              </div>
              <div class="action-card-body" style="padding: 1rem;">
                <span class="badge badge-category" style="margin-bottom: 0.4rem; align-self: flex-start;">${act.category}</span>
                <h4 style="font-size: 0.95rem; font-weight: 700; color: var(--dark);">${act.title}</h4>
                <div style="font-size: 0.8rem; font-weight: 700; color: #047857; margin-top: 0.5rem;">+${act.pointsEarned} pts awarded</div>
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      `;
    } catch (err) {
      listEl.innerHTML = '<p style="color: var(--danger);">Failed to load actions.</p>';
    }
  },

  async toggleFollow(targetUserId, currentlyFollowing) {
    try {
      if (currentlyFollowing) {
        await window.api.unfollowUser(targetUserId);
        window.app.showToast('Unfollowed.', 'info');
      } else {
        await window.api.followUser(targetUserId);
        window.app.showToast('Following user!', 'success');
      }
      this.render(targetUserId);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async handleAvatarUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const formData = new FormData();
      formData.append('avatar', file);
      const res = await window.api.uploadAvatar(formData);
      window.app.showToast('Profile photo updated!', 'success');
      window.app.currentUser = res.user;
      window.app.updateNavAuth();
      this.render(this.viewingUserId);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  openEditModal() {
    const user = window.app.currentUser;
    if (!user) return;

    document.getElementById('edit-name').value = user.name || '';
    document.getElementById('edit-city').value = user.city || '';
    document.getElementById('edit-occupation').value = user.occupation || '';
    document.getElementById('edit-college').value = user.college || '';
    document.getElementById('edit-company').value = user.company || '';
    document.getElementById('edit-role').value = user.jobRole || '';
    document.getElementById('edit-bio').value = user.bio || '';
    document.getElementById('edit-interests').value = (user.interests || []).join(', ');
    document.getElementById('edit-goals').value = (user.climateGoals || []).join(', ');

    document.getElementById('edit-profile-modal').style.display = 'flex';
  },

  closeEditModal() {
    document.getElementById('edit-profile-modal').style.display = 'none';
  },

  async saveProfileEdits() {
    const data = {
      name: document.getElementById('edit-name').value.trim(),
      city: document.getElementById('edit-city').value.trim(),
      occupation: document.getElementById('edit-occupation').value,
      college: document.getElementById('edit-college').value.trim(),
      company: document.getElementById('edit-company').value.trim(),
      jobRole: document.getElementById('edit-role').value.trim(),
      bio: document.getElementById('edit-bio').value.trim(),
      interests: document.getElementById('edit-interests').value,
      climateGoals: document.getElementById('edit-goals').value,
    };

    try {
      const res = await window.api.updateProfile(data);
      window.app.currentUser = res.user;
      window.app.showToast('Profile updated!', 'success');
      this.closeEditModal();
      this.render(res.user.id);
    } catch (err) {
      window.app.showToast(err.message, 'error');
    }
  },

  async showFollowersModal(type = 'followers') {
    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-header">
          <h3 class="modal-title">${type === 'followers' ? 'Followers' : 'Following'}</h3>
          <button class="modal-close-btn" onclick="this.closest('.modal-backdrop').remove()">&times;</button>
        </div>
        <div class="modal-body" id="social-modal-body">
          <p>Loading...</p>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    try {
      const res = type === 'followers'
        ? await window.api.getFollowers(this.viewingUserId)
        : await window.api.getFollowing(this.viewingUserId);

      const list = type === 'followers' ? res.followers : res.following;
      const body = document.getElementById('social-modal-body');

      if (!list || list.length === 0) {
        body.innerHTML = `<div class="empty-state" style="padding: 1.5rem;"><p class="empty-state-text">No ${type} yet.</p></div>`;
        return;
      }

      body.innerHTML = list
        .map(
          (u) => `
        <div style="display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--light-border);">
          <div style="display: flex; align-items: center; gap: 0.75rem; cursor: pointer;" onclick="document.querySelector('.modal-backdrop').remove(); window.profile.openProfile('${u._id}')">
            <div class="nav-avatar-placeholder" style="width: 38px; height: 38px;">${u.name.charAt(0).toUpperCase()}</div>
            <div>
              <div style="font-weight: 700; color: var(--dark);">${u.name}</div>
              <div style="font-size: 0.8rem; color: var(--muted-text);">${u.city || 'Global'} &bull; ${u.totalPoints || 0} pts</div>
            </div>
          </div>
        </div>
      `
        )
        .join('');
    } catch (err) {
      document.getElementById('social-modal-body').innerHTML = '<p style="color: var(--danger);">Failed to load list.</p>';
    }
  },
};
