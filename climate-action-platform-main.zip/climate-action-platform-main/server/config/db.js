const mongoose = require('mongoose');

let mongoMemoryServer = null;

const connectDB = async () => {
  try {
    let mongoUri = process.env.MONGODB_URI;

    if (!mongoUri || mongoUri.trim() === '') {
      console.log('ℹ️  MONGODB_URI not set. Initializing embedded MongoDB engine...');
      try {
        const { MongoMemoryServer } = require('mongodb-memory-server');
        mongoMemoryServer = await MongoMemoryServer.create();
        mongoUri = mongoMemoryServer.getUri();
        console.log(`✅ Embedded MongoDB engine active at: ${mongoUri}`);
      } catch (memErr) {
        console.warn('⚠️  Could not start MongoMemoryServer, falling back to local default mongodb://127.0.0.1:27017/climateaction', memErr.message);
        mongoUri = 'mongodb://127.0.0.1:27017/climateaction';
      }
    }

    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 8000,
    });

    console.log(`🌿 MongoDB connected successfully: ${conn.connection.host} (${conn.connection.name})`);
    return conn;
  } catch (error) {
    console.error('❌ MongoDB Connection Error:', error.message);
    process.exit(1);
  }
};

const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
    if (mongoMemoryServer) {
      await mongoMemoryServer.stop();
    }
  } catch (err) {
    console.error('Error disconnecting MongoDB:', err);
  }
};

module.exports = { connectDB, disconnectDB };
