const Action = require('../models/Action');
const ActionVerification = require('../models/ActionVerification');
const { performAutomaticVerification } = require('../services/verificationService');
const { approveActionAndAwardImpact } = require('../services/impactService');

/**
 * Report a Genuine Climate Action with Photo Proof
 */
exports.reportAction = async (req, res) => {
  try {
    const { title, category, description, date, quantity, unit } = req.body;

    if (!title || !category || !description) {
      return res.status(400).json({
        success: false,
        message: 'Action title, category, and description are required.',
      });
    }

    // Photo proof is mandatory
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Authentic photo proof is strictly required to verify climate actions.',
      });
    }

    const photoPath = `/uploads/actions/${req.file.filename}`;

    // Create Action document
    const action = await Action.create({
      user: req.user._id,
      title: title.trim(),
      category: category.toLowerCase().trim(),
      description: description.trim(),
      date: date ? new Date(date) : new Date(),
      quantity: quantity ? Number(quantity) : 1,
      unit: unit || 'action',
      photoProof: photoPath,
      photoOriginalName: req.file.originalname,
      photoMimeType: req.file.mimetype,
      photoSizeBytes: req.file.size,
      verificationStatus: 'pending',
    });

    // Stage 1: Automatic verification engine
    const autoResult = await performAutomaticVerification(action);

    let finalAction = action;
    let awardResult = null;

    if (autoResult.suggestedStatus === 'approved') {
      // High confidence: Automatically approve and compute real metrics
      awardResult = await approveActionAndAwardImpact(action._id, null, autoResult.reason);
      finalAction = awardResult.action;
    } else {
      // Flagged for Stage 2 Admin review
      action.verificationStatus = 'under_review';
      await action.save();
      finalAction = action;
    }

    return res.status(201).json({
      success: true,
      message:
        finalAction.verificationStatus === 'approved'
          ? `Action automatically verified! You earned +${finalAction.pointsEarned} points.`
          : 'Action submitted with photo proof and queued for review.',
      action: finalAction,
      verificationStatus: finalAction.verificationStatus,
      autoVerification: {
        confidence: autoResult.confidence,
        checks: autoResult.checks,
        reason: autoResult.reason,
      },
      pointsEarned: finalAction.pointsEarned,
      impact: finalAction.impact,
    });
  } catch (error) {
    console.error('reportAction error:', error);
    return res.status(500).json({ success: false, message: 'Failed to record climate action.' });
  }
};

/**
 * Get Action History for Current User (or specified user if public)
 */
exports.getActionHistory = async (req, res) => {
  try {
    const userId = req.query.userId || req.user._id;
    const { status, category, page = 1, limit = 20 } = req.query;

    const query = { user: userId };

    if (status && status !== 'all') {
      query.verificationStatus = status;
    }

    if (category && category !== 'all') {
      query.category = category;
    }

    // If viewing another user's action history, only show approved actions
    if (req.user && req.user._id.toString() !== userId.toString()) {
      query.verificationStatus = 'approved';
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [actions, total] = await Promise.all([
      Action.find(query)
        .sort({ date: -1, createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Action.countDocuments(query),
    ]);

    return res.status(200).json({
      success: true,
      actions,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
        limit: Number(limit),
      },
    });
  } catch (error) {
    console.error('getActionHistory error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve action history.' });
  }
};

/**
 * Get Single Action Details by ID
 */
exports.getActionById = async (req, res) => {
  try {
    const { id } = req.params;
    const action = await Action.findById(id).populate('user', 'name avatar city');

    if (!action) {
      return res.status(404).json({ success: false, message: 'Action not found.' });
    }

    // Fetch verification audit trail
    const verification = await ActionVerification.findOne({ action: action._id });

    return res.status(200).json({
      success: true,
      action,
      verification,
    });
  } catch (error) {
    console.error('getActionById error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch action.' });
  }
};
