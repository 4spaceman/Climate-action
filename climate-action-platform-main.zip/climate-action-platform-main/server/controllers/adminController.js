const User = require('../models/User');
const Action = require('../models/Action');
const ActionVerification = require('../models/ActionVerification');
const Community = require('../models/Community');
const CommunityPost = require('../models/CommunityPost');
const { approveActionAndAwardImpact, rejectAction } = require('../services/impactService');

/**
 * 1. Get Real Platform Statistics from Database
 */
exports.getPlatformStats = async (req, res) => {
  try {
    const [
      totalUsers,
      totalVerifiedUsers,
      totalActions,
      verifiedActionsCount,
      pendingActionsCount,
      underReviewCount,
      totalCommunities,
      totalPosts,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ isEmailVerified: true }),
      Action.countDocuments(),
      Action.countDocuments({ verificationStatus: 'approved' }),
      Action.countDocuments({ verificationStatus: 'pending' }),
      Action.countDocuments({ verificationStatus: 'under_review' }),
      Community.countDocuments(),
      CommunityPost.countDocuments(),
    ]);

    // Aggregate environmental totals from all approved actions
    const impactAgg = await Action.aggregate([
      { $match: { verificationStatus: 'approved' } },
      {
        $group: {
          _id: null,
          totalPoints: { $sum: '$pointsEarned' },
          totalCO2: { $sum: '$impact.co2AvoidedKg' },
          totalWater: { $sum: '$impact.waterSavedLitres' },
          totalEnergy: { $sum: '$impact.energyReducedKwh' },
          totalWaste: { $sum: '$impact.wasteAvoidedKg' },
        },
      },
    ]);

    const aggregateMetrics = impactAgg[0] || {
      totalPoints: 0,
      totalCO2: 0,
      totalWater: 0,
      totalEnergy: 0,
      totalWaste: 0,
    };

    return res.status(200).json({
      success: true,
      stats: {
        totalUsers,
        totalVerifiedUsers,
        totalActions,
        verifiedActionsCount,
        pendingReviewCount: pendingActionsCount + underReviewCount,
        totalCommunities,
        totalPosts,
        totalPointsAwarded: aggregateMetrics.totalPoints,
        totalCO2AvoidedKg: Number(aggregateMetrics.totalCO2.toFixed(2)),
        totalWaterSavedLitres: Number(aggregateMetrics.totalWater.toFixed(1)),
        totalEnergyReducedKwh: Number(aggregateMetrics.totalEnergy.toFixed(2)),
        totalWasteAvoidedKg: Number(aggregateMetrics.totalWaste.toFixed(2)),
      },
    });
  } catch (error) {
    console.error('getPlatformStats error:', error);
    return res.status(500).json({ success: false, message: 'Failed to aggregate platform statistics.' });
  }
};

/**
 * 2. Get Pending and Under Review Actions Queue
 */
exports.getPendingActions = async (req, res) => {
  try {
    const { status = 'all', page = 1, limit = 20 } = req.query;

    const query = {};
    if (status === 'all') {
      query.verificationStatus = { $in: ['pending', 'under_review'] };
    } else {
      query.verificationStatus = status;
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [actions, total] = await Promise.all([
      Action.find(query)
        .populate('user', 'name email avatar city')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Action.countDocuments(query),
    ]);

    // Attach verification audit records
    const actionIds = actions.map((a) => a._id);
    const verifications = await ActionVerification.find({ action: { $in: actionIds } });
    const verificationMap = {};
    verifications.forEach((v) => {
      verificationMap[v.action.toString()] = v;
    });

    const enrichedActions = actions.map((act) => ({
      ...act.toObject(),
      verificationAudit: verificationMap[act._id.toString()] || null,
    }));

    return res.status(200).json({
      success: true,
      actions: enrichedActions,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getPendingActions error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve review queue.' });
  }
};

/**
 * 3. Approve Action (Admin Review)
 */
exports.approveAction = async (req, res) => {
  try {
    const { actionId } = req.params;
    const { notes } = req.body;

    const result = await approveActionAndAwardImpact(
      actionId,
      req.user._id,
      notes || 'Action approved by administrator'
    );

    // Update ActionVerification record
    await ActionVerification.findOneAndUpdate(
      { action: actionId },
      {
        'adminDecision.decision': 'approved',
        'adminDecision.adminId': req.user._id,
        'adminDecision.reason': notes || 'Approved following administrator review',
        'adminDecision.decidedAt': new Date(),
        stage: 'admin_review',
      }
    );

    return res.status(200).json({
      success: true,
      message: 'Action approved successfully and impact points awarded!',
      action: result.action,
      pointsEarned: result.pointsEarned,
      impact: result.impact,
    });
  } catch (error) {
    console.error('admin approveAction error:', error);
    return res.status(500).json({ success: false, message: error.message || 'Failed to approve action.' });
  }
};

/**
 * 4. Reject Action (Admin Review)
 */
exports.rejectAction = async (req, res) => {
  try {
    const { actionId } = req.params;
    const { reason } = req.body;

    if (!reason || !reason.trim()) {
      return res.status(400).json({ success: false, message: 'Rejection reason is required.' });
    }

    const action = await rejectAction(actionId, req.user._id, reason.trim());

    await ActionVerification.findOneAndUpdate(
      { action: actionId },
      {
        'adminDecision.decision': 'rejected',
        'adminDecision.adminId': req.user._id,
        'adminDecision.reason': reason.trim(),
        'adminDecision.decidedAt': new Date(),
        stage: 'admin_review',
      }
    );

    return res.status(200).json({
      success: true,
      message: 'Action rejected and applicant notified.',
      action,
    });
  } catch (error) {
    console.error('admin rejectAction error:', error);
    return res.status(500).json({ success: false, message: error.message || 'Failed to reject action.' });
  }
};

/**
 * 5. Get Users List for Management
 */
exports.getUsers = async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const query = {};

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [users, total] = await Promise.all([
      User.find(query)
        .select('-password')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      User.countDocuments(query),
    ]);

    return res.status(200).json({
      success: true,
      users,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getUsers error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve users.' });
  }
};

/**
 * 6. Toggle User Admin Role
 */
exports.toggleUserRole = async (req, res) => {
  try {
    const { userId } = req.params;
    const targetUser = await User.findById(userId);

    if (!targetUser) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Prevent removing admin role from oneself
    if (targetUser._id.toString() === req.user._id.toString()) {
      return res.status(400).json({ success: false, message: 'You cannot alter your own admin privileges.' });
    }

    targetUser.role = targetUser.role === 'admin' ? 'user' : 'admin';
    await targetUser.save();

    return res.status(200).json({
      success: true,
      message: `User role updated to ${targetUser.role}.`,
      role: targetUser.role,
    });
  } catch (error) {
    console.error('toggleUserRole error:', error);
    return res.status(500).json({ success: false, message: 'Failed to change user role.' });
  }
};
