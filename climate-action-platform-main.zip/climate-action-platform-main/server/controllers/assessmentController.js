const ClimateProfile = require('../models/ClimateProfile');
const User = require('../models/User');
const { generateRecommendationsForUser } = require('../services/recommendationService');

/**
 * Submit or Update Climate Lifestyle Assessment
 */
exports.submitAssessment = async (req, res) => {
  try {
    const userId = req.user._id;
    const {
      transportation,
      energy,
      water,
      food,
      waste,
      shopping,
      nature,
      climateAwareness,
    } = req.body;

    // Calculate baseline score (0-100) from habits
    let baseline = 50;

    // Transportation adjustments
    if (transportation?.primaryCommute === 'walking' || transportation?.primaryCommute === 'cycling') baseline += 10;
    else if (transportation?.primaryCommute === 'public_transit' || transportation?.primaryCommute === 'ev') baseline += 6;
    else if (transportation?.primaryCommute === 'car' && (transportation?.weeklyKm || 0) > 100) baseline -= 8;

    // Energy adjustments
    if (energy?.solarPowered) baseline += 8;
    if (energy?.appliancesOffWhenIdle) baseline += 4;
    if ((energy?.acUsageHoursPerDay || 0) > 6) baseline -= 6;

    // Water adjustments
    if ((water?.showerDurationMins || 10) <= 5) baseline += 5;
    if (water?.rainwaterHarvesting) baseline += 6;
    if (water?.runningTapHabit) baseline -= 4;

    // Food adjustments
    if (food?.dietType === 'vegan') baseline += 10;
    else if (food?.dietType === 'vegetarian') baseline += 7;
    else if (food?.mealsWithMeatPerWeek > 10) baseline -= 5;
    if (food?.foodWasteFrequency === 'rarely') baseline += 5;

    // Waste adjustments
    if (waste?.recyclePlastics) baseline += 4;
    if (waste?.repairBeforeReplace) baseline += 4;
    if ((waste?.singleUseBottlesWeekly || 0) > 5) baseline -= 5;

    // Nature adjustments
    if (nature?.plantsTreesAnnually) baseline += 6;
    if (nature?.participatesInCleanups) baseline += 5;

    baseline = Math.min(95, Math.max(15, baseline));

    // Save or update ClimateProfile
    const profile = await ClimateProfile.findOneAndUpdate(
      { user: userId },
      {
        user: userId,
        transportation: transportation || {},
        energy: energy || {},
        water: water || {},
        food: food || {},
        waste: waste || {},
        shopping: shopping || {},
        nature: nature || {},
        climateAwareness: climateAwareness || {},
        calculatedBaselineScore: baseline,
      },
      { upsert: true, new: true }
    );

    // Update User record
    await User.findByIdAndUpdate(userId, {
      hasCompletedAssessment: true,
      isOnboarded: true,
    });

    // Generate personalized rule-based recommendations based on this real assessment
    const recommendations = await generateRecommendationsForUser(userId, profile);

    return res.status(200).json({
      success: true,
      message: 'Climate lifestyle assessment completed successfully!',
      profile,
      baselineScore: baseline,
      recommendations,
    });
  } catch (error) {
    console.error('submitAssessment error:', error);
    return res.status(500).json({ success: false, message: 'Failed to record assessment.' });
  }
};

/**
 * Get User's Current Assessment
 */
exports.getAssessment = async (req, res) => {
  try {
    const profile = await ClimateProfile.findOne({ user: req.user._id });
    if (!profile) {
      return res.status(200).json({
        success: true,
        completed: false,
        message: 'No assessment found. Complete your lifestyle assessment to unlock recommendations.',
        profile: null,
      });
    }

    return res.status(200).json({
      success: true,
      completed: true,
      profile,
    });
  } catch (error) {
    console.error('getAssessment error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch assessment.' });
  }
};
