const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const OTP = require('../models/OTP');
const { sendOtpEmail } = require('../services/emailService');

// Helper to generate JWT token and set HTTP-only cookie
const sendTokenResponse = (user, statusCode, res, message = 'Success') => {
  const token = jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET || 'climate_action_default_secret',
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );

  const cookieOptions = {
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
  };

  res.cookie('token', token, cookieOptions);

  return res.status(statusCode).json({
    success: true,
    message,
    token,
    user: user.toPublicProfile ? user.toPublicProfile() : user,
  });
};

// Generate cryptographically secure 6-digit OTP
const generate6DigitOTP = () => {
  return crypto.randomInt(100000, 999999).toString();
};

/**
 * 1. Request Email Verification OTP (Step 1 of Signup)
 */
exports.sendSignupOtp = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      return res.status(400).json({ success: false, message: 'Please provide a valid email address.' });
    }

    const cleanEmail = email.toLowerCase().trim();

    // Check if user already exists with verified email
    const existingUser = await User.findOne({ email: cleanEmail });
    if (existingUser && existingUser.isEmailVerified) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email address already exists. Please log in.',
      });
    }

    // Invalidate any previous OTPs for this email and type
    await OTP.deleteMany({ email: cleanEmail, type: 'email_verification' });

    // Generate secure 6-digit OTP
    const rawOtp = generate6DigitOTP();
    const hashedOtp = await bcrypt.hash(rawOtp, 8);

    await OTP.create({
      email: cleanEmail,
      otp: hashedOtp,
      type: 'email_verification',
      expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
    });

    // Send real email via Nodemailer
    const emailResult = await sendOtpEmail(cleanEmail, rawOtp, 'email_verification');

    return res.status(200).json({
      success: true,
      message: 'A 6-digit verification code has been dispatched to your email address.',
      email: cleanEmail,
      previewUrl: emailResult.previewUrl || null,
    });
  } catch (error) {
    console.error('sendSignupOtp error:', error);
    return res.status(500).json({ success: false, message: 'Server error processing verification request.' });
  }
};

/**
 * 2. Verify OTP and Register Account (Step 2 of Signup)
 */
exports.verifyAndRegister = async (req, res) => {
  try {
    const { email, otp, name, password, adminSecretKey } = req.body;

    if (!email || !otp || !name || !password) {
      return res.status(400).json({ success: false, message: 'All registration fields are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
    }

    const cleanEmail = email.toLowerCase().trim();

    // Verify OTP record
    const otpRecord = await OTP.findOne({
      email: cleanEmail,
      type: 'email_verification',
    });

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'No active verification code found or code has expired. Please request a new code.',
      });
    }

    // Check expiration
    if (new Date() > otpRecord.expiresAt) {
      await OTP.deleteOne({ _id: otpRecord._id });
      return res.status(400).json({
        success: false,
        message: 'Verification code has expired. Please request a new code.',
      });
    }

    // Check attempt limits
    if (otpRecord.attempts >= otpRecord.maxAttempts) {
      await OTP.deleteOne({ _id: otpRecord._id });
      return res.status(400).json({
        success: false,
        message: 'Too many incorrect attempts. For security, please request a new verification code.',
      });
    }

    // Verify code match
    const isMatch = await bcrypt.compare(otp.trim(), otpRecord.otp);
    if (!isMatch) {
      otpRecord.attempts += 1;
      await otpRecord.save();
      const remaining = otpRecord.maxAttempts - otpRecord.attempts;
      return res.status(400).json({
        success: false,
        message: `Incorrect verification code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`,
      });
    }

    // OTP is valid! Clean up OTP record
    await OTP.deleteOne({ _id: otpRecord._id });

    // Determine role (optional admin passkey for initial administrator provisioning)
    let role = 'user';
    if (adminSecretKey && adminSecretKey === process.env.ADMIN_SECRET_KEY) {
      role = 'admin';
    }

    // If an unverified user document existed with this email, remove or update it
    let user = await User.findOne({ email: cleanEmail });
    if (user) {
      user.name = name.trim();
      user.password = password;
      user.isEmailVerified = true;
      user.role = role;
      await user.save();
    } else {
      user = await User.create({
        name: name.trim(),
        email: cleanEmail,
        password: password,
        isEmailVerified: true,
        role: role,
      });
    }

    return sendTokenResponse(user, 201, res, 'Account created and verified successfully!');
  } catch (error) {
    console.error('verifyAndRegister error:', error);
    return res.status(500).json({ success: false, message: 'Server error creating account.' });
  }
};

/**
 * 3. User Login
 */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide both email and password.' });
    }

    const cleanEmail = email.toLowerCase().trim();

    // Query user including password field
    const user = await User.findOne({ email: cleanEmail }).select('+password');

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    if (!user.isEmailVerified) {
      return res.status(403).json({
        success: false,
        message: 'Your email address is not yet verified. Please complete verification.',
        needsVerification: true,
        email: cleanEmail,
      });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    return sendTokenResponse(user, 200, res, 'Logged in successfully!');
  } catch (error) {
    console.error('login error:', error);
    return res.status(500).json({ success: false, message: 'Server error during login.' });
  }
};

/**
 * 4. Request Forgot Password OTP
 */
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      return res.status(400).json({ success: false, message: 'Please provide a valid registered email address.' });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    if (!user) {
      // Return 200 with standard wording to avoid email enumeration attacks
      return res.status(200).json({
        success: true,
        message: 'If an account matches that email address, a password reset code has been sent.',
      });
    }

    // Invalidate old reset OTPs
    await OTP.deleteMany({ email: cleanEmail, type: 'password_reset' });

    // Generate new OTP
    const rawOtp = generate6DigitOTP();
    const hashedOtp = await bcrypt.hash(rawOtp, 8);

    await OTP.create({
      email: cleanEmail,
      otp: hashedOtp,
      type: 'password_reset',
      expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
    });

    const emailResult = await sendOtpEmail(cleanEmail, rawOtp, 'password_reset');

    return res.status(200).json({
      success: true,
      message: 'If an account matches that email address, a password reset code has been sent.',
      email: cleanEmail,
      previewUrl: emailResult.previewUrl || null,
    });
  } catch (error) {
    console.error('forgotPassword error:', error);
    return res.status(500).json({ success: false, message: 'Server error initiating password reset.' });
  }
};

/**
 * 5. Reset Password using OTP
 */
exports.resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({ success: false, message: 'Email, OTP code, and new password are required.' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ success: false, message: 'New password must be at least 6 characters long.' });
    }

    const cleanEmail = email.toLowerCase().trim();

    const otpRecord = await OTP.findOne({
      email: cleanEmail,
      type: 'password_reset',
    });

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Reset code is invalid or has expired. Please request a new code.',
      });
    }

    if (new Date() > otpRecord.expiresAt) {
      await OTP.deleteOne({ _id: otpRecord._id });
      return res.status(400).json({ success: false, message: 'Reset code has expired. Please request a new code.' });
    }

    if (otpRecord.attempts >= otpRecord.maxAttempts) {
      await OTP.deleteOne({ _id: otpRecord._id });
      return res.status(400).json({
        success: false,
        message: 'Maximum verification attempts exceeded. Please request a new code.',
      });
    }

    const isMatch = await bcrypt.compare(otp.trim(), otpRecord.otp);
    if (!isMatch) {
      otpRecord.attempts += 1;
      await otpRecord.save();
      const remaining = otpRecord.maxAttempts - otpRecord.attempts;
      return res.status(400).json({
        success: false,
        message: `Incorrect code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`,
      });
    }

    // Code verified! Clean up OTP record
    await OTP.deleteOne({ _id: otpRecord._id });

    // Update password
    const user = await User.findOne({ email: cleanEmail }).select('+password');
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    user.password = newPassword;
    await user.save();

    return res.status(200).json({
      success: true,
      message: 'Password reset successfully. You can now log in with your new password.',
    });
  } catch (error) {
    console.error('resetPassword error:', error);
    return res.status(500).json({ success: false, message: 'Server error resetting password.' });
  }
};

/**
 * 6. Get Current User Session (Me)
 */
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    return res.status(200).json({
      success: true,
      user: user.toPublicProfile ? user.toPublicProfile() : user,
      role: user.role,
      isOnboarded: user.isOnboarded,
      hasCompletedAssessment: user.hasCompletedAssessment,
    });
  } catch (error) {
    console.error('getMe error:', error);
    return res.status(500).json({ success: false, message: 'Server error retrieving session.' });
  }
};

/**
 * 7. Logout
 */
exports.logout = (req, res) => {
  res.cookie('token', 'none', {
    expires: new Date(Date.now() + 5 * 1000),
    httpOnly: true,
  });

  return res.status(200).json({
    success: true,
    message: 'Logged out successfully.',
  });
};
