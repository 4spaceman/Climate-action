const Community = require('../models/Community');
const CommunityMembership = require('../models/CommunityMembership');
const CommunityPost = require('../models/CommunityPost');
const Comment = require('../models/Comment');
const Reaction = require('../models/Reaction');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { updateCommunityAggregateMetrics } = require('../services/impactService');

/**
 * 1. Create a New Community (Limit: 1 active community per user creator)
 */
exports.createCommunity = async (req, res) => {
  try {
    const { name, description, category, isPublic } = req.body;
    const userId = req.user._id;

    if (!name || !description) {
      return res.status(400).json({ success: false, message: 'Name and description are required.' });
    }

    // Check if user already has an active community they created
    const existingCreated = await Community.findOne({ creator: userId });
    if (existingCreated) {
      return res.status(400).json({
        success: false,
        message: `You already own an active community ("${existingCreated.name}"). Users may only create one active community at a time.`,
      });
    }

    // Check if name is taken
    const nameTaken = await Community.findOne({ name: name.trim() });
    if (nameTaken) {
      return res.status(400).json({ success: false, message: 'A community with this name already exists.' });
    }

    let image = '';
    if (req.file) {
      image = `/uploads/posts/${req.file.filename}`;
    }

    // Create community
    const community = await Community.create({
      name: name.trim(),
      description: description.trim(),
      category: category || 'General Sustainability',
      creator: userId,
      image,
      isPublic: isPublic !== 'false' && isPublic !== false,
      memberCount: 1,
    });

    // Add creator as admin member
    await CommunityMembership.create({
      community: community._id,
      user: userId,
      role: 'admin',
    });

    // Update user's activeCommunityId
    await User.findByIdAndUpdate(userId, { activeCommunityId: community._id });

    // Sync metrics for this community with creator's stats
    await updateCommunityAggregateMetrics(community._id);

    return res.status(201).json({
      success: true,
      message: 'Community created successfully!',
      community,
    });
  } catch (error) {
    console.error('createCommunity error:', error);
    return res.status(500).json({ success: false, message: 'Failed to create community.' });
  }
};

/**
 * 2. Get Communities (Search, Filter, List)
 */
exports.getCommunities = async (req, res) => {
  try {
    const { search, category, page = 1, limit = 15 } = req.query;
    const query = {};

    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }

    if (category && category !== 'all') {
      query.category = category;
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [communities, total] = await Promise.all([
      Community.find(query)
        .populate('creator', 'name avatar')
        .sort({ memberCount: -1, totalPoints: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Community.countDocuments(query),
    ]);

    // Check membership status for current user if logged in
    let userCommunityIds = [];
    if (req.user) {
      const memberships = await CommunityMembership.find({ user: req.user._id }).select('community');
      userCommunityIds = memberships.map((m) => m.community.toString());
    }

    const mappedCommunities = communities.map((comm) => ({
      ...comm.toObject(),
      isMember: userCommunityIds.includes(comm._id.toString()),
      isCreator: req.user ? comm.creator._id.toString() === req.user._id.toString() : false,
    }));

    return res.status(200).json({
      success: true,
      communities: mappedCommunities,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getCommunities error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve communities.' });
  }
};

/**
 * 3. Get Community Details by ID
 */
exports.getCommunityById = async (req, res) => {
  try {
    const { id } = req.params;
    const community = await Community.findById(id).populate('creator', 'name avatar city');

    if (!community) {
      return res.status(404).json({ success: false, message: 'Community not found.' });
    }

    let isMember = false;
    let isAdmin = false;

    if (req.user) {
      const membership = await CommunityMembership.findOne({
        community: community._id,
        user: req.user._id,
      });
      if (membership) {
        isMember = true;
        isAdmin = membership.role === 'admin' || community.creator._id.toString() === req.user._id.toString();
      }
    }

    // Fetch members list
    const memberships = await CommunityMembership.find({ community: community._id })
      .populate('user', 'name avatar city totalPoints climateActionScore')
      .limit(30);

    const members = memberships.map((m) => ({
      user: m.user,
      role: m.role,
    }));

    return res.status(200).json({
      success: true,
      community,
      isMember,
      isAdmin,
      members,
    });
  } catch (error) {
    console.error('getCommunityById error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve community.' });
  }
};

/**
 * 4. Join a Community
 */
exports.joinCommunity = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    const community = await Community.findById(id);
    if (!community) {
      return res.status(404).json({ success: false, message: 'Community not found.' });
    }

    const existingMembership = await CommunityMembership.findOne({
      community: id,
      user: userId,
    });

    if (existingMembership) {
      return res.status(400).json({ success: false, message: 'You are already a member of this community.' });
    }

    // Add membership
    await CommunityMembership.create({
      community: id,
      user: userId,
      role: 'member',
    });

    // Sync metrics and member count
    await updateCommunityAggregateMetrics(id);

    // Notify community creator
    if (community.creator.toString() !== userId.toString()) {
      await Notification.create({
        recipient: community.creator,
        sender: userId,
        type: 'community_join',
        title: 'New Community Member!',
        message: `${req.user.name} joined your community "${community.name}".`,
        data: { communityId: id },
      });
    }

    return res.status(200).json({
      success: true,
      message: `Joined "${community.name}" successfully!`,
    });
  } catch (error) {
    console.error('joinCommunity error:', error);
    return res.status(500).json({ success: false, message: 'Failed to join community.' });
  }
};

/**
 * 5. Leave a Community
 */
exports.leaveCommunity = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    const community = await Community.findById(id);
    if (!community) {
      return res.status(404).json({ success: false, message: 'Community not found.' });
    }

    // Creator cannot abandon ownership without deleting
    if (community.creator.toString() === userId.toString()) {
      return res.status(400).json({
        success: false,
        message: 'As the creator, you cannot leave your own community. You can delete the community if desired.',
      });
    }

    await CommunityMembership.deleteOne({
      community: id,
      user: userId,
    });

    await updateCommunityAggregateMetrics(id);

    return res.status(200).json({
      success: true,
      message: `You have left "${community.name}".`,
    });
  } catch (error) {
    console.error('leaveCommunity error:', error);
    return res.status(500).json({ success: false, message: 'Failed to leave community.' });
  }
};

/**
 * 6. Update Community (Creator / Admin only)
 */
exports.updateCommunity = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, category } = req.body;
    const userId = req.user._id;

    const community = await Community.findById(id);
    if (!community) {
      return res.status(404).json({ success: false, message: 'Community not found.' });
    }

    if (community.creator.toString() !== userId.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Only the creator or platform admin can edit this community.' });
    }

    if (name) community.name = name.trim();
    if (description) community.description = description.trim();
    if (category) community.category = category.trim();

    await community.save();

    return res.status(200).json({
      success: true,
      message: 'Community updated successfully.',
      community,
    });
  } catch (error) {
    console.error('updateCommunity error:', error);
    return res.status(500).json({ success: false, message: 'Failed to update community.' });
  }
};

/**
 * 7. Delete Community (Creator / Admin only)
 */
exports.deleteCommunity = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    const community = await Community.findById(id);
    if (!community) {
      return res.status(404).json({ success: false, message: 'Community not found.' });
    }

    if (community.creator.toString() !== userId.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Only the creator or platform admin can delete this community.' });
    }

    // Clean up memberships, posts, comments, reactions
    await CommunityMembership.deleteMany({ community: id });
    const posts = await CommunityPost.find({ community: id }).select('_id');
    const postIds = posts.map((p) => p._id);

    await Comment.deleteMany({ post: { $in: postIds } });
    await Reaction.deleteMany({ post: { $in: postIds } });
    await CommunityPost.deleteMany({ community: id });

    // Reset user's activeCommunityId so they can create a new one later
    await User.findByIdAndUpdate(community.creator, { activeCommunityId: null });
    await Community.findByIdAndDelete(id);

    return res.status(200).json({
      success: true,
      message: 'Community deleted successfully. You can now create a new community if desired.',
    });
  } catch (error) {
    console.error('deleteCommunity error:', error);
    return res.status(500).json({ success: false, message: 'Failed to delete community.' });
  }
};

/**
 * 8. Create a Community Post
 */
exports.createPost = async (req, res) => {
  try {
    const { communityId, content } = req.body;
    const userId = req.user._id;

    if (!communityId || !content) {
      return res.status(400).json({ success: false, message: 'Community ID and content are required.' });
    }

    // Verify membership
    const membership = await CommunityMembership.findOne({
      community: communityId,
      user: userId,
    });

    if (!membership && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'You must join this community to post.' });
    }

    let photo = '';
    if (req.file) {
      photo = `/uploads/posts/${req.file.filename}`;
    }

    const post = await CommunityPost.create({
      community: communityId,
      author: userId,
      content: content.trim(),
      photo,
    });

    await post.populate('author', 'name avatar city');

    return res.status(201).json({
      success: true,
      message: 'Post published successfully!',
      post,
    });
  } catch (error) {
    console.error('createPost error:', error);
    return res.status(500).json({ success: false, message: 'Failed to create post.' });
  }
};

/**
 * 9. Get Community Posts
 */
exports.getPosts = async (req, res) => {
  try {
    const { communityId } = req.params;
    const { page = 1, limit = 20 } = req.query;

    const skip = (Number(page) - 1) * Number(limit);

    const [posts, total] = await Promise.all([
      CommunityPost.find({ community: communityId })
        .populate('author', 'name avatar city')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      CommunityPost.countDocuments({ community: communityId }),
    ]);

    // Check user reactions on these posts
    let userReactions = {};
    if (req.user) {
      const postIds = posts.map((p) => p._id);
      const reactions = await Reaction.find({
        post: { $in: postIds },
        user: req.user._id,
      });
      reactions.forEach((r) => {
        userReactions[r.post.toString()] = r.type;
      });
    }

    const formattedPosts = posts.map((p) => ({
      ...p.toObject(),
      userReaction: userReactions[p._id.toString()] || null,
      isAuthor: req.user ? p.author._id.toString() === req.user._id.toString() : false,
    }));

    return res.status(200).json({
      success: true,
      posts: formattedPosts,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getPosts error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch posts.' });
  }
};

/**
 * 10. Add Comment to Post
 */
exports.addComment = async (req, res) => {
  try {
    const { postId } = req.params;
    const { content } = req.body;
    const userId = req.user._id;

    if (!content || !content.trim()) {
      return res.status(400).json({ success: false, message: 'Comment content cannot be empty.' });
    }

    const post = await CommunityPost.findById(postId);
    if (!post) {
      return res.status(404).json({ success: false, message: 'Post not found.' });
    }

    const comment = await Comment.create({
      post: postId,
      author: userId,
      content: content.trim(),
    });

    post.commentsCount += 1;
    await post.save();

    await comment.populate('author', 'name avatar');

    // Notify author if different user
    if (post.author.toString() !== userId.toString()) {
      await Notification.create({
        recipient: post.author,
        sender: userId,
        type: 'post_comment',
        title: 'New Comment on Your Post',
        message: `${req.user.name} commented: "${content.slice(0, 40)}..."`,
        data: { postId, commentId: comment._id },
      });
    }

    return res.status(201).json({
      success: true,
      comment,
    });
  } catch (error) {
    console.error('addComment error:', error);
    return res.status(500).json({ success: false, message: 'Failed to add comment.' });
  }
};

/**
 * 11. Get Post Comments
 */
exports.getComments = async (req, res) => {
  try {
    const { postId } = req.params;
    const comments = await Comment.find({ post: postId })
      .populate('author', 'name avatar')
      .sort({ createdAt: 1 });

    return res.status(200).json({
      success: true,
      comments,
    });
  } catch (error) {
    console.error('getComments error:', error);
    return res.status(500).json({ success: false, message: 'Failed to load comments.' });
  }
};

/**
 * 12. Toggle Post Reaction
 */
exports.toggleReaction = async (req, res) => {
  try {
    const { postId } = req.params;
    const { type = 'seedling' } = req.body;
    const userId = req.user._id;

    const post = await CommunityPost.findById(postId);
    if (!post) {
      return res.status(404).json({ success: false, message: 'Post not found.' });
    }

    const existing = await Reaction.findOne({ post: postId, user: userId });

    if (existing) {
      if (existing.type === type) {
        // Remove reaction
        await Reaction.deleteOne({ _id: existing._id });
        post.likesCount = Math.max(0, post.likesCount - 1);
        await post.save();

        return res.status(200).json({
          success: true,
          reacted: false,
          likesCount: post.likesCount,
        });
      } else {
        // Change reaction type
        existing.type = type;
        await existing.save();

        return res.status(200).json({
          success: true,
          reacted: true,
          reactionType: type,
          likesCount: post.likesCount,
        });
      }
    } else {
      // Add new reaction
      await Reaction.create({
        post: postId,
        user: userId,
        type,
      });

      post.likesCount += 1;
      await post.save();

      // Notify post author
      if (post.author.toString() !== userId.toString()) {
        await Notification.create({
          recipient: post.author,
          sender: userId,
          type: 'post_reaction',
          title: 'New Reaction!',
          message: `${req.user.name} reacted to your post.`,
          data: { postId, reactionType: type },
        });
      }

      return res.status(200).json({
        success: true,
        reacted: true,
        reactionType: type,
        likesCount: post.likesCount,
      });
    }
  } catch (error) {
    console.error('toggleReaction error:', error);
    return res.status(500).json({ success: false, message: 'Failed to process reaction.' });
  }
};

/**
 * 13. Delete Post
 */
exports.deletePost = async (req, res) => {
  try {
    const { postId } = req.params;
    const post = await CommunityPost.findById(postId);

    if (!post) {
      return res.status(404).json({ success: false, message: 'Post not found.' });
    }

    const community = await Community.findById(post.community);
    const isCreator = community && community.creator.toString() === req.user._id.toString();
    const isAuthor = post.author.toString() === req.user._id.toString();
    const isPlatformAdmin = req.user.role === 'admin';

    if (!isAuthor && !isCreator && !isPlatformAdmin) {
      return res.status(403).json({ success: false, message: 'You are not authorized to delete this post.' });
    }

    await Comment.deleteMany({ post: postId });
    await Reaction.deleteMany({ post: postId });
    await CommunityPost.findByIdAndDelete(postId);

    return res.status(200).json({
      success: true,
      message: 'Post deleted successfully.',
    });
  } catch (error) {
    console.error('deletePost error:', error);
    return res.status(500).json({ success: false, message: 'Failed to delete post.' });
  }
};
