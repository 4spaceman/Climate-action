const Follow = require('../models/Follow');
const User = require('../models/User');
const Notification = require('../models/Notification');

/**
 * 1. Follow a User
 */
exports.followUser = async (req, res) => {
  try {
    const { targetUserId } = req.params;
    const currentUserId = req.user._id;

    if (currentUserId.toString() === targetUserId) {
      return res.status(400).json({ success: false, message: 'You cannot follow your own profile.' });
    }

    const targetUser = await User.findById(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Check if already following
    const existing = await Follow.findOne({
      follower: currentUserId,
      following: targetUserId,
    });

    if (existing) {
      return res.status(400).json({ success: false, message: 'You are already following this user.' });
    }

    // Create follow relationship
    await Follow.create({
      follower: currentUserId,
      following: targetUserId,
    });

    // Update counts
    await User.findByIdAndUpdate(currentUserId, { $inc: { followingCount: 1 } });
    await User.findByIdAndUpdate(targetUserId, { $inc: { followersCount: 1 } });

    // Send notification to target user
    await Notification.create({
      recipient: targetUserId,
      sender: currentUserId,
      type: 'follow',
      title: 'New Follower!',
      message: `${req.user.name} started following your climate action journey.`,
      data: { followerId: currentUserId },
    });

    return res.status(200).json({
      success: true,
      message: `You are now following ${targetUser.name}.`,
    });
  } catch (error) {
    console.error('followUser error:', error);
    return res.status(500).json({ success: false, message: 'Failed to follow user.' });
  }
};

/**
 * 2. Unfollow a User
 */
exports.unfollowUser = async (req, res) => {
  try {
    const { targetUserId } = req.params;
    const currentUserId = req.user._id;

    const followRecord = await Follow.findOneAndDelete({
      follower: currentUserId,
      following: targetUserId,
    });

    if (!followRecord) {
      return res.status(400).json({ success: false, message: 'You are not following this user.' });
    }

    // Decrement counts
    await User.findByIdAndUpdate(currentUserId, { $inc: { followingCount: -1 } });
    await User.findByIdAndUpdate(targetUserId, { $inc: { followersCount: -1 } });

    // Do NOT notify the user about unfollow (per specification)
    return res.status(200).json({
      success: true,
      message: 'Unfollowed successfully.',
    });
  } catch (error) {
    console.error('unfollowUser error:', error);
    return res.status(500).json({ success: false, message: 'Failed to unfollow user.' });
  }
};

/**
 * 3. Remove a Follower
 */
exports.removeFollower = async (req, res) => {
  try {
    const { followerUserId } = req.params;
    const currentUserId = req.user._id;

    const followRecord = await Follow.findOneAndDelete({
      follower: followerUserId,
      following: currentUserId,
    });

    if (!followRecord) {
      return res.status(400).json({ success: false, message: 'User is not following you.' });
    }

    await User.findByIdAndUpdate(followerUserId, { $inc: { followingCount: -1 } });
    await User.findByIdAndUpdate(currentUserId, { $inc: { followersCount: -1 } });

    return res.status(200).json({
      success: true,
      message: 'Follower removed.',
    });
  } catch (error) {
    console.error('removeFollower error:', error);
    return res.status(500).json({ success: false, message: 'Failed to remove follower.' });
  }
};

/**
 * 4. Get Followers of a User
 */
exports.getFollowers = async (req, res) => {
  try {
    const userId = req.params.userId || req.user._id;
    const followers = await Follow.find({ following: userId })
      .populate('follower', 'name avatar city totalPoints climateActionScore')
      .sort({ createdAt: -1 });

    const formatted = followers.map((f) => f.follower).filter(Boolean);

    return res.status(200).json({
      success: true,
      followers: formatted,
      count: formatted.length,
    });
  } catch (error) {
    console.error('getFollowers error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch followers.' });
  }
};

/**
 * 5. Get Following of a User
 */
exports.getFollowing = async (req, res) => {
  try {
    const userId = req.params.userId || req.user._id;
    const following = await Follow.find({ follower: userId })
      .populate('following', 'name avatar city totalPoints climateActionScore')
      .sort({ createdAt: -1 });

    const formatted = following.map((f) => f.following).filter(Boolean);

    return res.status(200).json({
      success: true,
      following: formatted,
      count: formatted.length,
    });
  } catch (error) {
    console.error('getFollowing error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch following.' });
  }
};
