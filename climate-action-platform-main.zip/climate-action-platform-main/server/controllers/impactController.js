const Action = require('../models/Action');
const ImpactTransaction = require('../models/ImpactTransaction');
const User = require('../models/User');
const { calculateUserStreakAndHeatmap } = require('../services/streakService');
const { calculateClimateActionScore } = require('../utils/scoreFormula');

/**
 * Get Comprehensive Environmental Impact Summary for User
 */
exports.getUserImpactSummary = async (req, res) => {
  try {
    const userId = req.query.userId || req.user._id;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Aggregate category distribution from verified actions
    const categoryStats = await Action.aggregate([
      {
        $match: {
          user: user._id,
          verificationStatus: 'approved',
        },
      },
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 },
          points: { $sum: '$pointsEarned' },
          co2Avoided: { $sum: '$impact.co2AvoidedKg' },
          waterSaved: { $sum: '$impact.waterSavedLitres' },
          energyReduced: { $sum: '$impact.energyReducedKwh' },
          wasteAvoided: { $sum: '$impact.wasteAvoidedKg' },
        },
      },
    ]);

    // Format breakdown for Chart.js
    const categories = ['transportation', 'energy', 'water', 'waste', 'food', 'nature', 'shopping', 'other'];
    const categoryLabels = {
      transportation: 'Transportation',
      energy: 'Energy Conservation',
      water: 'Water Preservation',
      waste: 'Waste Diversion',
      food: 'Sustainable Food',
      nature: 'Nature & Greenery',
      shopping: 'Conscious Consumption',
      other: 'Other Eco-Actions',
    };

    const categoryBreakdown = categories.map((catKey) => {
      const match = categoryStats.find((s) => s._id === catKey);
      return {
        category: catKey,
        label: categoryLabels[catKey],
        count: match ? match.count : 0,
        points: match ? match.points : 0,
        co2Avoided: match ? Number(match.co2Avoided.toFixed(2)) : 0,
        waterSaved: match ? Number(match.waterSaved.toFixed(1)) : 0,
        energyReduced: match ? Number(match.energyReduced.toFixed(2)) : 0,
        wasteAvoided: match ? Number(match.wasteAvoided.toFixed(2)) : 0,
      };
    });

    const { currentStreak, longestStreak, totalActiveDays, heatmapData } =
      await calculateUserStreakAndHeatmap(user._id);

    const scoreInfo = calculateClimateActionScore({
      totalVerifiedActions: user.totalVerifiedActions,
      currentStreak,
      longestStreak,
      distinctCategoriesCount: categoryStats.length,
      totalCO2Avoided: user.totalCO2Avoided,
      totalWaterSaved: user.totalWaterSaved,
      totalWasteAvoided: user.totalWasteAvoided,
      activeDays: totalActiveDays,
      hasCommunity: !!user.activeCommunityId,
      followersCount: user.followersCount,
    });

    return res.status(200).json({
      success: true,
      label: 'Estimated environmental impact',
      totals: {
        totalVerifiedActions: user.totalVerifiedActions,
        totalPoints: user.totalPoints,
        totalCO2AvoidedKg: user.totalCO2Avoided,
        totalWaterSavedLitres: user.totalWaterSaved,
        totalEnergyReducedKwh: user.totalEnergyReduced,
        totalWasteAvoidedKg: user.totalWasteAvoided,
        currentStreak,
        longestStreak,
        totalActiveDays,
        climateActionScore: user.climateActionScore || scoreInfo.score,
        scoreBreakdown: scoreInfo.breakdown,
        scoreDescription: scoreInfo.formulaDescription,
      },
      categoryBreakdown,
      heatmapData,
    });
  } catch (error) {
    console.error('getUserImpactSummary error:', error);
    return res.status(500).json({ success: false, message: 'Failed to calculate impact summary.' });
  }
};

/**
 * Get Traceable Impact & Points Transactions Log
 */
exports.getImpactTransactions = async (req, res) => {
  try {
    const userId = req.user._id;
    const { page = 1, limit = 20 } = req.query;

    const skip = (Number(page) - 1) * Number(limit);

    const [transactions, total] = await Promise.all([
      ImpactTransaction.find({ user: userId })
        .populate('action', 'title category photoProof date')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      ImpactTransaction.countDocuments({ user: userId }),
    ]);

    return res.status(200).json({
      success: true,
      transactions,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getImpactTransactions error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve transactions.' });
  }
};
