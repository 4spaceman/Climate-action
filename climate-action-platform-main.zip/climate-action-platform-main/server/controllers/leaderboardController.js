const User = require('../models/User');
const Community = require('../models/Community');

/**
 * Get Global Leaderboard with Verified Points and Tie-Breaking
 */
exports.getGlobalLeaderboard = async (req, res) => {
  try {
    const { page = 1, limit = 25 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    // Query only verified users with active points or all verified users
    const query = { isEmailVerified: true };

    const [users, total] = await Promise.all([
      User.find(query)
        .select(
          'name avatar city occupation college company totalPoints climateActionScore currentStreak totalVerifiedActions totalCO2Avoided pointsLastUpdatedAt'
        )
        .sort({ totalPoints: -1, pointsLastUpdatedAt: 1, createdAt: 1 })
        .skip(skip)
        .limit(Number(limit))
        .lean(),
      User.countDocuments(query),
    ]);

    // Attach calculated rank numbers with tie-breaker preservation
    const rankedUsers = users.map((u, idx) => ({
      ...u,
      rank: skip + idx + 1,
    }));

    // Find current user's exact global rank if authenticated
    let userRank = null;
    let userStats = null;

    if (req.user) {
      const currentUser = await User.findById(req.user._id).select(
        'name totalPoints pointsLastUpdatedAt'
      );
      if (currentUser) {
        const higherCount = await User.countDocuments({
          isEmailVerified: true,
          $or: [
            { totalPoints: { $gt: currentUser.totalPoints } },
            {
              totalPoints: currentUser.totalPoints,
              pointsLastUpdatedAt: { $lt: currentUser.pointsLastUpdatedAt },
            },
          ],
        });
        userRank = higherCount + 1;
        userStats = {
          rank: userRank,
          totalPoints: currentUser.totalPoints,
        };
      }
    }

    return res.status(200).json({
      success: true,
      leaderboard: rankedUsers,
      currentUserRank: userStats,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getGlobalLeaderboard error:', error);
    return res.status(500).json({ success: false, message: 'Failed to load leaderboard.' });
  }
};

/**
 * Get Community Leaderboard
 */
exports.getCommunityLeaderboard = async (req, res) => {
  try {
    const { page = 1, limit = 25 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const [communities, total] = await Promise.all([
      Community.find({ isPublic: true })
        .populate('creator', 'name avatar')
        .sort({ totalPoints: -1, pointsLastUpdatedAt: 1 })
        .skip(skip)
        .limit(Number(limit))
        .lean(),
      Community.countDocuments({ isPublic: true }),
    ]);

    const rankedCommunities = communities.map((comm, idx) => ({
      ...comm,
      rank: skip + idx + 1,
    }));

    return res.status(200).json({
      success: true,
      communities: rankedCommunities,
      pagination: {
        total,
        page: Number(page),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error('getCommunityLeaderboard error:', error);
    return res.status(500).json({ success: false, message: 'Failed to load community leaderboard.' });
  }
};
