const Recommendation = require('../models/Recommendation');
const ClimateProfile = require('../models/ClimateProfile');
const { generateRecommendationsForUser } = require('../services/recommendationService');

/**
 * Get Personalized Recommendations for Current User
 */
exports.getRecommendations = async (req, res) => {
  try {
    const userId = req.user._id;
    let recommendations = await Recommendation.find({ user: userId }).sort({ isCompleted: 1, potentialPoints: -1 });

    // If user has completed assessment but has no recommendations yet, generate them now
    if (recommendations.length === 0 && req.user.hasCompletedAssessment) {
      const profile = await ClimateProfile.findOne({ user: userId });
      if (profile) {
        recommendations = await generateRecommendationsForUser(userId, profile);
      }
    }

    return res.status(200).json({
      success: true,
      recommendations,
      hasCompletedAssessment: req.user.hasCompletedAssessment,
    });
  } catch (error) {
    console.error('getRecommendations error:', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve recommendations.' });
  }
};

/**
 * Get Daily Actions for Today
 */
exports.getDailyActions = async (req, res) => {
  try {
    const userId = req.user._id;

    // Fetch active personalized recommendations
    const pendingRecommendations = await Recommendation.find({
      user: userId,
      isCompleted: false,
    }).limit(6);

    return res.status(200).json({
      success: true,
      dailyActions: pendingRecommendations,
    });
  } catch (error) {
    console.error('getDailyActions error:', error);
    return res.status(500).json({ success: false, message: 'Failed to load daily actions.' });
  }
};
