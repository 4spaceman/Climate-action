const User = require('../models/User');
const Follow = require('../models/Follow');
const { calculateUserStreakAndHeatmap } = require('../services/streakService');

/**
 * Update Current User's Profile
 */
exports.updateProfile = async (req, res) => {
  try {
    const {
      name,
      city,
      occupation,
      college,
      company,
      jobRole,
      livingSituation,
      interests,
      climateGoals,
      bio,
    } = req.body;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (name) user.name = name.trim();
    if (city !== undefined) user.city = city.trim();
    if (occupation !== undefined) user.occupation = occupation;
    if (college !== undefined) user.college = college.trim();
    if (company !== undefined) user.company = company.trim();
    if (jobRole !== undefined) user.jobRole = jobRole.trim();
    if (livingSituation !== undefined) user.livingSituation = livingSituation.trim();
    if (bio !== undefined) user.bio = bio.trim();

    if (Array.isArray(interests)) {
      user.interests = interests;
    } else if (typeof interests === 'string') {
      user.interests = interests.split(',').map((s) => s.trim()).filter(Boolean);
    }

    if (Array.isArray(climateGoals)) {
      user.climateGoals = climateGoals;
    } else if (typeof climateGoals === 'string') {
      user.climateGoals = climateGoals.split(',').map((s) => s.trim()).filter(Boolean);
    }

    user.isOnboarded = true;
    await user.save();

    return res.status(200).json({
      success: true,
      message: 'Profile updated successfully.',
      user: user.toPublicProfile(),
    });
  } catch (error) {
    console.error('updateProfile error:', error);
    return res.status(500).json({ success: false, message: 'Failed to update profile.' });
  }
};

/**
 * Upload User Avatar
 */
exports.uploadAvatar = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No image file uploaded.' });
    }

    const relativePath = `/uploads/profiles/${req.file.filename}`;
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { avatar: relativePath },
      { new: true }
    );

    return res.status(200).json({
      success: true,
      message: 'Avatar uploaded successfully.',
      avatarUrl: relativePath,
      user: user.toPublicProfile(),
    });
  } catch (error) {
    console.error('uploadAvatar error:', error);
    return res.status(500).json({ success: false, message: 'Failed to upload avatar.' });
  }
};

/**
 * Get Public Profile of any User
 */
exports.getPublicProfile = async (req, res) => {
  try {
    const { id } = req.params;
    const targetUser = await User.findById(id);

    if (!targetUser) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Determine worldwide leaderboard rank
    const rank =
      (await User.countDocuments({
        isEmailVerified: true,
        $or: [
          { totalPoints: { $gt: targetUser.totalPoints } },
          {
            totalPoints: targetUser.totalPoints,
            pointsLastUpdatedAt: { $lt: targetUser.pointsLastUpdatedAt },
          },
        ],
      })) + 1;

    // Check if authenticated user follows this profile
    let isFollowing = false;
    if (req.user && req.user._id.toString() !== id) {
      const followRecord = await Follow.findOne({
        follower: req.user._id,
        following: targetUser._id,
      });
      isFollowing = !!followRecord;
    }

    const { heatmapData, currentStreak, longestStreak } = await calculateUserStreakAndHeatmap(targetUser._id);

    return res.status(200).json({
      success: true,
      profile: {
        ...targetUser.toPublicProfile(),
        worldwideRank: rank,
        isFollowing,
        isSelf: req.user ? req.user._id.toString() === id : false,
        heatmapData,
        currentStreak,
        longestStreak,
      },
    });
  } catch (error) {
    console.error('getPublicProfile error:', error);
    return res.status(500).json({ success: false, message: 'Failed to load user profile.' });
  }
};

/**
 * Get User's Activity Heatmap
 */
exports.getUserHeatmap = async (req, res) => {
  try {
    const userId = req.params.id || req.user._id;
    const { heatmapData, currentStreak, longestStreak, totalActiveDays } =
      await calculateUserStreakAndHeatmap(userId);

    return res.status(200).json({
      success: true,
      heatmapData,
      currentStreak,
      longestStreak,
      totalActiveDays,
    });
  } catch (error) {
    console.error('getUserHeatmap error:', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch heatmap data.' });
  }
};
