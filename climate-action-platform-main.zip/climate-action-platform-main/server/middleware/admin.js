const adminOnly = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Access denied. Administrative authorization required.',
    });
  }
  next();
};

module.exports = { adminOnly };
