const rateLimit = require('express-rate-limit');

// Limiter for OTP requests (max 5 per 15 minutes per IP/client)
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: {
    success: false,
    message: 'Too many OTP requests from this address. Please wait 15 minutes before requesting again.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Limiter for login attempts (max 10 per 15 minutes)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  message: {
    success: false,
    message: 'Too many login attempts. Please wait 15 minutes before trying again.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = {
  otpLimiter,
  authLimiter,
};
