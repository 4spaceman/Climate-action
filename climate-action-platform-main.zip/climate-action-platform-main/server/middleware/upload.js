const multer = require('multer');
const path = require('path');
const crypto = require('crypto');

// Allowed image MIME types and extensions
const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp'];

// Storage engine configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let subfolder = 'actions';
    if (req.baseUrl.includes('user') || req.path.includes('avatar') || req.path.includes('profile')) {
      subfolder = 'profiles';
    } else if (req.baseUrl.includes('community') || req.path.includes('post')) {
      subfolder = 'posts';
    }
    cb(null, path.join(__dirname, `../uploads/${subfolder}`));
  },
  filename: function (req, file, cb) {
    const randomHex = crypto.randomBytes(8).toString('hex');
    const ext = path.extname(file.originalname).toLowerCase();
    const cleanExt = ALLOWED_EXTENSIONS.includes(ext) ? ext : '.jpg';
    cb(null, `${Date.now()}-${randomHex}${cleanExt}`);
  },
});

// Strict file filter enforcing photo-only requirement and rejecting video formats
const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();

  // Explicitly check and reject video formats
  const videoExtensions = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.flv', '.wmv', '.3gp'];
  if (videoExtensions.includes(ext) || (file.mimetype && file.mimetype.startsWith('video/'))) {
    return cb(new Error('Video uploads are strictly prohibited. Please upload a clear photo proof (JPG, PNG, WEBP).'), false);
  }

  // Validate allowed photo formats
  if (ALLOWED_MIME_TYPES.includes(file.mimetype) && ALLOWED_EXTENSIONS.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid image format. Allowed formats: JPG, JPEG, PNG, WEBP.'), false);
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: Number(process.env.UPLOAD_MAX_SIZE) || 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: fileFilter,
});

module.exports = upload;
