const mongoose = require('mongoose');

const actionSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    title: {
      type: String,
      required: [true, 'Action title is required'],
      trim: true,
    },
    category: {
      type: String,
      enum: ['transportation', 'energy', 'water', 'waste', 'food', 'nature', 'shopping', 'other'],
      required: [true, 'Category is required'],
      index: true,
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      maxlength: [1000, 'Description cannot exceed 1000 characters'],
    },
    date: {
      type: Date,
      default: Date.now,
      index: true,
    },
    photoProof: {
      type: String,
      required: [true, 'Photo proof is strictly required'],
    },
    photoOriginalName: {
      type: String,
      default: '',
    },
    photoMimeType: {
      type: String,
      default: '',
    },
    photoSizeBytes: {
      type: Number,
      default: 0,
    },
    quantity: {
      type: Number,
      default: 1,
      min: 0.1,
    },
    unit: {
      type: String,
      default: 'action',
    },
    verificationStatus: {
      type: String,
      enum: ['pending', 'under_review', 'approved', 'rejected'],
      default: 'pending',
      index: true,
    },
    verifiedAt: {
      type: Date,
      default: null,
    },
    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    rejectionReason: {
      type: String,
      default: '',
    },
    pointsEarned: {
      type: Number,
      default: 0,
    },
    impact: {
      co2AvoidedKg: {
        type: Number,
        default: 0,
      },
      waterSavedLitres: {
        type: Number,
        default: 0,
      },
      energyReducedKwh: {
        type: Number,
        default: 0,
      },
      wasteAvoidedKg: {
        type: Number,
        default: 0,
      },
      explanation: {
        type: String,
        default: '',
      },
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for fast querying
actionSchema.index({ user: 1, verificationStatus: 1 });
actionSchema.index({ user: 1, date: -1 });

module.exports = mongoose.model('Action', actionSchema);
