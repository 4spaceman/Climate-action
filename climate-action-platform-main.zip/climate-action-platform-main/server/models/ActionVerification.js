const mongoose = require('mongoose');

const actionVerificationSchema = new mongoose.Schema(
  {
    action: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Action',
      required: true,
      unique: true,
      index: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    autoVerificationResult: {
      passed: { type: Boolean, default: false },
      confidence: { type: Number, default: 0 },
      checks: [
        {
          name: { type: String, required: true },
          passed: { type: Boolean, required: true },
          details: { type: String, default: '' },
        },
      ],
      reason: { type: String, default: '' },
    },
    stage: {
      type: String,
      enum: ['automatic', 'admin_review'],
      default: 'automatic',
    },
    adminDecision: {
      decision: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending',
      },
      adminId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
      },
      reason: {
        type: String,
        default: '',
      },
      decidedAt: {
        type: Date,
        default: null,
      },
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('ActionVerification', actionVerificationSchema);
