const mongoose = require('mongoose');

const climateProfileSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
      index: true,
    },
    transportation: {
      primaryCommute: {
        type: String,
        enum: ['motorcycle', 'car', 'public_transit', 'cycling', 'walking', 'ev', 'work_from_home'],
        default: 'public_transit',
      },
      weeklyKm: {
        type: Number,
        default: 50,
      },
      carpoolFrequency: {
        type: String,
        enum: ['never', 'sometimes', 'regularly', 'always'],
        default: 'sometimes',
      },
    },
    energy: {
      acUsageHoursPerDay: {
        type: Number,
        default: 2,
      },
      solarPowered: {
        type: Boolean,
        default: false,
      },
      appliancesOffWhenIdle: {
        type: Boolean,
        default: true,
      },
      ledLightingPercentage: {
        type: Number,
        default: 50,
      },
    },
    water: {
      showerDurationMins: {
        type: Number,
        default: 10,
      },
      runningTapHabit: {
        type: Boolean,
        default: false,
      },
      rainwaterHarvesting: {
        type: Boolean,
        default: false,
      },
      waterReuseHabit: {
        type: Boolean,
        default: false,
      },
    },
    food: {
      dietType: {
        type: String,
        enum: ['omnivore', 'pescatarian', 'vegetarian', 'vegan'],
        default: 'omnivore',
      },
      mealsWithMeatPerWeek: {
        type: Number,
        default: 7,
      },
      foodWasteFrequency: {
        type: String,
        enum: ['rarely', 'sometimes', 'often'],
        default: 'sometimes',
      },
      foodDeliveryWeeklyCount: {
        type: Number,
        default: 2,
      },
    },
    waste: {
      recyclePlastics: {
        type: Boolean,
        default: true,
      },
      wasteSeparation: {
        type: Boolean,
        default: true,
      },
      singleUseBottlesWeekly: {
        type: Number,
        default: 3,
      },
      repairBeforeReplace: {
        type: Boolean,
        default: true,
      },
      responsibleEWasteDisposal: {
        type: Boolean,
        default: true,
      },
    },
    shopping: {
      clothingPurchasesPerYear: {
        type: Number,
        default: 10,
      },
      preferSustainableBrands: {
        type: Boolean,
        default: false,
      },
      bringsReusableBags: {
        type: Boolean,
        default: true,
      },
    },
    nature: {
      plantsTreesAnnually: {
        type: Boolean,
        default: false,
      },
      gardeningOrHouseplants: {
        type: Boolean,
        default: true,
      },
      participatesInCleanups: {
        type: Boolean,
        default: false,
      },
    },
    climateAwareness: {
      concernLevel: {
        type: Number,
        min: 1,
        max: 5,
        default: 4,
      },
      primaryMotivation: {
        type: String,
        default: 'Future generation wellbeing & ecosystem preservation',
      },
      actionFrequency: {
        type: String,
        enum: ['daily', 'weekly', 'occasionally', 'just_starting'],
        default: 'weekly',
      },
    },
    calculatedBaselineScore: {
      type: Number,
      default: 50,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('ClimateProfile', climateProfileSchema);
