const mongoose = require('mongoose');

const communitySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Community name is required'],
      unique: true,
      trim: true,
      minlength: [3, 'Community name must be at least 3 characters'],
      maxlength: [60, 'Community name cannot exceed 60 characters'],
      index: true,
    },
    description: {
      type: String,
      required: [true, 'Community description is required'],
      maxlength: [500, 'Description cannot exceed 500 characters'],
    },
    creator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    image: {
      type: String,
      default: '',
    },
    category: {
      type: String,
      default: 'General Sustainability',
    },
    isPublic: {
      type: Boolean,
      default: true,
    },
    memberCount: {
      type: Number,
      default: 1,
    },
    totalPoints: {
      type: Number,
      default: 0,
      index: true,
    },
    totalCO2Avoided: {
      type: Number,
      default: 0,
    },
    totalActionsVerified: {
      type: Number,
      default: 0,
    },
    pointsLastUpdatedAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Community', communitySchema);
