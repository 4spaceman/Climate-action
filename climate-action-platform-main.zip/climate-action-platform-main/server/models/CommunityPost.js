const mongoose = require('mongoose');

const communityPostSchema = new mongoose.Schema(
  {
    community: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Community',
      required: true,
      index: true,
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    content: {
      type: String,
      required: [true, 'Post content cannot be empty'],
      maxlength: [2000, 'Post content cannot exceed 2000 characters'],
    },
    photo: {
      type: String,
      default: '',
    },
    likesCount: {
      type: Number,
      default: 0,
    },
    commentsCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

communityPostSchema.index({ community: 1, createdAt: -1 });

module.exports = mongoose.model('CommunityPost', communityPostSchema);
