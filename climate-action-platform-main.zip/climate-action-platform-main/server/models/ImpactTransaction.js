const mongoose = require('mongoose');

const impactTransactionSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    action: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Action',
      required: true,
      unique: true, // Prevents duplicate point awards
      index: true,
    },
    category: {
      type: String,
      required: true,
      index: true,
    },
    points: {
      type: Number,
      required: true,
    },
    co2AvoidedKg: {
      type: Number,
      default: 0,
    },
    waterSavedLitres: {
      type: Number,
      default: 0,
    },
    energyReducedKwh: {
      type: Number,
      default: 0,
    },
    wasteAvoidedKg: {
      type: Number,
      default: 0,
    },
    calculationNotes: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

impactTransactionSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('ImpactTransaction', impactTransactionSchema);
