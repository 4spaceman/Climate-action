const mongoose = require('mongoose');

const reactionSchema = new mongoose.Schema(
  {
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CommunityPost',
      required: true,
      index: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    type: {
      type: String,
      enum: ['like', 'clap', 'seedling', 'flame', 'heart'],
      default: 'seedling',
    },
  },
  {
    timestamps: true,
  }
);

// Prevent duplicate reactions from the same user on the same post
reactionSchema.index({ post: 1, user: 1 }, { unique: true });

module.exports = mongoose.model('Reaction', reactionSchema);
