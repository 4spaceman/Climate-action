const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    category: {
      type: String,
      required: true,
      index: true,
    },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    estimatedImpact: {
      type: String,
      required: true,
    },
    potentialPoints: {
      type: Number,
      required: true,
    },
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'easy',
    },
    sourceHabit: {
      type: String,
      required: true, // Transparent rule rationale explaining why this was recommended
    },
    isCompleted: {
      type: Boolean,
      default: false,
    },
    completedActionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Action',
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

recommendationSchema.index({ user: 1, isCompleted: 1 });

module.exports = mongoose.model('Recommendation', recommendationSchema);
