const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: [100, 'Name cannot exceed 100 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters'],
      select: false, // Never return password in queries by default
    },
    role: {
      type: String,
      enum: ['user', 'admin'],
      default: 'user',
      index: true,
    },
    isEmailVerified: {
      type: Boolean,
      default: false,
      index: true,
    },
    avatar: {
      type: String,
      default: '',
    },
    city: {
      type: String,
      default: '',
      trim: true,
    },
    occupation: {
      type: String,
      enum: ['student', 'employee', 'self-employed', 'homemaker', 'other', ''],
      default: '',
    },
    college: {
      type: String,
      default: '',
      trim: true,
    },
    company: {
      type: String,
      default: '',
      trim: true,
    },
    jobRole: {
      type: String,
      default: '',
      trim: true,
    },
    livingSituation: {
      type: String,
      default: '',
      trim: true,
    },
    interests: {
      type: [String],
      default: [],
    },
    climateGoals: {
      type: [String],
      default: [],
    },
    bio: {
      type: String,
      default: '',
      maxlength: [500, 'Bio cannot exceed 500 characters'],
    },
    isOnboarded: {
      type: Boolean,
      default: false,
    },
    hasCompletedAssessment: {
      type: Boolean,
      default: false,
    },

    // Metrics (Strictly derived and updated through verified action transactions)
    totalPoints: {
      type: Number,
      default: 0,
      index: true,
    },
    climateActionScore: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },
    currentStreak: {
      type: Number,
      default: 0,
    },
    longestStreak: {
      type: Number,
      default: 0,
    },
    lastActiveDate: {
      type: Date,
      default: null,
    },
    totalVerifiedActions: {
      type: Number,
      default: 0,
    },
    totalCO2Avoided: {
      type: Number,
      default: 0, // kg
    },
    totalWaterSaved: {
      type: Number,
      default: 0, // Litres
    },
    totalEnergyReduced: {
      type: Number,
      default: 0, // kWh
    },
    totalWasteAvoided: {
      type: Number,
      default: 0, // kg
    },
    followersCount: {
      type: Number,
      default: 0,
    },
    followingCount: {
      type: Number,
      default: 0,
    },
    activeCommunityId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Community',
      default: null,
    },
    pointsLastUpdatedAt: {
      type: Date,
      default: Date.now,
      index: true, // Used for tie-breaking on leaderboards
    },
    lastStreakNotificationDate: {
      type: Date,
      default: null,
    },
    lastDailyReminderDate: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// Hash password before saving if modified
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Filter safe public profile
userSchema.methods.toPublicProfile = function () {
  return {
    id: this._id,
    _id: this._id,
    name: this.name,
    avatar: this.avatar,
    city: this.city,
    occupation: this.occupation,
    college: this.college,
    company: this.company,
    jobRole: this.jobRole,
    bio: this.bio,
    interests: this.interests,
    climateGoals: this.climateGoals,
    totalPoints: this.totalPoints,
    climateActionScore: this.climateActionScore,
    currentStreak: this.currentStreak,
    longestStreak: this.longestStreak,
    totalVerifiedActions: this.totalVerifiedActions,
    totalCO2Avoided: this.totalCO2Avoided,
    totalWaterSaved: this.totalWaterSaved,
    totalEnergyReduced: this.totalEnergyReduced,
    totalWasteAvoided: this.totalWasteAvoided,
    followersCount: this.followersCount,
    followingCount: this.followingCount,
    createdAt: this.createdAt,
  };
};

module.exports = mongoose.model('User', userSchema);
