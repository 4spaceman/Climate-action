const express = require('express');
const router = express.Router();
const actionController = require('../controllers/actionController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Report a new climate action with mandatory photo proof
router.post('/report', protect, upload.single('photoProof'), actionController.reportAction);

// Get action history (filtered by status or category)
router.get('/history', protect, actionController.getActionHistory);

// Get single action by ID
router.get('/:id', protect, actionController.getActionById);

module.exports = router;
