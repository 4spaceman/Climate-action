const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { protect } = require('../middleware/auth');
const { adminOnly } = require('../middleware/admin');

// Apply protection and admin authorization to all admin endpoints
router.use(protect, adminOnly);

// Real platform statistics aggregated from MongoDB
router.get('/stats', adminController.getPlatformStats);

// Pending & under_review action verification queue
router.get('/actions/pending', adminController.getPendingActions);

// Approve action
router.post('/actions/:actionId/approve', adminController.approveAction);

// Reject action
router.post('/actions/:actionId/reject', adminController.rejectAction);

// User management
router.get('/users', adminController.getUsers);
router.patch('/users/:userId/role', adminController.toggleUserRole);

module.exports = router;
