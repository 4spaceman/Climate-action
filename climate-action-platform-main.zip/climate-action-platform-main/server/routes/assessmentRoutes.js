const express = require('express');
const router = express.Router();
const assessmentController = require('../controllers/assessmentController');
const { protect } = require('../middleware/auth');

// Submit or update climate lifestyle assessment
router.post('/', protect, assessmentController.submitAssessment);

// Get current user's climate assessment
router.get('/', protect, assessmentController.getAssessment);

module.exports = router;
