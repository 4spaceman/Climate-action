const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { protect } = require('../middleware/auth');
const { otpLimiter, authLimiter } = require('../middleware/rateLimiter');

// Step 1: Send OTP to email for signup
router.post('/signup-otp', otpLimiter, authController.sendSignupOtp);

// Step 2: Verify OTP and create verified account
router.post('/register', authLimiter, authController.verifyAndRegister);

// Login
router.post('/login', authLimiter, authController.login);

// Forgot password OTP
router.post('/forgot-password', otpLimiter, authController.forgotPassword);

// Reset password with OTP
router.post('/reset-password', authLimiter, authController.resetPassword);

// Current user session
router.get('/me', protect, authController.getMe);

// Logout
router.post('/logout', authController.logout);

module.exports = router;
