const express = require('express');
const router = express.Router();
const communityController = require('../controllers/communityController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Optional protect helper for viewing communities
const optionalProtect = async (req, res, next) => {
  const jwt = require('jsonwebtoken');
  const User = require('../models/User');
  try {
    let token = req.cookies?.token;
    if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'climate_action_default_secret');
      req.user = await User.findById(decoded.id);
    }
  } catch (err) {}
  next();
};

// Create a new community (1 active community per user creator)
router.post('/', protect, upload.single('image'), communityController.createCommunity);

// List/search communities
router.get('/', optionalProtect, communityController.getCommunities);

// Get community details
router.get('/:id', optionalProtect, communityController.getCommunityById);

// Join community
router.post('/:id/join', protect, communityController.joinCommunity);

// Leave community
router.post('/:id/leave', protect, communityController.leaveCommunity);

// Update community details (admin/creator)
router.put('/:id', protect, communityController.updateCommunity);

// Delete community (admin/creator)
router.delete('/:id', protect, communityController.deleteCommunity);

// Community Posts
router.post('/posts', protect, upload.single('photo'), communityController.createPost);
router.get('/:communityId/posts', optionalProtect, communityController.getPosts);
router.delete('/posts/:postId', protect, communityController.deletePost);

// Comments on posts
router.post('/posts/:postId/comments', protect, communityController.addComment);
router.get('/posts/:postId/comments', optionalProtect, communityController.getComments);

// Reactions on posts
router.post('/posts/:postId/react', protect, communityController.toggleReaction);

module.exports = router;
