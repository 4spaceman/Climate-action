const express = require('express');
const router = express.Router();
const followController = require('../controllers/followController');
const { protect } = require('../middleware/auth');

// Follow a user
router.post('/:targetUserId', protect, followController.followUser);

// Unfollow a user
router.delete('/:targetUserId', protect, followController.unfollowUser);

// Remove a follower
router.delete('/follower/:followerUserId', protect, followController.removeFollower);

// Get followers of user
router.get('/followers/:userId?', protect, followController.getFollowers);

// Get following of user
router.get('/following/:userId?', protect, followController.getFollowing);

module.exports = router;
