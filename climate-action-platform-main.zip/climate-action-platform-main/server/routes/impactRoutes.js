const express = require('express');
const router = express.Router();
const impactController = require('../controllers/impactController');
const { protect } = require('../middleware/auth');

// Get estimated environmental impact summary & category breakdown
router.get('/summary', protect, impactController.getUserImpactSummary);

// Get traceable impact transactions log
router.get('/transactions', protect, impactController.getImpactTransactions);

module.exports = router;
