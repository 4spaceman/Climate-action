const express = require('express');
const router = express.Router();
const leaderboardController = require('../controllers/leaderboardController');
const { protect } = require('../middleware/auth');

// Optional protect middleware so public visitors can view, but logged in users get their personal rank
const optionalProtect = async (req, res, next) => {
  const jwt = require('jsonwebtoken');
  const User = require('../models/User');
  try {
    let token = req.cookies?.token;
    if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'climate_action_default_secret');
      req.user = await User.findById(decoded.id);
    }
  } catch (err) {
    // Ignore invalid token for optional auth
  }
  next();
};

// Global worldwide leaderboard
router.get('/global', optionalProtect, leaderboardController.getGlobalLeaderboard);

// Community leaderboard
router.get('/communities', leaderboardController.getCommunityLeaderboard);

module.exports = router;
