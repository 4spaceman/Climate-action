const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');
const { protect } = require('../middleware/auth');

// Get all notifications for user
router.get('/', protect, notificationController.getNotifications);

// Mark all as read
router.patch('/read-all', protect, notificationController.markAllAsRead);

// Mark single as read
router.patch('/:id/read', protect, notificationController.markAsRead);

// Delete notification
router.delete('/:id', protect, notificationController.deleteNotification);

module.exports = router;
