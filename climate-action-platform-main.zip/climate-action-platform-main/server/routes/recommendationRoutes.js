const express = require('express');
const router = express.Router();
const recommendationController = require('../controllers/recommendationController');
const { protect } = require('../middleware/auth');

// Get personalized recommendations for user
router.get('/', protect, recommendationController.getRecommendations);

// Get daily actions for today
router.get('/daily', protect, recommendationController.getDailyActions);

module.exports = router;
