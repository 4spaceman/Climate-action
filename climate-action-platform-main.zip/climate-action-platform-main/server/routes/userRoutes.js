const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Update current user profile
router.put('/profile', protect, userController.updateProfile);

// Upload profile avatar photo
router.post('/avatar', protect, upload.single('avatar'), userController.uploadAvatar);

// Get user activity heatmap
router.get('/heatmap/:id?', protect, userController.getUserHeatmap);

// Get public profile of any user (by id)
router.get('/:id', protect, userController.getPublicProfile);

module.exports = router;
