require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const compression = require('compression');
const { connectDB } = require('./config/db');
const { initScheduler } = require('./services/schedulerService');

// Route imports
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const assessmentRoutes = require('./routes/assessmentRoutes');
const recommendationRoutes = require('./routes/recommendationRoutes');
const actionRoutes = require('./routes/actionRoutes');
const impactRoutes = require('./routes/impactRoutes');
const leaderboardRoutes = require('./routes/leaderboardRoutes');
const communityRoutes = require('./routes/communityRoutes');
const followRoutes = require('./routes/followRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Security & Utility Middleware
app.use(
  helmet({
    contentSecurityPolicy: false, // Allows CDN scripts for Lucide Icons & Chart.js
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);
app.use(
  cors({
    origin: process.env.CLIENT_URL || true,
    credentials: true,
  })
);
app.use(compression());
app.use(cookieParser());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static file serving
// 1. Uploaded user photo proofs and avatars
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 2. Client frontend files (HTML, CSS, JS, Assets)
app.use(express.static(path.join(__dirname, '../client')));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'ClimateAction Platform API',
  });
});

// REST API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/assessment', assessmentRoutes);
app.use('/api/recommendations', recommendationRoutes);
app.use('/api/actions', actionRoutes);
app.use('/api/impact', impactRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/communities', communityRoutes);
app.use('/api/social', followRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/admin', adminRoutes);

// SPA Fallback: Send client/index.html for any unhandled GET request
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/uploads')) {
    return next();
  }
  res.sendFile(path.join(__dirname, '../client/index.html'));
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);

  if (
    err.name === 'MulterError' ||
    err.message.includes('Video uploads are strictly prohibited') ||
    err.message.includes('Invalid image format') ||
    err.message.includes('Photo proof')
  ) {
    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }

  const statusCode = err.statusCode || 500;
  const message = err.message || 'An unexpected error occurred on the server.';

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

// Start Server
async function startServer() {
  await connectDB();
  initScheduler();

  const server = app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`🌍 ClimateAction Platform Server Active!`);
    console.log(`🚀 Access Website: http://localhost:${PORT}`);
    console.log(`🛰️  Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`====================================================`);
  });

  // Handle unhandled rejections and termination signals
  process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
  });

  process.on('SIGTERM', () => {
    console.log('SIGTERM signal received. Closing HTTP server gracefully.');
    server.close(() => {
      console.log('HTTP server closed.');
    });
  });

  return server;
}

if (require.main === module) {
  startServer();
}

module.exports = { app, startServer };
