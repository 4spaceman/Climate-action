const nodemailer = require('nodemailer');

let transporter = null;
let testAccount = null;

// Initialize Nodemailer transporter
async function initTransporter() {
  if (transporter) return transporter;

  const host = process.env.EMAIL_HOST;
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASSWORD;

  if (host && user && pass) {
    // Real production SMTP configuration
    transporter = nodemailer.createTransport({
      host: host,
      port: Number(process.env.EMAIL_PORT) || 587,
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: user,
        pass: pass,
      },
    });
    console.log(`📧 Configured real SMTP email transporter via ${host}`);
  } else {
    // Real development/testing transporter with Ethereal email
    try {
      testAccount = await nodemailer.createTestAccount();
      transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass,
        },
      });
      console.log(`📧 Ethereal test SMTP active for development (Account: ${testAccount.user})`);
    } catch (err) {
      console.warn('⚠️  Could not create Ethereal account, using json/stream transport:', err.message);
      transporter = nodemailer.createTransport({
        jsonTransport: true,
      });
    }
  }

  return transporter;
}

/**
 * Base email sender helper
 */
async function sendMail({ to, subject, html, text }) {
  try {
    const mailer = await initTransporter();
    const fromAddress = process.env.EMAIL_FROM || '"ClimateAction" <noreply@climateaction.org>';

    const info = await mailer.sendMail({
      from: fromAddress,
      to,
      subject,
      text: text || html.replace(/<[^>]+>/g, ''),
      html,
    });

    const previewUrl = nodemailer.getTestMessageUrl(info);
    if (previewUrl) {
      console.log(`✉️  Email sent to ${to}! View preview at: ${previewUrl}`);
    } else {
      console.log(`✉️  Email sent successfully to ${to} (MessageId: ${info.messageId})`);
    }

    return { success: true, messageId: info.messageId, previewUrl };
  } catch (error) {
    console.error(`❌ Failed to deliver email to ${to}:`, error.message);
    return { success: false, error: error.message };
  }
}

/**
 * 1. Send 6-Digit OTP Email
 */
async function sendOtpEmail(email, otp, type = 'email_verification') {
  const isVerification = type === 'email_verification';
  const title = isVerification ? 'Verify Your ClimateAction Account' : 'Reset Your Password';
  const subtitle = isVerification
    ? 'Welcome to ClimateAction! Use the single-use 6-digit passcode below to verify your email address and activate your account.'
    : 'A password reset request was received for your ClimateAction account. Use the 6-digit code below to set your new password.';

  const html = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 580px; margin: 0 auto; background-color: #F8FAFC; padding: 32px 16px;">
      <div style="background-color: #FFFFFF; border-radius: 12px; border: 1px solid #E2E8F0; padding: 36px 28px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
        <div style="text-align: center; margin-bottom: 24px;">
          <div style="display: inline-block; background-color: #ECFDF5; padding: 12px 18px; border-radius: 50px;">
            <span style="color: #10B981; font-weight: 700; font-size: 20px; letter-spacing: -0.5px;">🌱 ClimateAction</span>
          </div>
        </div>
        <h2 style="color: #0F172A; text-align: center; font-size: 22px; font-weight: 700; margin: 0 0 12px 0;">${title}</h2>
        <p style="color: #64748B; font-size: 15px; line-height: 24px; text-align: center; margin: 0 0 28px 0;">${subtitle}</p>
        
        <div style="background-color: #ECFDF5; border: 2px dashed #10B981; border-radius: 12px; padding: 20px; text-align: center; margin-bottom: 28px;">
          <span style="font-size: 34px; font-weight: 800; letter-spacing: 8px; color: #14532D; font-family: monospace;">${otp}</span>
          <p style="margin: 8px 0 0 0; color: #047857; font-size: 13px; font-weight: 500;">Valid for 10 minutes &bull; Do not share with anyone</p>
        </div>

        <p style="color: #94A3B8; font-size: 13px; line-height: 20px; text-align: center; margin: 0;">
          If you didn't request this email, you can safely ignore it. Your account remains secure.
        </p>
      </div>
      <div style="text-align: center; margin-top: 20px; color: #94A3B8; font-size: 12px;">
        &copy; ${new Date().getFullYear()} ClimateAction. Accelerating personal sustainability and SDG 13 climate stewardship.
      </div>
    </div>
  `;

  return sendMail({
    to: email,
    subject: `[ClimateAction] Your verification code is ${otp}`,
    html,
  });
}

/**
 * 2. Send Personalized Daily Climate Action Reminder
 */
async function sendDailyReminderEmail(user, recommendation) {
  const recoTitle = recommendation ? recommendation.title : 'Take a short walk or bike ride today';
  const recoDesc = recommendation ? recommendation.description : 'Avoid emissions on short trips and stay active.';
  const recoImpact = recommendation ? recommendation.estimatedImpact : 'Estimated 0.9 kg CO2 avoided';

  const html = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 580px; margin: 0 auto; background-color: #F8FAFC; padding: 32px 16px;">
      <div style="background-color: #FFFFFF; border-radius: 12px; border: 1px solid #E2E8F0; padding: 36px 28px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <span style="color: #10B981; font-weight: 700; font-size: 20px;">🌱 ClimateAction Daily</span>
        </div>
        <h2 style="color: #0F172A; font-size: 20px; font-weight: 700; margin-bottom: 8px;">Hi ${user.name}, here is your climate habit for today!</h2>
        <p style="color: #64748B; font-size: 15px; line-height: 24px;">Small, consistent daily habits drive meaningful global transformation.</p>

        <div style="background-color: #F8FAFC; border-left: 4px solid #10B981; padding: 16px 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin: 0 0 6px 0; color: #14532D; font-size: 16px;">🎯 ${recoTitle}</h3>
          <p style="margin: 0 0 8px 0; color: #334155; font-size: 14px;">${recoDesc}</p>
          <span style="background-color: #ECFDF5; color: #047857; font-size: 12px; font-weight: 600; padding: 4px 8px; border-radius: 4px;">${recoImpact}</span>
        </div>

        <p style="color: #64748B; font-size: 14px; line-height: 22px;">
          Current streak: <strong>${user.currentStreak || 0} days</strong> &bull; Report your action with photo proof to preserve your streak and earn impact points.
        </p>

        <div style="text-align: center; margin-top: 24px;">
          <a href="${process.env.CLIENT_URL || 'http://localhost:3000'}#report" style="background-color: #10B981; color: #FFFFFF; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">Report Action & Upload Proof</a>
        </div>
      </div>
    </div>
  `;

  return sendMail({
    to: user.email,
    subject: `🌱 Your daily climate action reminder: ${recoTitle}`,
    html,
  });
}

/**
 * 3. Send Missed Streak Reminder
 */
async function sendMissedStreakEmail(user, previousStreak = 1) {
  const html = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 580px; margin: 0 auto; background-color: #F8FAFC; padding: 32px 16px;">
      <div style="background-color: #FFFFFF; border-radius: 12px; border: 1px solid #E2E8F0; padding: 36px 28px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <span style="color: #10B981; font-weight: 700; font-size: 20px;">🌱 ClimateAction</span>
        </div>
        <h2 style="color: #0F172A; font-size: 20px; font-weight: 700; margin-bottom: 8px;">You missed your streak yesterday!</h2>
        <p style="color: #64748B; font-size: 15px; line-height: 24px;">
          You were building a great ${previousStreak}-day climate-action streak. Life gets busy, but every day is a fresh opportunity to champion the planet.
        </p>
        <p style="color: #334155; font-size: 15px; font-weight: 500;">
          Come back today and start your new streak with a simple verified climate action!
        </p>
        <div style="text-align: center; margin-top: 24px;">
          <a href="${process.env.CLIENT_URL || 'http://localhost:3000'}#report" style="background-color: #14532D; color: #FFFFFF; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">Restart My Streak Today</a>
        </div>
      </div>
    </div>
  `;

  return sendMail({
    to: user.email,
    subject: `🌿 You missed your streak, ${user.name} — come back and start again today!`,
    html,
  });
}

module.exports = {
  sendOtpEmail,
  sendDailyReminderEmail,
  sendMissedStreakEmail,
  sendMail,
};
