const User = require('../models/User');
const Action = require('../models/Action');
const ImpactTransaction = require('../models/ImpactTransaction');
const CommunityMembership = require('../models/CommunityMembership');
const Community = require('../models/Community');
const Notification = require('../models/Notification');
const Recommendation = require('../models/Recommendation');
const { calculateEstimatedImpact } = require('../utils/environmentalImpact');
const { calculateClimateActionScore } = require('../utils/scoreFormula');
const { calculateUserStreakAndHeatmap } = require('./streakService');

/**
 * Approves an action, records impact and points, updates streaks, score, communities, and notifications.
 * Idempotent: safe against duplicate calls.
 */
async function approveActionAndAwardImpact(actionId, reviewerId = null, reason = 'Verification criteria satisfied') {
  const action = await Action.findById(actionId);
  if (!action) throw new Error('Action not found');

  if (action.verificationStatus === 'approved') {
    // Already approved, return existing state
    return { action, alreadyApproved: true };
  }

  // 1. Calculate environmental impact and points
  const { pointsEarned, impact } = calculateEstimatedImpact(
    action.category,
    action.title,
    action.description,
    action.quantity
  );

  // 2. Update action document
  action.verificationStatus = 'approved';
  action.verifiedAt = new Date();
  action.verifiedBy = reviewerId;
  action.pointsEarned = pointsEarned;
  action.impact = impact;
  action.rejectionReason = '';
  await action.save();

  // 3. Create or update ImpactTransaction (unique by action)
  await ImpactTransaction.findOneAndUpdate(
    { action: action._id },
    {
      user: action.user,
      action: action._id,
      category: action.category,
      points: pointsEarned,
      co2AvoidedKg: impact.co2AvoidedKg,
      waterSavedLitres: impact.waterSavedLitres,
      energyReducedKwh: impact.energyReducedKwh,
      wasteAvoidedKg: impact.wasteAvoidedKg,
      calculationNotes: impact.explanation,
    },
    { upsert: true, new: true }
  );

  // 4. Recalculate streak & active days
  const { currentStreak, longestStreak, totalActiveDays } = await calculateUserStreakAndHeatmap(action.user);

  // 5. Aggregate all verified actions for this user to get exact source-of-truth totals
  const userVerifiedActions = await Action.find({
    user: action.user,
    verificationStatus: 'approved',
  }).select('category impact pointsEarned');

  const totalVerifiedActions = userVerifiedActions.length;
  let totalPoints = 0;
  let totalCO2Avoided = 0;
  let totalWaterSaved = 0;
  let totalEnergyReduced = 0;
  let totalWasteAvoided = 0;
  const distinctCategories = new Set();

  for (const act of userVerifiedActions) {
    totalPoints += act.pointsEarned || 0;
    totalCO2Avoided += act.impact?.co2AvoidedKg || 0;
    totalWaterSaved += act.impact?.waterSavedLitres || 0;
    totalEnergyReduced += act.impact?.energyReducedKwh || 0;
    totalWasteAvoided += act.impact?.wasteAvoidedKg || 0;
    if (act.category) distinctCategories.add(act.category);
  }

  // 6. Check user community status
  const userRecord = await User.findById(action.user);
  const communityMemberships = await CommunityMembership.find({ user: action.user });
  const hasCommunity = communityMemberships.length > 0;

  // 7. Calculate new Climate Action Score
  const { score: newScore } = calculateClimateActionScore({
    totalVerifiedActions,
    currentStreak,
    longestStreak,
    distinctCategoriesCount: distinctCategories.size,
    totalCO2Avoided,
    totalWaterSaved,
    totalWasteAvoided,
    activeDays: totalActiveDays,
    hasCommunity,
    followersCount: userRecord ? userRecord.followersCount : 0,
  });

  // 8. Update User document with synchronized metrics
  await User.findByIdAndUpdate(action.user, {
    totalPoints,
    climateActionScore: newScore,
    currentStreak,
    longestStreak: Math.max(longestStreak, userRecord ? userRecord.longestStreak : 0),
    totalVerifiedActions,
    totalCO2Avoided: Number(totalCO2Avoided.toFixed(3)),
    totalWaterSaved: Number(totalWaterSaved.toFixed(1)),
    totalEnergyReduced: Number(totalEnergyReduced.toFixed(2)),
    totalWasteAvoided: Number(totalWasteAvoided.toFixed(3)),
    lastActiveDate: action.date,
    pointsLastUpdatedAt: new Date(),
  });

  // 9. Update all communities the user is a member of
  for (const membership of communityMemberships) {
    await updateCommunityAggregateMetrics(membership.community);
  }

  // 10. Check if this action satisfies any active recommendation
  await Recommendation.updateMany(
    {
      user: action.user,
      category: action.category,
      isCompleted: false,
    },
    {
      isCompleted: true,
      completedActionId: action._id,
    }
  );

  // 11. Create in-app Notification
  await Notification.create({
    recipient: action.user,
    sender: reviewerId,
    type: 'action_approved',
    title: 'Action Verified & Impact Awarded!',
    message: `Your action "${action.title}" was verified! You earned +${pointsEarned} points and avoided ~${impact.co2AvoidedKg} kg CO2.`,
    data: {
      actionId: action._id,
      pointsEarned,
      impact,
      currentStreak,
    },
  });

  return {
    action,
    pointsEarned,
    impact,
    currentStreak,
    newScore,
  };
}

/**
 * Rejects an action and handles status update, reasons, and reversals if it was previously approved.
 */
async function rejectAction(actionId, reviewerId = null, reason = 'Action proof does not meet verification guidelines') {
  const action = await Action.findById(actionId);
  if (!action) throw new Error('Action not found');

  const wasApproved = action.verificationStatus === 'approved';

  action.verificationStatus = 'rejected';
  action.verifiedAt = new Date();
  action.verifiedBy = reviewerId;
  action.rejectionReason = reason;
  action.pointsEarned = 0;
  action.impact = {
    co2AvoidedKg: 0,
    waterSavedLitres: 0,
    energyReducedKwh: 0,
    wasteAvoidedKg: 0,
    explanation: 'Action not verified',
  };
  await action.save();

  // If it was previously approved, remove ImpactTransaction and re-sync user metrics
  if (wasApproved) {
    await ImpactTransaction.deleteOne({ action: action._id });
    await recalculateAllUserMetrics(action.user);
  }

  // Create notification
  await Notification.create({
    recipient: action.user,
    sender: reviewerId,
    type: 'action_rejected',
    title: 'Action Review Update',
    message: `Your action "${action.title}" could not be verified: ${reason}`,
    data: {
      actionId: action._id,
      reason,
    },
  });

  return action;
}

/**
 * Helper to recalculate community aggregate metrics
 */
async function updateCommunityAggregateMetrics(communityId) {
  const members = await CommunityMembership.find({ community: communityId }).select('user');
  const userIds = members.map((m) => m.user);

  // Sum up points and CO2 from verified actions of all members
  const memberUsers = await User.find({ _id: { $in: userIds } }).select('totalPoints totalCO2Avoided totalVerifiedActions');

  let communityPoints = 0;
  let communityCO2 = 0;
  let communityActions = 0;

  for (const u of memberUsers) {
    communityPoints += u.totalPoints || 0;
    communityCO2 += u.totalCO2Avoided || 0;
    communityActions += u.totalVerifiedActions || 0;
  }

  await Community.findByIdAndUpdate(communityId, {
    memberCount: members.length,
    totalPoints: communityPoints,
    totalCO2Avoided: Number(communityCO2.toFixed(3)),
    totalActionsVerified: communityActions,
    pointsLastUpdatedAt: new Date(),
  });
}

/**
 * Helper to recalculate a user's entire metrics from scratch
 */
async function recalculateAllUserMetrics(userId) {
  const approvedActions = await Action.find({ user: userId, verificationStatus: 'approved' });
  const { currentStreak, longestStreak, totalActiveDays } = await calculateUserStreakAndHeatmap(userId);

  let totalPoints = 0;
  let totalCO2Avoided = 0;
  let totalWaterSaved = 0;
  let totalEnergyReduced = 0;
  let totalWasteAvoided = 0;
  const distinctCategories = new Set();

  for (const act of approvedActions) {
    totalPoints += act.pointsEarned || 0;
    totalCO2Avoided += act.impact?.co2AvoidedKg || 0;
    totalWaterSaved += act.impact?.waterSavedLitres || 0;
    totalEnergyReduced += act.impact?.energyReducedKwh || 0;
    totalWasteAvoided += act.impact?.wasteAvoidedKg || 0;
    if (act.category) distinctCategories.add(act.category);
  }

  const user = await User.findById(userId);
  const memberships = await CommunityMembership.find({ user: userId });

  const { score } = calculateClimateActionScore({
    totalVerifiedActions: approvedActions.length,
    currentStreak,
    longestStreak,
    distinctCategoriesCount: distinctCategories.size,
    totalCO2Avoided,
    totalWaterSaved,
    totalWasteAvoided,
    activeDays: totalActiveDays,
    hasCommunity: memberships.length > 0,
    followersCount: user ? user.followersCount : 0,
  });

  await User.findByIdAndUpdate(userId, {
    totalPoints,
    climateActionScore: score,
    currentStreak,
    longestStreak,
    totalVerifiedActions: approvedActions.length,
    totalCO2Avoided: Number(totalCO2Avoided.toFixed(3)),
    totalWaterSaved: Number(totalWaterSaved.toFixed(1)),
    totalEnergyReduced: Number(totalEnergyReduced.toFixed(2)),
    totalWasteAvoided: Number(totalWasteAvoided.toFixed(3)),
    pointsLastUpdatedAt: new Date(),
  });

  for (const m of memberships) {
    await updateCommunityAggregateMetrics(m.community);
  }
}

module.exports = {
  approveActionAndAwardImpact,
  rejectAction,
  updateCommunityAggregateMetrics,
  recalculateAllUserMetrics,
};
