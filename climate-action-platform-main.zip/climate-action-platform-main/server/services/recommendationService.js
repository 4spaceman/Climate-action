const Recommendation = require('../models/Recommendation');

/**
 * Transparent, Rule-Based Recommendation Engine
 * Analyzes the user's ClimateProfile and produces explainable recommendations.
 */
async function generateRecommendationsForUser(userId, climateProfile) {
  // Clear any existing uncompleted recommendations for clean state or keep them
  await Recommendation.deleteMany({ user: userId, isCompleted: false });

  const recommendationsToCreate = [];

  // 1. Transportation rules
  const commute = climateProfile?.transportation?.primaryCommute;
  const weeklyKm = climateProfile?.transportation?.weeklyKm || 0;

  if (commute === 'motorcycle' || commute === 'car') {
    recommendationsToCreate.push({
      user: userId,
      category: 'transportation',
      title: 'Pedal or Walk for Trips Under 3 km',
      description: 'Replace your motorized vehicle with cycling or walking for short neighborhood commutes.',
      estimatedImpact: 'Estimated ~0.8 kg CO2 avoided per trip',
      potentialPoints: 35,
      difficulty: 'easy',
      sourceHabit: `Recommended because you reported ${commute} as your primary commute mode (${weeklyKm} km/week).`,
    });

    recommendationsToCreate.push({
      user: userId,
      category: 'transportation',
      title: 'Opt for Public Transit or Carpooling Twice This Week',
      description: 'Take the bus, metro, or share a ride for your daily route to slash single-occupancy emissions.',
      estimatedImpact: 'Estimated ~2.2 kg CO2 avoided',
      potentialPoints: 45,
      difficulty: 'medium',
      sourceHabit: `Recommended to diversify your ${weeklyKm} km/week travel away from solo combustion vehicles.`,
    });
  } else if (commute === 'cycling' || commute === 'walking') {
    recommendationsToCreate.push({
      user: userId,
      category: 'transportation',
      title: 'Inspire a Friend or Colleague to Walk/Bike',
      description: 'You already have zero-emission commute habits! Champion sustainable mobility by riding with a peer.',
      estimatedImpact: 'Estimated ~1.5 kg CO2 avoided via advocacy',
      potentialPoints: 40,
      difficulty: 'medium',
      sourceHabit: 'Recommended because you already maintain exemplary active mobility habits.',
    });
  }

  // 2. Energy rules
  const acHours = climateProfile?.energy?.acUsageHoursPerDay || 0;
  const solar = climateProfile?.energy?.solarPowered;

  if (acHours > 2) {
    recommendationsToCreate.push({
      user: userId,
      category: 'energy',
      title: 'Reduce AC Run-Time by 1-2 Hours',
      description: 'Utilize natural cross-ventilation or ceiling fans during cooler morning or evening hours.',
      estimatedImpact: 'Estimated ~1.2 kWh saved & 0.85 kg CO2 reduced',
      potentialPoints: 30,
      difficulty: 'easy',
      sourceHabit: `Recommended because you noted ${acHours} hours/day of air conditioning usage.`,
    });
  }

  recommendationsToCreate.push({
    user: userId,
    category: 'energy',
    title: 'Audit and Eliminate Phantom Power / Vampire Draw',
    description: 'Switch off power strips and unplug chargers and appliances on standby mode before bed.',
    estimatedImpact: 'Estimated ~0.5 kWh saved daily',
    potentialPoints: 25,
    difficulty: 'easy',
    sourceHabit: 'Recommended as an essential daily foundation for domestic energy efficiency.',
  });

  // 3. Water rules
  const showerMins = climateProfile?.water?.showerDurationMins || 10;
  const rainwater = climateProfile?.water?.rainwaterHarvesting;

  if (showerMins > 7) {
    recommendationsToCreate.push({
      user: userId,
      category: 'water',
      title: 'Trim 3 Minutes Off Your Daily Shower',
      description: 'Keep your shower under 5 minutes to conserve precious freshwater and water-heating energy.',
      estimatedImpact: 'Estimated ~27 Litres saved & 0.1 kg CO2 avoided',
      potentialPoints: 30,
      difficulty: 'easy',
      sourceHabit: `Recommended because your current average shower duration is ${showerMins} minutes.`,
    });
  }

  recommendationsToCreate.push({
    user: userId,
    category: 'water',
    title: 'Turn Off Tap While Brushing & Washing',
    description: 'Keep the faucet turned firmly off while soaping hands or brushing teeth.',
    estimatedImpact: 'Estimated ~12 Litres saved per session',
    potentialPoints: 20,
    difficulty: 'easy',
    sourceHabit: 'Recommended baseline water stewardship action.',
  });

  // 4. Waste & Plastic rules
  const singleUseBottles = climateProfile?.waste?.singleUseBottlesWeekly || 0;

  if (singleUseBottles > 0) {
    recommendationsToCreate.push({
      user: userId,
      category: 'waste',
      title: 'Carry a Refillable Stainless or Glass Bottle',
      description: 'Refill throughout the day to eliminate disposable single-use plastic beverage containers.',
      estimatedImpact: 'Estimated ~0.15 kg plastic diverted & 0.3 kg CO2',
      potentialPoints: 30,
      difficulty: 'easy',
      sourceHabit: `Recommended because you reported using ~${singleUseBottles} single-use plastic bottles weekly.`,
    });
  }

  recommendationsToCreate.push({
    user: userId,
    category: 'waste',
    title: 'Segregate Organics and Recyclables at Home',
    description: 'Separate wet food scraps and dry plastics/paper before disposal to facilitate circular recycling.',
    estimatedImpact: 'Estimated ~0.8 kg waste diverted from landfill',
    potentialPoints: 35,
    difficulty: 'medium',
    sourceHabit: 'Recommended to promote local circular economy and waste separation.',
  });

  // 5. Food & Diet rules
  const diet = climateProfile?.food?.dietType;
  const meatMeals = climateProfile?.food?.mealsWithMeatPerWeek || 0;

  if (diet === 'omnivore' && meatMeals > 3) {
    recommendationsToCreate.push({
      user: userId,
      category: 'food',
      title: 'Enjoy a 100% Plant-Based Lunch or Dinner',
      description: 'Choose a delicious lentil, legume, or veggie-packed meal to bypass livestock emissions.',
      estimatedImpact: 'Estimated ~1.8 kg CO2 avoided & 650 L virtual water saved',
      potentialPoints: 40,
      difficulty: 'easy',
      sourceHabit: `Recommended because your diet includes ~${meatMeals} meat meals weekly.`,
    });
  }

  recommendationsToCreate.push({
    user: userId,
    category: 'food',
    title: 'Zero Food Waste Day: Finish Leftovers Mindfully',
    description: 'Plan meal portions accurately and repurpose leftovers to prevent edible food from ending in trash.',
    estimatedImpact: 'Estimated ~0.45 kg food saved & 1.0 kg CO2 avoided',
    potentialPoints: 30,
    difficulty: 'easy',
    sourceHabit: 'Recommended to curb household food waste emissions.',
  });

  // 6. Nature & Biodiversity
  recommendationsToCreate.push({
    user: userId,
    category: 'nature',
    title: 'Plant or Tend to Urban Greenery / Native Sapling',
    description: 'Plant a potted herb, nourish indoor greenery, or care for a neighborhood street tree.',
    estimatedImpact: 'Estimated positive biodiversity habitat & microclimate cooling',
    potentialPoints: 50,
    difficulty: 'medium',
    sourceHabit: 'Recommended to strengthen local ecological resilience.',
  });

  // Save to database
  const createdRecommendations = await Recommendation.insertMany(recommendationsToCreate);
  return createdRecommendations;
}

module.exports = {
  generateRecommendationsForUser,
};
