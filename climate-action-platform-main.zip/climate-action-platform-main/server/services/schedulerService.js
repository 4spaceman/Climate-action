const cron = require('node-cron');
const User = require('../models/User');
const Recommendation = require('../models/Recommendation');
const { sendDailyReminderEmail, sendMissedStreakEmail } = require('./emailService');
const { calculateUserStreakAndHeatmap } = require('./streakService');

/**
 * Daily climate action reminder task
 */
async function processDailyReminders() {
  console.log('⏰ Running daily climate action reminder scheduler...');
  try {
    const todayStr = new Date().toISOString().split('T')[0];

    // Find active users who have completed onboarding and haven't received a reminder today
    const users = await User.find({
      isEmailVerified: true,
      isOnboarded: true,
    });

    for (const user of users) {
      if (user.lastDailyReminderDate) {
        const lastSentStr = new Date(user.lastDailyReminderDate).toISOString().split('T')[0];
        if (lastSentStr === todayStr) continue; // Already sent today
      }

      // Fetch a pending recommendation for the user
      const recommendation = await Recommendation.findOne({
        user: user._id,
        isCompleted: false,
      });

      await sendDailyReminderEmail(user, recommendation);

      user.lastDailyReminderDate = new Date();
      await user.save();
    }
  } catch (error) {
    console.error('Error in daily reminders job:', error.message);
  }
}

/**
 * Missed streak reminder task
 */
async function processMissedStreakReminders() {
  console.log('⏰ Running missed streak reminder check...');
  try {
    const todayStr = new Date().toISOString().split('T')[0];

    // Check users with positive longestStreak or past streak who were inactive yesterday
    const users = await User.find({
      isEmailVerified: true,
      longestStreak: { $gte: 2 },
      currentStreak: 0,
    });

    for (const user of users) {
      if (user.lastStreakNotificationDate) {
        const lastSentStr = new Date(user.lastStreakNotificationDate).toISOString().split('T')[0];
        if (lastSentStr === todayStr) continue;
      }

      if (user.lastActiveDate) {
        const lastActive = new Date(user.lastActiveDate);
        const now = new Date();
        const diffDays = Math.round((now.getTime() - lastActive.getTime()) / (1000 * 60 * 60 * 24));

        // Missed yesterday (diffDays is 2)
        if (diffDays === 2) {
          await sendMissedStreakEmail(user, user.longestStreak);
          user.lastStreakNotificationDate = new Date();
          await user.save();
        }
      }
    }
  } catch (error) {
    console.error('Error in missed streak job:', error.message);
  }
}

/**
 * Initialize cron schedules
 */
function initScheduler() {
  // Run every morning at 09:00 AM
  cron.schedule('0 9 * * *', async () => {
    await processDailyReminders();
    await processMissedStreakReminders();
  });

  console.log('⏱️  Background cron scheduler initialized (Daily reminders & streak checks)');
}

module.exports = {
  initScheduler,
  processDailyReminders,
  processMissedStreakReminders,
};
