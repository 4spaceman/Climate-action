const Action = require('../models/Action');

/**
 * Calculates current streak, longest streak, total active days,
 * and daily activity heatmap based solely on real verified actions.
 */
async function calculateUserStreakAndHeatmap(userId) {
  // Fetch all approved actions for the user sorted by date ascending
  const approvedActions = await Action.find({
    user: userId,
    verificationStatus: 'approved',
  })
    .select('date pointsEarned category impact')
    .sort({ date: 1 })
    .lean();

  if (!approvedActions || approvedActions.length === 0) {
    return {
      currentStreak: 0,
      longestStreak: 0,
      totalActiveDays: 0,
      heatmapData: {},
      activityByDate: {},
    };
  }

  // Aggregate by calendar date (YYYY-MM-DD) in local/UTC standard
  const dailyMap = {};
  for (const act of approvedActions) {
    const d = new Date(act.date);
    const dateStr = d.toISOString().split('T')[0];

    if (!dailyMap[dateStr]) {
      dailyMap[dateStr] = {
        date: dateStr,
        count: 0,
        points: 0,
        co2Avoided: 0,
        actions: [],
      };
    }
    dailyMap[dateStr].count += 1;
    dailyMap[dateStr].points += act.pointsEarned || 0;
    dailyMap[dateStr].co2Avoided += act.impact?.co2AvoidedKg || 0;
  }

  const sortedDates = Object.keys(dailyMap).sort();
  const totalActiveDays = sortedDates.length;

  // Calculate streaks
  let longestStreak = 0;
  let tempStreak = 0;
  let prevDate = null;

  for (const dateStr of sortedDates) {
    const curDate = new Date(dateStr);
    if (!prevDate) {
      tempStreak = 1;
    } else {
      const diffMs = curDate.getTime() - prevDate.getTime();
      const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        tempStreak += 1;
      } else if (diffDays > 1) {
        tempStreak = 1;
      }
    }
    prevDate = curDate;
    if (tempStreak > longestStreak) {
      longestStreak = tempStreak;
    }
  }

  // Check if current streak is active (active today or yesterday)
  const todayStr = new Date().toISOString().split('T')[0];
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  let currentStreak = 0;
  const lastActiveDateStr = sortedDates[sortedDates.length - 1];

  if (lastActiveDateStr === todayStr || lastActiveDateStr === yesterdayStr) {
    // Traverse backwards from last active date to count current streak
    currentStreak = 1;
    let checkDate = new Date(lastActiveDateStr);

    for (let i = sortedDates.length - 2; i >= 0; i--) {
      const prev = new Date(sortedDates[i]);
      const diffDays = Math.round((checkDate.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        currentStreak += 1;
        checkDate = prev;
      } else {
        break;
      }
    }
  } else {
    // Current streak has lapsed
    currentStreak = 0;
  }

  // Generate GitHub-style heatmap data for the past 365 days
  // Intensity 0 - 4 based on real actions and points:
  // 0: 0 actions
  // 1: 1 action
  // 2: 2 actions or >= 30 pts
  // 3: 3 actions or >= 60 pts
  // 4: 4+ actions or >= 100 pts
  const heatmapData = {};
  for (const [dStr, info] of Object.entries(dailyMap)) {
    let level = 0;
    if (info.count >= 4 || info.points >= 100) {
      level = 4;
    } else if (info.count >= 3 || info.points >= 60) {
      level = 3;
    } else if (info.count >= 2 || info.points >= 30) {
      level = 2;
    } else if (info.count >= 1) {
      level = 1;
    }
    heatmapData[dStr] = {
      level,
      count: info.count,
      points: info.points,
      co2: Number(info.co2Avoided.toFixed(2)),
    };
  }

  return {
    currentStreak,
    longestStreak,
    totalActiveDays,
    heatmapData,
    dailyMap,
  };
}

module.exports = {
  calculateUserStreakAndHeatmap,
};
