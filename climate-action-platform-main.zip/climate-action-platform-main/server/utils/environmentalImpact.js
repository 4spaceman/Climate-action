/**
 * Centralized Environmental Impact Constants and Estimation Engine
 * All calculations are transparent, scientifically referenced, and explainable.
 * Wording strictly uses "Estimated environmental impact".
 */

const IMPACT_FACTORS = {
  transportation: {
    basePoints: 20,
    co2PerKmCarAvoided: 0.192, // kg CO2 avoided per km vs average passenger vehicle (EPA / DEFRA)
    co2PerKmTransit: 0.105,     // kg CO2 avoided per km vs solo driving
    defaultKm: 5,
  },
  energy: {
    basePoints: 15,
    co2PerKwh: 0.42,           // kg CO2 per kWh avoided (average grid intensity)
    acKwhPerHour: 1.2,          // kWh per hour of split AC
    ledSavingsKwhPerDay: 0.35,  // kWh saved per day
  },
  water: {
    basePoints: 15,
    litresPerMinShower: 9.0,    // Average shower head flow rate
    co2PerLitreHotWater: 0.0035,// kg CO2 per litre of heated water energy
    tapSavingsLitres: 12.0,     // Litres saved by not running tap
    rainwaterLitres: 40.0,
  },
  waste: {
    basePoints: 15,
    plasticBottleWasteKg: 0.03, // kg plastic diverted per bottle
    plasticBagWasteKg: 0.008,
    co2PerKgPlasticRecycled: 1.5,
    repairWasteAvoidedKg: 1.5,
  },
  food: {
    basePoints: 25,
    vegetarianMealCo2Avoided: 1.85, // kg CO2 avoided compared to high-meat meal (Poore & Nemecek, Science)
    veganMealCo2Avoided: 2.4,
    virtualWaterSavedLitres: 650,    // Litres of virtual water saved per plant meal
    foodWasteAvoidedKg: 0.45,
  },
  nature: {
    basePoints: 30,
    treeAnnualSequestrationKg: 22.0, // kg CO2 absorbed per tree per year
    treeImmediateBenchmarkKg: 5.5,   // Pro-rated impact awarded
    cleanupWasteAvoidedKg: 4.0,      // kg trash collected in cleanup
  },
  shopping: {
    basePoints: 20,
    secondHandItemCo2Avoided: 8.5,
    clothingRepairWasteKg: 0.5,
  },
  other: {
    basePoints: 15,
    defaultCo2Avoided: 0.8,
  },
};

/**
 * Calculates estimated impact metrics and points for a given action.
 * @param {string} category 
 * @param {string} title 
 * @param {string} description 
 * @param {number} quantity 
 * @returns {object} { pointsEarned, impact: { co2AvoidedKg, waterSavedLitres, energyReducedKwh, wasteAvoidedKg, explanation } }
 */
function calculateEstimatedImpact(category, title = '', description = '', quantity = 1) {
  const cat = (category || 'other').toLowerCase();
  const text = `${title} ${description}`.toLowerCase();
  const qty = Math.max(1, Number(quantity) || 1);

  let co2 = 0;
  let water = 0;
  let energy = 0;
  let waste = 0;
  let explanation = '';
  let basePts = IMPACT_FACTORS[cat]?.basePoints || 15;

  switch (cat) {
    case 'transportation': {
      let km = 5 * qty;
      if (text.includes('walk') || text.includes('foot')) {
        co2 = km * IMPACT_FACTORS.transportation.co2PerKmCarAvoided;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided by walking ~${km} km instead of driving.`;
      } else if (text.includes('cycle') || text.includes('bike') || text.includes('bicycle')) {
        km = 8 * qty;
        co2 = km * IMPACT_FACTORS.transportation.co2PerKmCarAvoided;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided by cycling ~${km} km instead of motorized vehicle.`;
      } else if (text.includes('bus') || text.includes('metro') || text.includes('train') || text.includes('public transit')) {
        km = 12 * qty;
        co2 = km * IMPACT_FACTORS.transportation.co2PerKmTransit;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided by opting for mass transit over solo driving.`;
      } else if (text.includes('carpool') || text.includes('pool')) {
        co2 = 6 * qty * 0.09;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided by ridesharing/carpooling.`;
      } else {
        co2 = km * IMPACT_FACTORS.transportation.co2PerKmCarAvoided;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided through sustainable transit choices.`;
      }
      break;
    }

    case 'energy': {
      if (text.includes('ac') || text.includes('air conditioning')) {
        const hoursSaved = 3 * qty;
        energy = hoursSaved * IMPACT_FACTORS.energy.acKwhPerHour;
        co2 = energy * IMPACT_FACTORS.energy.co2PerKwh;
        explanation = `Estimated ${energy.toFixed(1)} kWh saved and ${co2.toFixed(2)} kg CO2 reduced by curbing AC run-time.`;
      } else if (text.includes('solar')) {
        energy = 6 * qty;
        co2 = energy * IMPACT_FACTORS.energy.co2PerKwh;
        explanation = `Estimated ${energy.toFixed(1)} kWh green power generated, saving ${co2.toFixed(2)} kg CO2 from grid.`;
      } else {
        energy = 1.5 * qty;
        co2 = energy * IMPACT_FACTORS.energy.co2PerKwh;
        explanation = `Estimated ${energy.toFixed(1)} kWh energy saved by turning off idle lights and electronics.`;
      }
      break;
    }

    case 'water': {
      if (text.includes('shower')) {
        water = 5 * IMPACT_FACTORS.water.litresPerMinShower * qty; // 45 litres saved
        co2 = water * IMPACT_FACTORS.water.co2PerLitreHotWater;
        explanation = `Estimated ${water.toFixed(0)} litres saved and ${co2.toFixed(2)} kg CO2 reduced through shorter shower.`;
      } else if (text.includes('rainwater') || text.includes('harvest')) {
        water = 60 * qty;
        explanation = `Estimated ${water.toFixed(0)} litres of freshwater preserved via rainwater harvesting/reuse.`;
      } else if (text.includes('tap') || text.includes('leak') || text.includes('brush')) {
        water = 15 * qty;
        explanation = `Estimated ${water.toFixed(0)} litres saved by closing running taps and fixing leaks.`;
      } else {
        water = 25 * qty;
        explanation = `Estimated ${water.toFixed(0)} litres saved through water conservation practices.`;
      }
      break;
    }

    case 'waste': {
      if (text.includes('bottle') || text.includes('reusable bottle')) {
        waste = 0.09 * qty;
        co2 = waste * IMPACT_FACTORS.waste.co2PerKgPlasticRecycled;
        explanation = `Estimated ${waste.toFixed(2)} kg plastic waste avoided by using reusable bottle.`;
      } else if (text.includes('compost') || text.includes('organic')) {
        waste = 1.2 * qty;
        co2 = 0.8 * qty;
        explanation = `Estimated ${waste.toFixed(1)} kg organic waste diverted from landfill to natural compost.`;
      } else if (text.includes('repair') || text.includes('mend') || text.includes('fix')) {
        waste = 2.0 * qty;
        co2 = 6.0 * qty;
        explanation = `Estimated ${waste.toFixed(1)} kg electronic/goods waste avoided by repairing rather than buying new.`;
      } else {
        waste = 0.5 * qty;
        co2 = 0.4 * qty;
        explanation = `Estimated ${waste.toFixed(2)} kg recyclable waste diverted from municipal waste streams.`;
      }
      break;
    }

    case 'food': {
      if (text.includes('vegan')) {
        co2 = IMPACT_FACTORS.food.veganMealCo2Avoided * qty;
        water = 800 * qty;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided and ${water.toFixed(0)} L virtual water preserved via vegan meal.`;
      } else if (text.includes('veg') || text.includes('plant') || text.includes('meatless')) {
        co2 = IMPACT_FACTORS.food.vegetarianMealCo2Avoided * qty;
        water = IMPACT_FACTORS.food.virtualWaterSavedLitres * qty;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided and ${water.toFixed(0)} L virtual water saved by choosing plant-based.`;
      } else if (text.includes('leftover') || text.includes('food waste')) {
        waste = IMPACT_FACTORS.food.foodWasteAvoidedKg * qty;
        co2 = 1.1 * qty;
        explanation = `Estimated ${waste.toFixed(2)} kg food waste prevented and associated emissions avoided.`;
      } else {
        co2 = 1.2 * qty;
        water = 300 * qty;
        explanation = `Estimated ${co2.toFixed(2)} kg CO2 avoided through conscious climate-friendly dietary choices.`;
      }
      break;
    }

    case 'nature': {
      if (text.includes('tree') || text.includes('plant tree') || text.includes('sapling')) {
        co2 = IMPACT_FACTORS.nature.treeImmediateBenchmarkKg * qty;
        basePts = 50;
        explanation = `Estimated ~${(IMPACT_FACTORS.nature.treeAnnualSequestrationKg * qty).toFixed(0)} kg CO2 annual carbon sequestration initiated by planting ${qty} tree(s).`;
      } else if (text.includes('clean') || text.includes('litter') || text.includes('beach') || text.includes('park')) {
        waste = IMPACT_FACTORS.nature.cleanupWasteAvoidedKg * qty;
        co2 = 1.2 * qty;
        basePts = 40;
        explanation = `Estimated ${waste.toFixed(1)} kg litter collected and cleaned from local environment.`;
      } else {
        co2 = 1.5 * qty;
        explanation = `Estimated positive ecosystem support through urban greening and habitat protection.`;
      }
      break;
    }

    case 'shopping': {
      if (text.includes('thrift') || text.includes('second hand') || text.includes('vintage')) {
        co2 = IMPACT_FACTORS.shopping.secondHandItemCo2Avoided * qty;
        waste = 0.8 * qty;
        explanation = `Estimated ${co2.toFixed(1)} kg manufacturing CO2 avoided by buying pre-loved/secondhand.`;
      } else if (text.includes('bag') || text.includes('tote')) {
        waste = 0.05 * qty;
        explanation = `Estimated single-use plastic packaging and shopping bags avoided.`;
      } else {
        co2 = 2.0 * qty;
        waste = 0.3 * qty;
        explanation = `Estimated emissions avoided through conscious consumption and packaging minimization.`;
      }
      break;
    }

    default: {
      co2 = IMPACT_FACTORS.other.defaultCo2Avoided * qty;
      explanation = `Estimated positive climate impact achieved via conscious environmental action.`;
      break;
    }
  }

  // Calculate points dynamically based on real environmental benefit
  // Formula: base points + (CO2 in kg * 12) + (Water in Litres * 0.15) + (Waste in kg * 10) + (Energy in kWh * 8)
  const impactMultiplier = (co2 * 12) + (water * 0.15) + (waste * 10) + (energy * 8);
  const rawPoints = Math.round(basePts + impactMultiplier);
  const pointsEarned = Math.min(500, Math.max(10, rawPoints));

  return {
    pointsEarned,
    impact: {
      co2AvoidedKg: Number(co2.toFixed(3)),
      waterSavedLitres: Number(water.toFixed(1)),
      energyReducedKwh: Number(energy.toFixed(2)),
      wasteAvoidedKg: Number(waste.toFixed(3)),
      explanation,
    },
  };
}

module.exports = {
  IMPACT_FACTORS,
  calculateEstimatedImpact,
};
