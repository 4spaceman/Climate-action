/**
 * Climate Action Score Calculation Engine (0 - 100)
 * 
 * Formula Breakdown:
 * 1. Verified Actions Factor (Max 30 pts):
 *    Rewards total volume of verified sustainability actions completed.
 *    Calculation: min(30, totalVerifiedActions * 2)
 * 
 * 2. Consistency & Streak Factor (Max 25 pts):
 *    Rewards habitual daily climate stewardship and uninterrupted streaks.
 *    Calculation: min(25, (currentStreak * 2.5) + (longestStreak * 0.75))
 * 
 * 3. Habit Diversity Factor (Max 20 pts):
 *    Rewards taking climate action across diverse facets of life (waste, energy, transport, water, food, nature, shopping).
 *    Calculation: min(20, distinctCategoriesCount * 3.0)
 * 
 * 4. Environmental Impact Volume Factor (Max 15 pts):
 *    Rewards tangible avoided emissions (CO2) and resource conservation (Water, Waste).
 *    Calculation: logarithmic scaling based on cumulative metrics.
 * 
 * 5. Engagement & Community Factor (Max 10 pts):
 *    Rewards community participation, active days, and social climate leadership.
 *    Calculation: min(10, (hasCommunity ? 3 : 0) + (activeDays * 0.5) + (followersCount > 0 ? 2 : 0))
 * 
 * Total Capped at 100 points.
 */

function calculateClimateActionScore({
  totalVerifiedActions = 0,
  currentStreak = 0,
  longestStreak = 0,
  distinctCategoriesCount = 0,
  totalCO2Avoided = 0,
  totalWaterSaved = 0,
  totalWasteAvoided = 0,
  activeDays = 0,
  hasCommunity = false,
  followersCount = 0,
}) {
  // Factor 1: Verified Actions (Max 30)
  const actionsScore = Math.min(30, totalVerifiedActions * 2);

  // Factor 2: Consistency & Streaks (Max 25)
  const streakScore = Math.min(25, (currentStreak * 2.5) + (longestStreak * 0.75));

  // Factor 3: Habit Diversity (Max 20)
  const diversityScore = Math.min(20, distinctCategoriesCount * 3.0);

  // Factor 4: Cumulative Impact (Max 15)
  // 100kg CO2 = ~7 pts, 1000L water = ~4 pts, 50kg waste = ~4 pts
  const co2Pts = Math.min(7, Math.log10(Math.max(1, totalCO2Avoided + 1)) * 3.5);
  const waterPts = Math.min(4, Math.log10(Math.max(1, totalWaterSaved + 1)) * 1.3);
  const wastePts = Math.min(4, Math.log10(Math.max(1, totalWasteAvoided + 1)) * 2.5);
  const impactScore = Math.min(15, co2Pts + waterPts + wastePts);

  // Factor 5: Community & Engagement (Max 10)
  let engagementScore = (hasCommunity ? 3 : 0) + (Math.min(5, activeDays * 0.5)) + (followersCount > 0 ? 2 : 0);
  engagementScore = Math.min(10, engagementScore);

  const rawTotal = actionsScore + streakScore + diversityScore + impactScore + engagementScore;
  const finalScore = Math.min(100, Math.max(0, Math.round(rawTotal)));

  return {
    score: finalScore,
    breakdown: {
      actionsScore: Math.round(actionsScore),
      streakScore: Math.round(streakScore),
      diversityScore: Math.round(diversityScore),
      impactScore: Math.round(impactScore),
      engagementScore: Math.round(engagementScore),
    },
    formulaDescription:
      'Climate Action Score is a dynamic composite (0–100) combining verified action frequency (30%), daily streak consistency (25%), habit diversity across 7 sectors (20%), cumulative CO2/water/waste savings (15%), and collective community engagement (10%).',
  };
}

module.exports = {
  calculateClimateActionScore,
};
