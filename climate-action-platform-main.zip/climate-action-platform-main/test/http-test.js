const { startServer } = require('../server/server');
const fs = require('fs');
const path = require('path');
const OTP = require('../server/models/OTP');
const bcrypt = require('bcryptjs');

async function testHttpEndpoints() {
  console.log('🌐 Starting Comprehensive HTTP & File Upload Validation Test...');
  let server = null;

  try {
    server = await startServer();
    const port = process.env.PORT || 3000;
    const baseUrl = `http://localhost:${port}`;

    // 1. Health check
    console.log('Testing GET /api/health...');
    const healthRes = await fetch(`${baseUrl}/api/health`);
    const healthData = await healthRes.json();
    console.log('Health check response:', healthData);
    if (healthRes.status !== 200 || healthData.status !== 'healthy') {
      throw new Error('Health check failed');
    }
    console.log('✅ Health check passed!');

    // 2. Signup OTP endpoint
    console.log('Testing POST /api/auth/signup-otp...');
    const testEmail = `user_${Date.now()}@climateaction.org`;
    const otpRes = await fetch(`${baseUrl}/api/auth/signup-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: testEmail }),
    });
    const otpData = await otpRes.json();
    if (!otpData.success) {
      throw new Error(`OTP endpoint failed: ${otpData.message}`);
    }
    console.log('✅ Real OTP generation & delivery endpoint passed!');

    // Fetch the generated OTP from MongoDB to verify registration
    const otpRecord = await OTP.findOne({ email: testEmail, type: 'email_verification' });
    if (!otpRecord) throw new Error('OTP was not persisted in MongoDB');

    // Register user with valid OTP by matching hash
    // We can update the OTP document with known code '998877' to test register API
    otpRecord.otp = await bcrypt.hash('998877', 8);
    await otpRecord.save();

    console.log('Testing POST /api/auth/register...');
    const regRes = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testEmail,
        otp: '998877',
        name: 'Alex Rivera',
        password: 'Password123!',
      }),
    });
    const regData = await regRes.json();
    if (!regData.success || !regData.token) {
      throw new Error(`Registration failed: ${regData.message}`);
    }
    const token = regData.token;
    console.log('✅ User registration and JWT issuance passed!');

    // 3. Test Video Rejection on POST /api/actions/report
    console.log('Testing Video Rejection on POST /api/actions/report...');
    const dummyMp4Path = path.join(__dirname, 'dummy-video.mp4');
    fs.writeFileSync(dummyMp4Path, 'FAKE_MP4_VIDEO_STREAM_BYTES');

    const videoBytes = fs.readFileSync(dummyMp4Path);
    const videoBlob = new Blob([videoBytes], { type: 'video/mp4' });

    const videoForm = new FormData();
    videoForm.append('title', 'Video Test');
    videoForm.append('category', 'transportation');
    videoForm.append('description', 'Attempting to upload a forbidden video file');
    videoForm.append('photoProof', videoBlob, 'action-video.mp4');

    const videoRes = await fetch(`${baseUrl}/api/actions/report`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: videoForm,
    });
    const videoData = await videoRes.json();
    console.log('Video upload response (Status ' + videoRes.status + '):', videoData);

    if (videoRes.status === 400 && videoData.message.includes('Video uploads are strictly prohibited')) {
      console.log('✅ Video upload was strictly rejected as required!');
    } else {
      throw new Error(`Expected 400 Bad Request for video upload, but received: ${videoRes.status} ${videoData.message}`);
    }

    // 4. Test Valid Photo Proof Upload
    console.log('Testing Valid Photo Proof Upload on POST /api/actions/report...');
    const dummyJpgPath = path.join(__dirname, 'dummy-photo.jpg');
    // Write valid JPG magic bytes (FF D8 FF E0) followed by dummy payload > 1KB
    const jpgHeader = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46]);
    const padding = Buffer.alloc(2048, 0x20);
    fs.writeFileSync(dummyJpgPath, Buffer.concat([jpgHeader, padding]));

    const photoBytes = fs.readFileSync(dummyJpgPath);
    const photoBlob = new Blob([photoBytes], { type: 'image/jpeg' });

    const photoForm = new FormData();
    photoForm.append('title', 'Cycled to farmers market');
    photoForm.append('category', 'transportation');
    photoForm.append('description', 'Cycled 6 km round-trip using my city bicycle instead of driving my gasoline car.');
    photoForm.append('photoProof', photoBlob, 'bike-proof.jpg');

    const photoRes = await fetch(`${baseUrl}/api/actions/report`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: photoForm,
    });
    const photoData = await photoRes.json();
    console.log('Valid photo upload response (Status ' + photoRes.status + '):', photoData);

    if (photoRes.status !== 201 || !photoData.success) {
      throw new Error(`Photo upload failed: ${photoData.message}`);
    }
    console.log('✅ Valid photo proof accepted, verified, and points awarded!');

    // 5. Test Frontend Static Asset Delivery (Checking index.html)
    console.log('Testing GET / (Frontend delivery)...');
    const htmlRes = await fetch(`${baseUrl}/`);
    const htmlText = await htmlRes.text();
    if (htmlRes.status !== 200 || !htmlText.includes('ClimateAction')) {
      throw new Error('Frontend website failed to serve at http://localhost:3000');
    }
    console.log('✅ Website HTML served successfully at root URL!');

    // Cleanup dummy files
    if (fs.existsSync(dummyMp4Path)) fs.unlinkSync(dummyMp4Path);
    if (fs.existsSync(dummyJpgPath)) fs.unlinkSync(dummyJpgPath);

    console.log('\n🎉 ALL REAL HTTP, AUTH, REST API, FILE UPLOAD, VIDEO REJECTION, AND FRONTEND TESTS PASSED!\n');
  } catch (err) {
    console.error('❌ HTTP Test Failure:', err);
    process.exitCode = 1;
  } finally {
    if (server) {
      server.close();
      console.log('Server shut down cleanly.');
      process.exit(0);
    }
  }
}

testHttpEndpoints();
